package com.soft.utility;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateDifference {
	public long dateDifferenceforPanelty(Date emiList) {
		long diffDays =0;
		Date d1 = null;
		Date d2 = null;
		Date dateToday = new Date();
		if(emiList!=null)
		{
			Date date= emiList;
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			String first= format.format(date);
			String last = format.format(dateToday);
			try {
				d1 = format.parse(first);
				d2 = format.parse(last);
				
				if(d1.getTime() < d2.getTime())
				{
					 long diff = d2.getTime() - d1.getTime();
					 diffDays = diff / (24 * 60 * 60 * 1000);
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		return diffDays;
	}
}

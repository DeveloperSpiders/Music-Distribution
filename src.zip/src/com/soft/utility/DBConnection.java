package com.soft.utility;
import java.beans.PropertyVetoException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

import javax.naming.Context;
import javax.sql.DataSource;

import com.mchange.v2.c3p0.ComboPooledDataSource;

public class DBConnection {
	 private java.sql.Connection conn = null;
	 Statement stmt = null;
	 ResultSet rs = null;
	 private Context ctx = null;
	 private DataSource ds =null;


	 private static DBConnection dataSource;
	   private ComboPooledDataSource comboPooledDataSource;
	   private DBConnection() {
	      try {
	         comboPooledDataSource = new ComboPooledDataSource();
	         comboPooledDataSource
	            .setDriverClass("com.mysql.jdbc.Driver");
	         comboPooledDataSource
	            .setJdbcUrl("jdbc:mysql://localhost:3306/rmcreato_data");
	         comboPooledDataSource.setMinPoolSize(15);
	         comboPooledDataSource.setMaxPoolSize(30);
	         comboPooledDataSource.setAcquireIncrement(30);
	         comboPooledDataSource.setMaxStatementsPerConnection(200);
	         comboPooledDataSource.setMaxConnectionAge(7200);//2min   (this time is in second)
//	         comboPooledDataSource.setUser("");
//	         comboPooledDataSource.setPassword("");
	         comboPooledDataSource.setUser("root");
	         comboPooledDataSource.setPassword("akdesire");
	      }catch (PropertyVetoException ex1) {
	         ex1.printStackTrace();
	      }
	   }

	   public static DBConnection getInstance() {
	      if (dataSource == null)
	         dataSource = new DBConnection();
	      return dataSource;
	   }

	   public Connection insertPreparequery() {
	      Connection con = null;
	      try {
	         con = comboPooledDataSource.getConnection();
			    System.out.println(con+" >>>>>>>>>>>>>>>>>>>>>>>  NEW CONNECTION Created AT >>> :  "+ new  Date());
			        	 System.err.println("num_connections: " + comboPooledDataSource.getNumConnectionsDefaultUser()); 
			        	 System.err.println("num_busy_connections: " + comboPooledDataSource.getNumBusyConnectionsDefaultUser()); 
			        	 System.err.println("num_idle_connections: " + comboPooledDataSource.getNumIdleConnectionsDefaultUser()); 
			        	 System.err.println(); 
	      } catch (SQLException e) {
	         e.printStackTrace();
	      }
	      return con;
	   }
	 
	
	
}

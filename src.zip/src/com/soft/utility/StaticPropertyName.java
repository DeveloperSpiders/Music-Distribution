package com.soft.utility;

public class StaticPropertyName {

	public String sessionPeriod() {
		return "2018-19";
	}
	public String invoiceGeneratedMessageToCustomer() {
		return "2018-19";
	}	
	public String getCurrentYear() {
		return "2019";
	}
	public float minimumPurchaseAmountForFreeShipping() {
		return 200;
	}
}

package com.soft.utility;

import javax.servlet.http.HttpServletRequest;

public class Pagging {

	/*
	 * Get Row Number to set pagging for 20 Records.
	 */
	
	public int extractPaggingNumber(HttpServletRequest request, int count) 
	  {
		  int rowNumber=0;
			int totalRows = count; 
			if(request.getParameter("rowNo")!=null && request.getParameter("btnName")!= null)
			{
				String buttonName = request.getParameter("btnName").toString();
			    rowNumber =Integer.parseInt(request.getParameter("rowNo"));
			    if(buttonName.equals("next") && rowNumber<=20)
			    {	request.setAttribute("next", rowNumber);
			    	request.setAttribute("back", rowNumber+20);
			    }
			    else if(buttonName.equals("next") && rowNumber>20)
			    {	request.setAttribute("next", rowNumber-20);
			    	request.setAttribute("back", rowNumber+20);
			    }
			    else if(buttonName.equals("back")  &&  rowNumber<=totalRows) {
			    	request.setAttribute("next", rowNumber-20);
			    	request.setAttribute("back", rowNumber+20);
				}
			    else
				{	rowNumber=	totalRows;
					request.setAttribute("next", totalRows);
			    	request.setAttribute("back", rowNumber);
				}
			}else
			{	if(request.getParameter("rowNo")!=null)
				{	
					rowNumber =Integer.parseInt(request.getParameter("rowNo"));
					request.setAttribute("next", rowNumber);
			    	request.setAttribute("back", rowNumber+20);
				}
				else
				{	request.setAttribute("next", totalRows);
					request.setAttribute("back", totalRows);
					rowNumber=	totalRows;
				}
			}
			return rowNumber;
		}
	
	public int extractPaggingNumber(HttpServletRequest req, int total,	int rowNo) 
	{
		int back;
		int next;
		req.setAttribute("back", 0);  
		req.setAttribute("next", 0);
		if(rowNo==0 || rowNo>=total)
		{
			rowNo= total;
		}
		if(rowNo >= 1)
		{
			next =rowNo-20;
			if(next >0)
			 {
				req.setAttribute("next", next);
			 }else{
				 req.setAttribute("next", rowNo);
			 }
			 if(rowNo<(total-20))
			 {
				 back = rowNo+20;
				 req.setAttribute("back", back); 
			 }else{
				 req.setAttribute("back", total);  
			 }
		}
		if(rowNo <=1)
		{rowNo = 1;}
		req.getSession().setAttribute("forPagging", rowNo);
		return rowNo;
	}
}

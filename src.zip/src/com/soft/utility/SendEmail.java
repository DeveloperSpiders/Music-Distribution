package com.soft.utility;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class SendEmail {
	public int emailSending(String fromEmail, String toEmail, String subject, String messageData) {
		int i =1;
		/* // Recipient email ID needs to be mentioned.
		 String from =  "no-reply@wearnwalkfashion.com";
		 if(fromEmail!=null && !fromEmail.equals("")){
			 from = fromEmail;
		 }
		 // Sender email ID needs to be mentioned
		 String to = toEmail;
		    // Assuming you are sending email from localhost
		 String host = "localhost";
		 // Get system properties object
		 Properties properties = System.getProperties();
		 // Setup mail server
		 properties.setProperty("mail.smtp.host", host);
		 // Get the default Session object.
		 Session mailSession = Session.getDefaultInstance(properties);
		 try{
		    // Create a default MimeMessage object.
		    MimeMessage message = new MimeMessage(mailSession);
		    // Set From: header field of the header.
		    message.setFrom(new InternetAddress(from));
		    // Set To: header field of the header.
		    message.addRecipient(Message.RecipientType.TO,
		                             new InternetAddress(to));
		    // Set Subject: header field
		    if(subject==null){
		    	subject = "WEAR n WALK";
		    }
		    message.setSubject(subject);
		    // Now set the actual message
		    message.setContent(messageData,"text/html");
		    // Send message
		    Transport.send(message);
		    i=1;
		 }catch (MessagingException mex) {
		    mex.printStackTrace();
		    i=0;
		 }*/
		 return i;
	}
}

package com.soft.utility;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

import javax.servlet.http.HttpServletRequest;

import com.soft.model.Member;

public class SendSMS {
	public int sendSMSToMember(HttpServletRequest request, Member m, String msg)
			throws MalformedURLException, IOException, ProtocolException {
		/*String  urlforsms = "http://sms.akdesire.com/api/sendmsg.php?user=abhinavchatwal&pass=abc&sender=WWFSHN&phone="+m.getContactNumber()+"&text="+msg+"&priority=ndnd&stype=normal";
		URL obj = new URL(urlforsms);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		// optional default is GET
		con.setRequestMethod("GET");
		con.setUseCaches(false);
		con.setDoOutput(true);
		con.connect();
		//Send request
	      DataOutputStream wr = new DataOutputStream (con.getOutputStream());
	      wr.writeBytes(urlforsms);
	      wr.flush ();
	      wr.close ();
		
		int responseCode = con.getResponseCode();
		System.out.println("\nSending 'GET' request to URL : " + urlforsms);
		System.out.println("Response Code : " + responseCode);
		request.getSession().setAttribute("msg", "Profile Updated Successfully");
		return responseCode;*/
		return 200;
	}
}

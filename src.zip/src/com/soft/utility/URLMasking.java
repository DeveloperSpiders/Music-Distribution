package com.soft.utility;

public class URLMasking {
	
	public String maskURL(String subject) {
		String url = null;
		String str = "Url";
		try
		{
			System.out.println("enter a string : ");
				
			str = subject.trim().replaceAll("\\W", " ");
			String[] st = str.split(" ");
			for(int i=0; i<st.length;i++)
			{
				if(st[i].trim().length()!=0)
					url = url +st[i].trim()+" ";
			}
			url = url.replaceAll("null", "");
			url = url.trim().replaceAll(" ", "-");
			    System.out.println(url);
		}
		catch(Exception ex)
        {
             ex.printStackTrace();
         }
		return url;
	}
}

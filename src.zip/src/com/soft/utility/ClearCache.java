package com.soft.utility;

import javax.servlet.http.HttpServletResponse;

public class ClearCache {

	public void clearBrowserCache(HttpServletResponse response) {

		final int CACHE_DURATION_IN_SECOND = 60 * 60 * 24 * 2; // 2 days
		final long   CACHE_DURATION_IN_MS = CACHE_DURATION_IN_SECOND  * 1000;
		long now = System.currentTimeMillis();
		//res being the HttpServletResponse of the request
		response.addHeader("Cache-Control", "max-age=" + CACHE_DURATION_IN_SECOND);
		response.addHeader("Cache-Control", "must-revalidate");//optional
		response.setDateHeader("Last-Modified", now);
		response.setDateHeader("Expires", now + CACHE_DURATION_IN_MS);
		response.setHeader("Pragma", "No-cache");
		response.setHeader("Cache-Control", "no-cache,no-store,max-age=0");
		response.setDateHeader("Expires", 0);
	}
}

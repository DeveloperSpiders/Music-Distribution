package com.soft.web.admin;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.ProfileDAO;
import com.soft.model.Member;
import com.soft.utility.ClearCache;
import com.soft.utility.Pagging;

/**
 * Servlet implementation class AddBlog
 */
@WebServlet("/edit-member")
public class EditMember extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ProfileDAO pfDAO = new ProfileDAO();

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		ServletContext context = getServletContext();
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		Pagging pg = new Pagging();
		int rowNo=0;
		
		if(request.getSession().getAttribute("admin")!=null){
			
			int id = 0;
			if(request.getParameter("id")!=null && !request.getParameter("id").equals("")){
				id = Integer.parseInt(request.getParameter("id").toString());
			}
			Member s = pfDAO.getSilgleMemberDetails(id, con);
			request.setAttribute("student", s);
			
			RequestDispatcher rd= context.getRequestDispatcher("/pages/admin/member/edit-member.jsp");
			rd.forward(request, response);
		}else{
			RequestDispatcher rd= context.getRequestDispatcher("/index.jsp");
			rd.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		 ServletContext context = request.getServletContext();
		//cleared browser calling above class
		 Member m = new Member();
		if(request.getSession().getAttribute("admin")!=null){
			
			int id = 0;
			if(request.getParameter("id")!=null && !request.getParameter("id").equals("")){
				id = Integer.parseInt(request.getParameter("id").toString());
			}
			m.setId(id);
			
			String firstName = request.getParameter("firstName");
			String email = request.getParameter("email");
			String address = request.getParameter("address");
			String contactNumber = request.getParameter("contactNumber");
			String city = request.getParameter("city");
			String state = request.getParameter("state");
			String pinCode = request.getParameter("pinCode");
			String password = request.getParameter("password");
			
			String accountNo = request.getParameter("accountNo");
			String ifsc = request.getParameter("ifsc");
			String bankName = request.getParameter("bankName");
			String googlePay = request.getParameter("googlePay");
			String phonePe = request.getParameter("phonePe");
			String payTm = request.getParameter("payTm");
			String upiId = request.getParameter("upiId");
			
			
			 m.setFirstName(firstName);
			 m.setLastName("");
			 m.setEmail(email);
			 m.setAddress(address);
			 m.setPassword(password);
			 m.setContactNumber(contactNumber);
			 m.setCity(city);
			 m.setState(state);
			 m.setPinCode(pinCode);
			 m.setEntryBy("ADMIN");
			
			 m.setAccountNo(accountNo);
				m.setIfsc(ifsc);
				m.setBankName(bankName);
				m.setGooglePay(googlePay);
				m.setPhonePe(phonePe);
				m.setPayTm(payTm);
				m.setUpiId(upiId);
			
			int i = pfDAO.updateUserDetails(m, con);
			if(i!=0){ 
				request.getSession().setAttribute("msg", "Student Details Update Successfully;");
				response.sendRedirect("edit-member?id="+id);
			}else{
				request.getSession().setAttribute("msg", "SORRY! PLEASE TRY AGAIN LATER");
			}
		}else{
			RequestDispatcher rd = context.getRequestDispatcher("/index.jsp");
			rd.forward(request, response);
		}
	}
}

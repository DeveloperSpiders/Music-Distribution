package com.soft.web.admin;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.LabelDAO;
import com.soft.model.Label;
import com.soft.utility.ClearCache;

/**
 * Servlet implementation class AdminAddBlog
 */
@WebServlet("/admin-edit-blog-display")
public class AdminEditBlogDisplay extends HttpServlet {
	private static final long serialVersionUID = 1L;
	LabelDAO blDAO = new LabelDAO();
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		 ClearCache cc = new ClearCache();
		 cc.clearBrowserCache(response);
		 Label bl = new Label();
		 LabelDAO blDAO = new LabelDAO();
		 ServletContext context = request.getServletContext();
			if(request.getSession().getAttribute("admin")!=null){
			int id = 0;
			if(request.getParameter("id")!=null){
				id = Integer.parseInt(request.getParameter("id"));
			}
				String status = "";
				if(request.getParameter("status")!=null){
					status = request.getParameter("status");
				}
				
				if(status.equals("DISPLAY")){
					status = "NO DISPLAY";
				}else{
					status = "DISPLAY";
				}
				
				
				int i = blDAO.updateURLStatus(status, id, con);
				if(i!=0){
					request.getSession().setAttribute("msg", "URL STATUS CHANGED SUCCESSFULLY");
					request.getSession().setAttribute("blogid", i);
				}
				//response.sendRedirect("upload-blog-images");  
				response.sendRedirect("add-blog");  
				}else{
				RequestDispatcher rd= context.getRequestDispatcher("/index.jsp");
				rd.forward(request, response);
			}
	}

}

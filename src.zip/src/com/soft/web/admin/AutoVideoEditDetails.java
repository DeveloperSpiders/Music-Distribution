package com.soft.web.admin;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.renamedgson.Gson;
import com.soft.dao.VideoDAO;
import com.soft.model.Category;
import com.soft.model.Video;
import com.soft.utility.ClearCache;

/**
 * Servlet implementation class AutoTopCategory
 */
@WebServlet("/AutoVideoEditDetails")
public class AutoVideoEditDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
	VideoDAO cDAO = new VideoDAO();

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}

		response.setContentType("application/json");
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		String name = "";
		String optionList = "";
		try {
			int term = Integer.parseInt(request.getParameter("formType"));
			System.out.println("Data from ajax call " + term);
			
			Video v = cDAO.getSilgleVideoAccountDetails(term, con);
			
			if(v!=null){
				
				name += "<form action='admin-update-video-status' method='post'  >";
				name += "<input type='hidden' name='id' value='"+v.getId()+"' >" +
				
				"<div style='width: 100%;'>" +
				
					"<div class='row'>" +

						"<div class='col-md-12 col-md-12'>" +
							"<div class='row'>" +
								"<div class='col-md-4 col-sm-12 col-lg-4'>" +
									"<label class='lable-text'style=''>Thumbnail</label>" +
									"<br><img id='form__img' src='"+v.getImagepath1()+"' style='width: 100%;' alt=''>" +
								"</div>";
									
								if(v.getType().equals("video")){
								name += "" +	
								"<div class='col-md-4 col-sm-12 col-lg-4'>" +
									"<label class='lable-text'style=''>Video</label>" +
									"<br>" +
									"<video width='100%' id='videoplaya' style='width: 100%;' controls autoplay>" +
							               "<source src='"+v.getFilePath()+"' type='video/mp4'></source>" +
							               "<source src='"+v.getFilePath()+"' type='video/ogg'></source>" +
							          "</video>" +
								"</div>";
								}   
								if(v.getType().equals("audio")){
								name += ""+	
								"<div class='col-md-4 col-sm-12 col-lg-4'>" +
									"<label class='lable-text'style=''>Audio</label>" +
									"<br>" +
									"<audio id='videoplayb' style='width: 100%;' controls autoplay>" +
										  "<source src='"+v.getFilePath()+"' type='audio/ogg'>" +
										  "<source src='"+v.getFilePath()+"' type='audio/mpeg'>" +
									"</audio>" +
								"</div>";
								}
								
								name += "" +	
								"<div class='col-md-4 col-sm-12 col-lg-4'>" +
									"<label class='lable-text'style=''>Title</label>" +
									"<br><input type='text' name='title' value='"+v.getTitle()+"' class='form__input' placeholder='Title*' readonly>" +
								"</div>" +
								"</div>" +
								
							"<div class='row'>" +	
								"<div class='col-12'>" +
									"<label class='lable-text'style=''>Status</label>" +
										"<br>" +
										"<select name='status' required>" +
										"<option value='"+v.getStatus()+"' class='form__input'>"+v.getStatus()+"</option>" +
										"<option value='Reject' class='form__input'>Reject</option>" +
										"<option value='Hold' class='form__input'>Hold</option>" +
										"<option value='Awaiting' class='form__input'>Awaiting</option>" +
										"<option value='Approved' class='form__input'>Approved</option>" +
										"<option value='Update' class='form__input'>Update</option>" +
										"<option value='Process' class='form__input'>Process</option>" +
										"<option value='Live' class='form__input'>Live</option>" +
										"</select>" +
								"</div>" +
								"</div>" +
								
							"<div class='row'>" +
									
								"<div class='col-12'>" +
									"<br><input type='submit' name='submit' value='Update' class='form__input'>" +
								"</div>" +
									
							"</div>" +

							"</div>" +
						"</div>" +

						
					"</div>" +
			"</div>" +
			
			"</div>" ;
								
			name += "</form>";
		} 
			
			
			
			 String searchList = new Gson().toJson(name);
			response.getWriter().write(searchList);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

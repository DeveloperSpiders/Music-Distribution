package com.soft.web.admin;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.renamedgson.Gson;
import com.soft.dao.SubCategoryDAO;
import com.soft.model.Category;
import com.soft.utility.ClearCache;
import com.soft.utility.DBConnection;

/**
 * Servlet implementation class AutoTopCategory
 */
@WebServlet("/AutoTopCategory")
public class AutoTopCategory extends HttpServlet {
	private static final long serialVersionUID = 1L;
	SubCategoryDAO cDAO = new SubCategoryDAO();

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}

		response.setContentType("application/json");
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		String name = "";
		String optionList = "";
		try {
			String term = request.getParameter("formType");
			System.out.println("Data from ajax call " + term);
			ArrayList<Category> al = cDAO.selectCategoryListByMainCategory(term, con);
			for(Category c: al){
				optionList +="<option value='"+c.getSubCategory()+"'>"+c.getSubCategory()+"</option>";
			}
			name= "<div id='mainCertificateId'><select  class='form-control' id='subcategory' name='subcategory' onchange='return clientSearchTableSubCategory();' onclick='return clientSearchTableSubCategory();'>" +optionList+"</select></div>";
			 String searchList = new Gson().toJson(name);
			response.getWriter().write(searchList);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

package com.soft.web.admin;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.AlbumNameDAO;
import com.soft.dao.BlogImageDAO;
import com.soft.model.AlbumName;
import com.soft.model.Gallery;
import com.soft.utility.ClearCache;
import com.soft.utility.DBConnection;
import com.soft.utility.Pagging;

/**
 * Servlet implementation class AddImageGallery
 */
@WebServlet("/add-blog-image")
public class AddBlogImage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	BlogImageDAO gDAO = new BlogImageDAO();

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		ServletContext context = getServletContext();
		Pagging pg = new Pagging();
		int rowNo=0;
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		if(request.getSession().getAttribute("admin")!=null){
			int lstID = gDAO.getLastImageGalleryID(con);
			if(request.getParameter("rowNo")!=null){
				rowNo = Integer.parseInt(request.getParameter("rowNo"));
			}
			int qsv = pg.extractPaggingNumber(request, lstID, rowNo);
			
			ArrayList<Gallery> list = gDAO.getImageGalleryList(qsv, con);
			request.setAttribute("galleryList", list);
			RequestDispatcher rd= context.getRequestDispatcher("/pages/admin/blog-gallery/manage-gallery.jsp");
		    rd.forward(request, response);						
		}else{
			RequestDispatcher rd= context.getRequestDispatcher("/index.jsp");
		    rd.forward(request, response);		
		}							
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}

		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		
		Gallery g = new Gallery();
		g.setAlbumName(request.getParameter("albumName"));
		g.setSubject(request.getParameter("subject"));
		g.setImagePath(request.getParameter("imagepath"));
		int i = gDAO.addNewIamgeInGallery(g, con);
		if(i!=0){
			request.getSession().setAttribute("lstID", i);
			request.getSession().setAttribute("msg", "Gallery Data Added Succesfully! Please Upload a image.");
			response.sendRedirect("upload-blog-gallery-image");
		}else{
			request.getSession().setAttribute("msg", "Sorry! Please Again Later.");
			response.sendRedirect("add-blog-image");
		}
	}
}

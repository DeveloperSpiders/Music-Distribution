package com.soft.web.admin;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.renamedgson.Gson;
import com.soft.dao.LabelDAO;
import com.soft.model.Label;
import com.soft.utility.ClearCache;

/**
 * Servlet implementation class AutoTopCategory
 */
@WebServlet("/AutoLabelDetails")
public class AutoLabelDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
	LabelDAO cDAO = new LabelDAO();

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}

		response.setContentType("application/json");
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		String name = "";
		String optionList = "";
		try {
			int term = Integer.parseInt(request.getParameter("formType"));
			System.out.println("Data from ajax call " + term);
			
			Label v = cDAO.getSingleBlogByID(term, con);
			
			if(v!=null){
				
				name += "" +
				
				"<div style='width: 100%;'>" +
				
					"<div class='row'>" +

						"<div class='col-md-12 col-md-12'>" +
							"<div class='row'>" +
								"<div class='col-md-4 col-sm-12 col-lg-4'>" +
									"<label class='lable-text'style=''>Thumbnail</label>" +
									"<br><img id='form__img' src='"+v.getImagePath()+"' style='width: 100%;' alt=''>" +
								"</div>";
									
								
								name += "" +	
								"<div class='col-md-4 col-sm-12 col-lg-4'>" +
									"<label class='lable-text'style=''>Title</label>" +
									"<br><input type='text' name='title' value='"+v.getTitle()+"' class='form__input' placeholder='Title*' readonly>" +
								"</div>" +

								"<div class='col-md-12'>" +
									"<label class='lable-text'style=''>Description</label>" +
									"<p>"+v.getDescription()+"</p>" +
								"</div>" +
								
								"<div class='col-md-12 col-sm-6 col-lg-3'>" +
									"<label class='lable-text'style=''>Short Desc.</label>" +
										"<br><input type='text' name='crbtTitle' value='"+v.getSubject()+"' class='form__input' placeholder='Category*' readonly>" +
								"</div>" +

								"<div class='col-md-12 col-sm-6 col-lg-3'>" +
									"<label class='lable-text'style=''>Entry By</label>" +
									"<br><input type='text' name='singer' value='"+v.getEntryBy()+"' class='form__input' placeholder='Singer*' readonly>" +
								"</div>" +

									
								"<div class='col-md-12 col-sm-6 col-lg-3'>" +
									"<label class='lable-text'style=''>Date</label>" +
									"<br><input type='text' name='type' id='type' value='"+v.getEntryDate()+"' class='form__input' placeholder='type*' readonly>" +
								"</div>" +

							"</div>" +
						"</div>" +

						
					"</div>" +
			"</div>" +
			
			"</div>" ;
		} 
			
			
			
			 String searchList = new Gson().toJson(name);
			response.getWriter().write(searchList);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

package com.soft.web.admin;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.ProfileDAO;
import com.soft.utility.ClearCache;
import com.soft.utility.DBConnection;

/**
 * Servlet implementation class AdminHome
 */
@WebServlet("/admin-home")
public class AdminHome extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ProfileDAO pfDAO = new ProfileDAO();

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		int id = 0;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}else{
				 con = (Connection)DBConnection.getInstance().insertPreparequery();
				 request.setAttribute("myDBConnection", con);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		ServletContext context = getServletContext();
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		if(request.getSession().getAttribute("admin")!=null){
			
			 if(request.getParameter("id")!=null){
				 id = Integer.parseInt(request.getParameter("id")); 
			 }
			
			
			int totalbstudent = pfDAO.selectTotalStudent(con);
			request.setAttribute("totalbstudent", totalbstudent);
			
			
		
			
			RequestDispatcher rd= context.getRequestDispatcher("/pages/admin/welcome/welcome.jsp");
			rd.forward(request, response);					
		}else{
			RequestDispatcher rd= context.getRequestDispatcher("/index.jsp");
		    rd.forward(request, response);		
		}				
	}
}

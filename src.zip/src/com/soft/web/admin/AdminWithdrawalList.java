package com.soft.web.admin;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.RequestDAO;

/**
 * Servlet implementation class AddFundInWalletConfirm
 */
@WebServlet("/admin-withdrawal-list")
public class AdminWithdrawalList extends HttpServlet {
	private static final long serialVersionUID = 1L;
	RequestDAO wDAO = new RequestDAO();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		ServletContext context = getServletContext();
		if(request.getSession().getAttribute("admin")!=null){
			
			ResultSet withdrawalList = wDAO.getPendingWithdrawalRequestListsFilter(null, null, null, null, null, con);
			request.setAttribute("withdrawalList", withdrawalList);
			
			RequestDispatcher rd= context.getRequestDispatcher("/pages/admin/withdrawal/withdrawal-list.jsp");
		    rd.forward(request, response);			
		}else{
			response.sendRedirect("index.jsp");		
		}							
	}
	
}

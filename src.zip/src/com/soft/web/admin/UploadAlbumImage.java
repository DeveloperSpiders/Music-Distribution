package com.soft.web.admin;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.soft.dao.AlbumNameDAO;
import com.soft.utility.ClearCache;
import com.soft.utility.DBConnection;

/**
 * Servlet implementation class AddBannerImage
 */
@WebServlet("/upload-album-image")
public class UploadAlbumImage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	AlbumNameDAO  bDAO = new AlbumNameDAO();

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ServletContext context = getServletContext();
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		//-------------------------------------------------------------------------
		if(request.getSession().getAttribute("admin")!=null){
			RequestDispatcher rd= context.getRequestDispatcher("/pages/admin/album/upload-album-image.jsp");
		    rd.forward(request, response);						
		}else{
			RequestDispatcher rd= context.getRequestDispatcher("/index.jsp");
		    rd.forward(request, response);		
		}							
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}

		int i = 0;
		int id = (Integer)request.getSession().getAttribute("lstID");
		response.setContentType("text/html;charset=UTF-8");
	    // Create path components to save the file
		String root = getServletContext().getRealPath("/"); 
	    File path = new File(root); 
	    //process only if its multi part content
	    String name = null;
	    String nameNow = null;
//	    ArrayList<String> imgUrlList = new ArrayList<String>();
	   // ServletContext context = getServletContext();
        if(ServletFileUpload.isMultipartContent(request)) {
            try  {
                List<FileItem> multiparts = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(request);
                for(FileItem item : multiparts) {
                    if(!item.isFormField()) {
                        name = new File(item.getName()).getName();
                        nameNow = id+"_"+name;
		                File dir = new File(path + File.separator +"gallery");
		                if(!dir.exists()) {
		                	dir.mkdirs();
		                }
		                item.write( new File(dir + File.separator + nameNow));
                    }
                }
               //File uploaded successfully
               request.getSession().setAttribute("msg", "<span style='color:green;'>File Uploaded Successfully</span>");
               //File uploaded successfully save path into the database
               i = bDAO.updateAlbumImagePath(nameNow, id, con);
               if(i!=0)
            	   System.out.println("Image Uploaded Successfully");
            }catch (Exception ex) {
               request.getSession().setAttribute("msg", "<span style='color:red;'>Sorry! please try again Later</span> " + ex);
            }          
        }else{
            request.getSession().setAttribute("msg", "<span style='color:red;'>Sorry this Servlet only handles file upload request</span>");
        }
        response.sendRedirect("admin-manage-album-name");
		
	}

}

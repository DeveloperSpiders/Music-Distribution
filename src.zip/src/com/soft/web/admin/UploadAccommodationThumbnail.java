 package com.soft.web.admin;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.AccommodationDAO;
import com.soft.model.Accommodation;
import com.soft.utility.ClearCache;
import com.soft.utility.DBConnection;


/**
 * Servlet implementation class UploadPropertyImages
 */
@WebServlet("/upload-accommodation-thumbnail")
public class UploadAccommodationThumbnail extends HttpServlet {
	private static final long serialVersionUID = 1L;
	AccommodationDAO tDAO = new AccommodationDAO();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ServletContext context = getServletContext();
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		//-------------------------------------------------------------------------
		if(request.getSession().getAttribute("admin")!=null){
			Connection con= null;
			try{
				if(request.getSession().getAttribute("myDBConnection")!=null){
					con = (Connection)request.getSession().getAttribute("myDBConnection");
				}else{
					 con = (Connection)DBConnection.getInstance().insertPreparequery();
					request.getSession().setAttribute("myDBConnection", con);
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
			
			int  id=0;
			if(request.getSession().getAttribute("blogID")!=null){
				id = (Integer)request.getSession().getAttribute("blogID");
			}
			Accommodation accommodationSingle = tDAO.getBlogById(id, con);
				request.setAttribute("accommodationSingle", accommodationSingle);
			
			RequestDispatcher rd= context.getRequestDispatcher("/pages/admin/accommodation/upload-accommodation-image.jsp");
		    rd.forward(request, response);						
		}else{
			RequestDispatcher rd= context.getRequestDispatcher("/index.jsp");
		    rd.forward(request, response);		
		}							
	
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getSession().getAttribute("myDBConnection")!=null){
				con = (Connection)request.getSession().getAttribute("myDBConnection");
			}else{
				 con = (Connection)DBConnection.getInstance().insertPreparequery();
				request.getSession().setAttribute("myDBConnection", con);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		int i = 0;
		int id = (Integer)request.getSession().getAttribute("blogID");
		response.setContentType("text/html;charset=UTF-8");
	    // Create path components to save the file
	    //process only if its multi part content
	    String imagePath = null;
	   
	    if(request.getParameter("image")!=null){
	    	imagePath = request.getParameter("image").toString();
		
	    
	    i = tDAO.updateIconPath(imagePath, id, con);
	    }
	    
       request.getSession().setAttribute("msg", "<span style='color:green;'>File Uploaded Successfully</span>");
       if(i!=0){
    	   System.out.println("Image Uploaded Successfully");
    	   request.getSession().setAttribute("msg", "<span style='color:green;'>File Uploaded Successfully</span>");
       }else{
    	   request.getSession().setAttribute("msg", "<span style='color:red;'>Something went wrong!</span>");
       }
        
        response.sendRedirect("add-accommodation");
	}
}

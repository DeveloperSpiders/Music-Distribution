package com.soft.web.admin;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.TravelCategoryDAO;
import com.soft.utility.ClearCache;
import com.soft.utility.DBConnection;

/**
 * Servlet implementation class AdminCategoryDelete
 */
@WebServlet("/admin-travel-category-delete")
public class AdminTravelCategoryDelete extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		TravelCategoryDAO pDAO = new TravelCategoryDAO();
		int id=0;
		String pages = "index.jsp";
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		if(request.getSession().getAttribute("admin")!=null){
			if(request.getParameter("id")!=null){
				id = Integer.parseInt(request.getParameter("id"));
			}
			int i = pDAO.deleteCategory(id, con);
			if(i!=0){
				request.getSession().setAttribute("msg", "Category Deleted Successfully");
			}else{
				request.getSession().setAttribute("msg", "Sorry! Please try again Later");
			}
			pages = "admin-add-travel-category";
		}else{
			pages = "index.jsp";
		}
		response.sendRedirect(pages);
	}
}

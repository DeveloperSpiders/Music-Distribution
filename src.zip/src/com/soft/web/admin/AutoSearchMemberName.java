package com.soft.web.admin;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.renamedgson.Gson;
import com.soft.dao.ProfileDAO;
import com.soft.model.Member;
import com.soft.utility.ClearCache;
import com.soft.utility.DBConnection;

/**
 * Servlet implementation class AutoSearchMemberName
 */
@WebServlet("/autosearchMemberName")
public class AutoSearchMemberName extends HttpServlet {
	private static final long serialVersionUID = 1L;
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}

		response.setContentType("application/json");
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		try {
			String term = request.getParameter("term");
			System.out.println("Data from ajax call " + term);
			ProfileDAO dataDao = new ProfileDAO();
			Member m = dataDao.getSilgleMemberDetailsByLoginID(term, con);
			if(m!=null){
				String name = m.getFirstName();
				String searchList = new Gson().toJson(name);
				response.getWriter().write(searchList);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

package com.soft.web.admin;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.CategoryDAO;
import com.soft.model.Category;
import com.soft.utility.ClearCache;
import com.soft.utility.DBConnection;
import com.soft.utility.Pagging;

/**
 * Servlet implementation class AdminViewCategory
 */
@WebServlet("/admin-view-category")
public class AdminListCategory extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CategoryDAO cDAO = new CategoryDAO();

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		ServletContext context = getServletContext();
		Pagging pg = new Pagging();
		int rowNo=0;
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		if(request.getSession().getAttribute("admin")!=null){
			int lstID = cDAO.totalCategoryCount(con);
			if(request.getParameter("rowNo")!=null){
				rowNo = Integer.parseInt(request.getParameter("rowNo"));
			}
			int qsv = pg.extractPaggingNumber(request, lstID, rowNo);
			ArrayList<Category> list = cDAO.selectCategoryList(con);
			request.setAttribute("cList", list);
			RequestDispatcher rd= context.getRequestDispatcher("/pages/admin/category/add_category.jsp");
		    rd.forward(request, response);	
		}else{
			RequestDispatcher rd= context.getRequestDispatcher("/index.jsp");
		    rd.forward(request, response);		
		}
		
	}

}

package com.soft.web.admin;

import java.io.IOException;
import java.sql.Connection;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.FundWalletDAO;
import com.soft.model.Member;
import com.soft.model.Payment;
import com.soft.utility.DBConnection;

/**
 * Servlet implementation class AddFundInWalletConfirm
 */
@WebServlet("/add-fund-in-wallet")
public class AddFundInWallet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	FundWalletDAO fwDAO = new FundWalletDAO();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ServletContext context = getServletContext();
		if(request.getSession().getAttribute("admin")!=null){
			RequestDispatcher rd= context.getRequestDispatcher("/pages/admin/wallet/add-fund.jsp");
		    rd.forward(request, response);			
		}else{
			response.sendRedirect("index.jsp");		
		}							
	}
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ServletContext context = getServletContext();
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		Member m = new Member();
		float amount=0;
		//-------------------------------------------------------------------------
		if(request.getSession().getAttribute("admin")!=null){
		   m = (Member)request.getSession().getAttribute("admin");
		
		   String loginId = request.getParameter("loginId");
		   String txnid = request.getParameter("txnid");
			String mode = request.getParameter("mode");
			String status = request.getParameter("status");
			String amountAdded = request.getParameter("amount");
			if(amountAdded!=null){
			  float	receivedAmount = Float.parseFloat(amountAdded);
			  amount =(float)(receivedAmount);
			}
			
			Random rm = new Random();
		     int minNum = 1111111;
				int maxNum = 99999999;
				int getNum = rm.nextInt(maxNum - minNum + 1) + minNum;
			
				Payment p = new Payment();
				p.setTotalAmount(amount);
				p.setLoginID(loginId);
				p.setOrderID(getNum);
				p.setPaymentStatus(status);
				p.setPaymentType(txnid);
				p.setPaymentvia(mode);
				int i = fwDAO.addNewFundInWallet(p, con);
				if(i!=0){
					request.getSession().setAttribute("msg", "WALLET FUND ADDED SUCCESSFULLY");
					response.sendRedirect("add-fund-in-wallet");
				}else{
					request.getSession().setAttribute("msg", "SORRY!  PLEASE TRY AGAIN LATER.");
					response.sendRedirect("add-fund-in-wallet");
				}
	  }
										
	}
}

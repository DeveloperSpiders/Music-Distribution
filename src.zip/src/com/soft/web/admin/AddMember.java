package com.soft.web.admin;

import java.io.IOException;
import java.sql.Connection;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.ProfileDAO;
import com.soft.model.Member;
import com.soft.utility.ClearCache;
import com.soft.utility.Pagging;

/**
 * Servlet implementation class AddBlog
 */
@WebServlet("/add-member")
public class AddMember extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ProfileDAO pfDAO = new ProfileDAO();
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		ServletContext context = getServletContext();
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		Pagging pg = new Pagging();
		int rowNo=0;
		
		if(request.getSession().getAttribute("admin")!=null){
			
			
			
			RequestDispatcher rd= context.getRequestDispatcher("/pages/admin/member/add-member.jsp");
			rd.forward(request, response);
		}else{
			RequestDispatcher rd= context.getRequestDispatcher("/index.jsp");
			rd.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		 ServletContext context = request.getServletContext();
		//cleared browser calling above class
		 Member m = new Member();
		if(request.getSession().getAttribute("admin")!=null){
			
			
			int id = 0;
			if(request.getSession().getAttribute("id")!=null && !request.getSession().getAttribute("id").equals("")){
				id = Integer.parseInt(request.getSession().getAttribute("id").toString());
			}
			
			String firstName = request.getParameter("firstName");
			String email = request.getParameter("email");
			String address = request.getParameter("address");
			String contactNumber = request.getParameter("contactNumber");
			String city = request.getParameter("city");
			String state = request.getParameter("state");
			String pinCode = request.getParameter("pinCode");
			String password = request.getParameter("password");
			
			
			String accountNo = request.getParameter("accountNo");
			String ifsc = request.getParameter("ifsc");
			String bankName = request.getParameter("bankName");
			String googlePay = request.getParameter("googlePay");
			String phonePe = request.getParameter("phonePe");
			String payTm = request.getParameter("payTm");
			String upiId = request.getParameter("upiId");
			
			String subString = "";
			Random random = new Random();
			int minNum = 1;
			int maxNum = 5;
			int rndNum = random.nextInt(maxNum - minNum + 1) + minNum;
			String lastLoginID = pfDAO.getLastMemberLOGIN_ID(con);

			long logID = 0;
			
			if(lastLoginID.equals("ADMIN")){
				subString = "111111";
				logID = 111111;
			}else{
				subString = lastLoginID.substring(0);
				logID = Long.parseLong(subString);
			}
			long GenLog = logID + rndNum;
			String generatedLoginID = ""+GenLog;
			m.setLoginID(generatedLoginID);
			
			
			 m.setFirstName(firstName);
			 m.setLastName("");
			 m.setEmail(email);
			 m.setAddress(address);
			 m.setPassword(password);
			 m.setContactNumber(contactNumber);
			 m.setCity(city);
			 m.setState(state);
			 m.setPinCode(pinCode);
			 m.setEntryBy("ADMIN");
			 
			 m.setAccountNo(accountNo);
			m.setIfsc(ifsc);
			m.setBankName(bankName);
			m.setGooglePay(googlePay);
			m.setPhonePe(phonePe);
			m.setPayTm(payTm);
			m.setUpiId(upiId);
			
			
			int i = pfDAO.addMember(m, con);
			if(i!=0){ 
				
				request.getSession().setAttribute("lstID", i);
				request.getSession().setAttribute("msg", "Registration Successfull;");
			}else{
				request.getSession().setAttribute("msg", "SORRY! PLEASE TRY AGAIN LATER");
			}
			response.sendRedirect("add-member");
		}else{
			RequestDispatcher rd = context.getRequestDispatcher("/index.jsp");
			rd.forward(request, response);
		}
	}
}

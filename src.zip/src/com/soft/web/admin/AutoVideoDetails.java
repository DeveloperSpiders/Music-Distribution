package com.soft.web.admin;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.renamedgson.Gson;
import com.soft.dao.VideoDAO;
import com.soft.model.Category;
import com.soft.model.Video;
import com.soft.utility.ClearCache;

/**
 * Servlet implementation class AutoTopCategory
 */
@WebServlet("/AutoVideoDetails")
public class AutoVideoDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
	VideoDAO cDAO = new VideoDAO();

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}

		response.setContentType("application/json");
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		String name = "";
		String optionList = "";
		try {
			int term = Integer.parseInt(request.getParameter("formType"));
			System.out.println("Data from ajax call " + term);
			
			Video v = cDAO.getSilgleVideoAccountDetails(term, con);
			
			if(v!=null){
				
				name += "" +
				
				"<div style='width: 100%;'>" +
				
					"<div class='row'>" +

						"<div class='col-md-12 col-md-12'>" +
							"<div class='row'>" +
								"<div class='col-md-4 col-sm-12 col-lg-4'>" +
									"<label class='lable-text'style=''>Thumbnail</label>" +
									"<br><img id='form__img' src='"+v.getImagepath1()+"' style='width: 100%;' alt=''>" +
								"</div>";
									
								if(v.getType().equals("video")){
								name += "" +	
								"<div class='col-md-4 col-sm-12 col-lg-4'>" +
									"<label class='lable-text'style=''>Video</label>" +
									"<br>" +
									"<video width='100%' id='videoplaya' style='width: 100%;' controls autoplay>" +
							               "<source src='"+v.getFilePath()+"' type='video/mp4'></source>" +
							               "<source src='"+v.getFilePath()+"' type='video/ogg'></source>" +
							          "</video>" +
								"</div>";
								}   
								if(v.getType().equals("audio")){
								name += ""+	
								"<div class='col-md-4 col-sm-12 col-lg-4'>" +
									"<label class='lable-text'style=''>Audio</label>" +
									"<br>" +
									"<audio id='videoplayb' style='width: 100%;' controls autoplay>" +
										  "<source src='"+v.getFilePath()+"' type='audio/ogg'>" +
										  "<source src='"+v.getFilePath()+"' type='audio/mpeg'>" +
									"</audio>" +
								"</div>";
								}
								
								name += "" +	
								"<div class='col-md-4 col-sm-12 col-lg-4'>" +
									"<label class='lable-text'style=''>Title</label>" +
									"<br><input type='text' name='title' value='"+v.getTitle()+"' class='form__input' placeholder='Title*' readonly>" +
								"</div>" +

								"<div class='col-md-12'>" +
									"<label class='lable-text'style=''>Description</label>" +
									"<p>"+v.getDescription()+"</p>" +
								"</div>" +
								
								"<div class='col-md-12 col-sm-6 col-lg-3'>" +
									"<label class='lable-text'style=''>Category</label>" +
										"<br><input type='text' name='crbtTitle' value='"+v.getCategory()+"' class='form__input' placeholder='Category*' readonly>" +
								"</div>" +

								"<div class='col-md-12 col-sm-6 col-lg-3'>" +
									"<label class='lable-text'style=''>Singer</label>" +
									"<br><input type='text' name='singer' value='"+v.getSinger()+"' class='form__input' placeholder='Singer*' readonly>" +
								"</div>" +

								"<div class='col-md-12 col-sm-6 col-lg-3'>" +
									"<label class='lable-text'style=''>Music Director</label>" +
									"<br><input type='text' name='musicDirector' value='"+v.getMusicDirector()+"' class='form__input' placeholder='Music Director*' readonly>" +
								"</div>" +

								"<div class='col-md-12 col-sm-6 col-lg-3'>" +
									"<label class='lable-text'style=''>Lyrics</label>" +
									"<br><input type='text' name='lyrics' value='"+v.getLyrics()+"' class='form__input' placeholder='Lyrics*' readonly>" +
								"</div>" +

								
								"<div class='col-md-12 col-sm-6 col-lg-3'>" +
									"<label class='lable-text'style=''>Genre</label>" +
									"<br><input type='text' name='crbtTitle' value='"+v.getGenre()+"' class='form__input' placeholder='Genre*' readonly>" +
								"</div>" +

								"<div class='col-md-12 col-sm-6 col-lg-3'>" +
									"<label class='lable-text'style=''>Mood</label>" +
									"<br><input type='text' name='mood' value='"+v.getMood()+"' class='form__input' placeholder='Mood*' readonly>" +
								"</div>" +

								"<div class='col-md-12 col-sm-6 col-lg-3'>" +
									"<label class='lable-text'style=''>Label</label>" +
									"<br><input type='text' name='label' value='"+v.getLabel()+"' class='form__input' placeholder='Label*' readonly>" +
								"</div>" +

								"<div class='col-md-12 col-sm-6 col-lg-3'>" +
									"<label class='lable-text'style=''>Publisher</label>" +
									"<br><input type='text' name='publisher' value='"+v.getPublisher()+"' class='form__input' placeholder='Publisher*' readonly>" +
								"</div>" +

								"<div class='col-md-12 col-sm-6 col-lg-3'>" +
									"<label class='lable-text'style=''>Language</label>" +
										"<br><input type='text' name='crbtTitle' value='"+v.getLanguage()+"' class='form__input' placeholder='Language*' readonly>" +
								"</div>" +

								"<div class='col-md-12 col-sm-6 col-lg-3'>" +
									"<label class='lable-text'style=''>ISRC</label>" +
									"<br><input type='text' name='isrc' value='"+v.getIsrc()+"' class='form__input' placeholder='ISRC' readonly>" +
								"</div>" +

								"<div class='col-md-12 col-sm-6 col-lg-3'>" +
									"<label class='lable-text'style=''>CRBT Title</label>" +
									"<br><input type='text' name='crbtTitle' value='"+v.getCrbtTitle()+"' class='form__input' placeholder='CRBT Title*' readonly>" +
								"</div>" +

								"<div class='col-md-12 col-sm-6 col-lg-3'>" +
									"<label class='lable-text'style=''>CRBT Time</label>" +
									"<br><input type='text' name='crbtTime' value='"+v.getCrbtTime()+"' class='form__input' placeholder='CRBT Time*' readonly>" +
								"</div>" +

								"<div class='col-md-12 col-sm-6 col-lg-3'>" +
									"<label class='lable-text'style=''>Track Duration</label>" +
									"<br><input type='text' name='trackDuration' value='"+v.getDuration()+"' class='form__input' placeholder='Track Duration*' readonly>" +
								"</div>" +

								"<div class='col-md-12 col-sm-6 col-lg-3'>" +
									"<label class='lable-text'style=''>Video Director</label>" +
									"<br><input type='text' name='videoDirector' value='"+v.getVideoDirector()+"' class='form__input' placeholder='Video Director' readonly>" +
								"</div>" +

								"<div class='col-md-12 col-sm-6 col-lg-3'>" +
									"<label class='lable-text'style=''>Star Cast</label>" +
									"<br><input type='text' name='starCast' value='"+v.getStarCast()+"' class='form__input' placeholder='Star Cast*' readonly>" +
								"</div>" +

								"<div class='col-md-12 col-sm-6 col-lg-3'>" +
									"<label class='lable-text'style=''>Releasing Date</label>" +
									"<br><input type='text' name='releasingDate' id='releasingDate' value='"+v.getReleasingDate()+"' class='form__input' placeholder='Releasing Date*' readonly>" +
								"</div>" +
									
								"<div class='col-md-12 col-sm-6 col-lg-3'>" +
									"<label class='lable-text'style=''>Type</label>" +
									"<br><input type='text' name='type' id='type' value='"+v.getType()+"' class='form__input' placeholder='type*' readonly>" +
								"</div>" +

							"</div>" +
						"</div>" +

						
					"</div>" +
			"</div>" +
			
			"</div>" ;
		} 
			
			
			
			 String searchList = new Gson().toJson(name);
			response.getWriter().write(searchList);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

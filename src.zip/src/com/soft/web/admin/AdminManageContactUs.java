package com.soft.web.admin;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.ContactUsDAO;
import com.soft.model.ContactUs;
import com.soft.model.Member;
import com.soft.utility.ClearCache;
import com.soft.utility.DBConnection;

/**
 * Servlet implementation class AdminManageContactUs
 */
@WebServlet("/admin-manage-contact-us")
public class AdminManageContactUs extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ContactUsDAO cuDAO = new ContactUsDAO();

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		 ServletContext context = request.getServletContext();
			if(request.getSession().getAttribute("admin")!=null){
				ArrayList<ContactUs> list = cuDAO.selectContactList(con);
				request.setAttribute("ContactList", list);
				  RequestDispatcher rd = context.getRequestDispatcher("/pages/admin/contact_us/add_contact_details.jsp");
				  rd.forward(request, response);
			}else{
				RequestDispatcher rd= context.getRequestDispatcher("/index.jsp");
				rd.forward(request, response);
			}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}

		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		if(request.getSession().getAttribute("admin")!=null){
			Member log = (Member)request.getSession().getAttribute("admin");
			
			ContactUs jb = new ContactUs();
			
			jb.setContact(request.getParameter("contact"));
			jb.setContact2(request.getParameter("contact2"));
			jb.setAddress(request.getParameter("address"));
			jb.setAddress2(request.getParameter("address2"));
			jb.setEmail(request.getParameter("email"));
			jb.setEmail2(request.getParameter("email2"));
			jb.setAbout(request.getParameter("about"));
			jb.setAboutLong(request.getParameter("aboutLong"));
			int i= cuDAO.addNewContact(jb, con);
			if(i!=0){
				request.getSession().setAttribute("msg", "New Contact Added Successfully.");
				
			}else{
				request.getSession().setAttribute("msg", "Sorry! please try again later.");
			}
			response.sendRedirect("admin-manage-contact-us");
		}else{
			response.sendRedirect("index.jsp");
		}
	}

}

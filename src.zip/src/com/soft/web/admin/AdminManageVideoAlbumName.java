package com.soft.web.admin;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.VideoAlbumDAO;
import com.soft.model.Member;
import com.soft.model.VideoAlbumName;
import com.soft.utility.ClearCache;
import com.soft.utility.DBConnection;

/**
 * Servlet implementation class AdminManageVideoAlbumName
 */
@WebServlet("/manage-video-album-name")
public class AdminManageVideoAlbumName extends HttpServlet {
	private static final long serialVersionUID = 1L;
	VideoAlbumDAO vbDAO = new VideoAlbumDAO();

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		int id = 0;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}else{
				 con = (Connection)DBConnection.getInstance().insertPreparequery();
				 request.setAttribute("myDBConnection", con);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		 ServletContext context = request.getServletContext();
		 
			if(request.getSession().getAttribute("admin")!=null){
				
				ArrayList<VideoAlbumName> list = vbDAO.selectVideoAlbumList(con);
				request.setAttribute("videoalbumlist", list);
				RequestDispatcher rd = context.getRequestDispatcher("/pages/admin/video_album/manage-video-album.jsp");
				rd.forward(request, response);
		 }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		if(request.getSession().getAttribute("admin")!=null){
			Member m = (Member)request.getSession().getAttribute("admin");
			
			VideoAlbumName vb = new VideoAlbumName();
			vb.setAlbumname(request.getParameter("albumname"));
			vb.setSubject(request.getParameter("subject"));
			vb.setImagepath(request.getParameter("imagepath"));
			int i = vbDAO.addNewVideoAlbum(vb, con);
			if(i!=0){
				int lstID = vbDAO.totalMaxAlbumId(con);
				request.getSession().setAttribute("lstID", lstID);
				request.getSession().setAttribute("msg", "Video Album Create Succesfully!");
				response.sendRedirect("upload-video-album-image");
			}else{
				request.getSession().setAttribute("msg", "Sorry! Please Try Again Later");
				response.sendRedirect("manage-video-album-name");
			}
		}
		
	}

}

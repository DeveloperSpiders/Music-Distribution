package com.soft.web.admin;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.CategoryDAO;
import com.soft.dao.TravelCategoryDAO;
import com.soft.dao.TravelDAO;
import com.soft.model.Category;
import com.soft.model.Travel;
import com.soft.model.TravelCategory;
import com.soft.utility.ClearCache;
import com.soft.utility.DBConnection;
import com.soft.utility.Pagging;

/**
 * Servlet implementation class AddBlog
 */
@WebServlet("/add-travel")
public class AddTravel extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CategoryDAO cDAO = new CategoryDAO();
	TravelCategoryDAO tcDAO = new TravelCategoryDAO();
	TravelDAO tDAO = new TravelDAO();

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		ServletContext context = getServletContext();
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		Pagging pg = new Pagging();
		int rowNo=0;
		
		if(request.getSession().getAttribute("admin")!=null){
			
			ArrayList<TravelCategory> list = tcDAO.selectCategoryList(con);
			if(list!=null){
				request.setAttribute("tcList", list);
			}else{
				request.setAttribute("tcList", null);
			}
			
			ArrayList<Category> cl = cDAO.selectCategoryList(con);
			if(list!=null){
				request.setAttribute("cList", cl);
			}else{
				request.setAttribute("cList", null);
			}
			
			int lstID = tDAO.getLastBlogID(con);
			if(request.getParameter("rowNo")!=null){
				rowNo = Integer.parseInt(request.getParameter("rowNo"));
			}
			int qsv = pg.extractPaggingNumber(request, lstID, rowNo);
			ArrayList<Travel> travelList = tDAO.getBlogList(qsv, con);
			if(travelList!=null){
				request.setAttribute("travelList", travelList);
			}else{
				request.setAttribute("travelList", null);
			}
			
			
			RequestDispatcher rd= context.getRequestDispatcher("/pages/admin/travel/add-travel.jsp");
			rd.forward(request, response);
		}else{
			RequestDispatcher rd= context.getRequestDispatcher("/index.jsp");
			rd.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		 ServletContext context = request.getServletContext();
		//cleared browser calling above class
		 Travel b = new Travel();
		 TravelDAO blDAO = new TravelDAO();
		if(request.getSession().getAttribute("admin")!=null){
			
			b.setTravelCategory(request.getParameter("travelCategory"));
			b.setSubjectLine(request.getParameter("subjectLine"));
			b.setDescription(request.getParameter("description"));
			b.setEntryBy("ADMIN");
			b.setState(request.getParameter("category"));
			b.setDistrict(request.getParameter("subcategory"));
			b.setCity(request.getParameter("childcategory"));
			b.setStatus(request.getParameter("status"));
			b.setName(request.getParameter("name"));
			
			
			if(request.getParameter("video")!=null && !request.getParameter("video").equals("")){
				b.setVideoPath(request.getParameter("video"));
			}else{
				b.setVideoPath("");
			}
			
			
			int i = blDAO.addNewBlog(b, con);
			if(i!=0){ 
				int id = blDAO.getLastBlogID(con);
				request.getSession().setAttribute("blogID", id);
				request.getSession().setAttribute("msg", "BLOG UPDATED SUCCESSFULLY");
//				response.sendRedirect("upload-travel-image");
				response.sendRedirect("upload-travel-thumbnail");
				
			}else{
				request.getSession().setAttribute("msg", "SORRY! PLEASE TRY AGAIN LATER");
			}
		}else{
			RequestDispatcher rd = context.getRequestDispatcher("/index.jsp");
			rd.forward(request, response);
		}
	}
}

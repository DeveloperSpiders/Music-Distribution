package com.soft.web.admin;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.BannerDAO;
import com.soft.model.Banner;
import com.soft.model.Label;
import com.soft.utility.ClearCache;
import com.soft.utility.DBConnection;

/**
 * Servlet implementation class AdminAddBanner
 */
@WebServlet("/admin-add-banner")
public class AdminAddBanner extends HttpServlet {
	private static final long serialVersionUID = 1L;
	BannerDAO bnrDAO = new BannerDAO();
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		ServletContext context = getServletContext();
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		//-------------------------------------------------------------------------
		if(request.getSession().getAttribute("admin")!=null){
			
			ArrayList<Banner> bannerList = bnrDAO.getImageBannerList(con);
			if(bannerList!=null){
				request.setAttribute("bannerList", bannerList);
			}else{
				request.setAttribute("bannerList", null);
			}
			
			
			
			RequestDispatcher rd= context.getRequestDispatcher("/pages/admin/banner/add_banner.jsp");
		    rd.forward(request, response);						
		}else{
			RequestDispatcher rd= context.getRequestDispatcher("/index.jsp");
		    rd.forward(request, response);		
		}							
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}

		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		Banner b = new Banner();
		b.setAbout(request.getParameter("about"));
		b.setSubLine(request.getParameter("subLine"));
		b.setTopLine(request.getParameter("topLine"));
		b.setShoppingURL(request.getParameter("shoppingURL"));
		BannerDAO bDAO = new BannerDAO();
		int i = bDAO.addNewIamgeInBanner(b, con);
		if(i!=0){
			request.getSession().setAttribute("lstID", i);
			response.sendRedirect("upload-banner-image?id="+i);
		}else{
			response.sendRedirect("add-banner-image");
		}
	}
}

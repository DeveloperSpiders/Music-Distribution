package com.soft.web.admin;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.FundWalletDAO;
import com.soft.model.Member;
import com.soft.model.Payment;
import com.soft.utility.DBConnection;

/**
 * Servlet implementation class AddFundInWalletConfirm
 */
@WebServlet("/admin-fund-list")
public class AdminFundList extends HttpServlet {
	private static final long serialVersionUID = 1L;
	FundWalletDAO fwDAO = new FundWalletDAO();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		ServletContext context = getServletContext();
		if(request.getSession().getAttribute("admin")!=null){
			
			ArrayList<Payment> fundList = fwDAO.getSilgleMemberFundInWalletDetails(con);
			request.setAttribute("fundList", fundList);
			
			RequestDispatcher rd= context.getRequestDispatcher("/pages/admin/wallet/fund-list.jsp");
		    rd.forward(request, response);			
		}else{
			response.sendRedirect("index.jsp");		
		}							
	}
	
}

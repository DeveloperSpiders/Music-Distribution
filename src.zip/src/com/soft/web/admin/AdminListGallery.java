package com.soft.web.admin;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.GalleryDAO;
import com.soft.model.Gallery;
import com.soft.utility.ClearCache;
import com.soft.utility.DBConnection;
import com.soft.utility.Pagging;

/**
 * Servlet implementation class AdminListGallery
 */
@WebServlet("/admin-list-gallery")
public class AdminListGallery extends HttpServlet {
	private static final long serialVersionUID = 1L;
	GalleryDAO gDAO = new GalleryDAO();

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		ServletContext context = getServletContext();
		Pagging pg = new Pagging();
		int rowNo=0;
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		if(request.getSession().getAttribute("admin")!=null){
			int lstID = gDAO.getLastImageGalleryID(con);
			if(request.getParameter("rowNo")!=null){
				rowNo = Integer.parseInt(request.getParameter("rowNo"));
			}
			int qsv = pg.extractPaggingNumber(request, lstID, rowNo);
			ArrayList<Gallery> list = gDAO.getImageGalleryList(qsv, con);
			request.setAttribute("galleryList", list);
			RequestDispatcher rd= context.getRequestDispatcher("/pages/admin/gallery/manage-gallery.jsp");
		    rd.forward(request, response);	
		}else{
			RequestDispatcher rd= context.getRequestDispatcher("/index.jsp");
		    rd.forward(request, response);		
		}
	}
}

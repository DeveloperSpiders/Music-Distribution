package com.soft.web.admin;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.CategoryDAO;
import com.soft.dao.LoginDAO;
import com.soft.model.Category;
import com.soft.model.Login;
import com.soft.model.Member;
import com.soft.utility.ClearCache;
import com.soft.utility.DBConnection;

/**
 * Servlet implementation class AdminLogin
 */
@WebServlet("/admin")
public class AdminLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CategoryDAO ctgDAO = new CategoryDAO();
	LoginDAO loginDAO = new LoginDAO();

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ServletContext context = getServletContext();
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
			RequestDispatcher rd= context.getRequestDispatcher("/pages/admin/account/login.jsp");
		    rd.forward(request, response);	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}

		Login login = new Login();
		  login.setEmailID(request.getParameter("email").toUpperCase());
		  login.setPassword(request.getParameter("password"));
//		  Date date = new Date();
		  String pages ="";
//		  SimpleDateFormat sm = new SimpleDateFormat("yyyy-MM-dd");
		  	Member m = loginDAO.memberLogin(login, con);
				if(m!=null && m.getLoginID().equals("ADMIN")){
					
						request.getSession().setAttribute("user", m);
						request.getSession().setAttribute("admin", m);
						pages="admin-home";
						
				}
				else{	
					request.getSession().setAttribute("msg", "<span style='color:red;'>You Entered Wrong UserID or Password.? Please Try Again</span>");
					pages="admin";
				}
				response.sendRedirect(pages);
			
		
	}

}

package com.soft.web.admin;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.LoginDAO;
import com.soft.model.Member;
import com.soft.utility.ClearCache;
import com.soft.utility.DBConnection;

/**
 * Servlet implementation class AdminChangePassword
 */
@WebServlet("/admin-change-password")
public class AdminChangePassword extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ServletContext context = getServletContext();
		if(request.getSession().getAttribute("admin")!=null){
			//clear browser cache memory for receive fresh data
			ClearCache cc = new ClearCache();
			cc.clearBrowserCache(response);
			//cleared browser calling above class
			RequestDispatcher rd= context.getRequestDispatcher("/pages/admin/account/change-password.jsp");
			rd.forward(request, response);												
		}else{
			RequestDispatcher rd= context.getRequestDispatcher("/index.jsp");
		    rd.forward(request, response);		
		}						
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		Member m = null;
		LoginDAO loginDAO = new LoginDAO();
		if(request.getSession().getAttribute("admin")!=null){
			//clear browser cache memory for receive fresh data
			ClearCache cc = new ClearCache();
			cc.clearBrowserCache(response);
			//cleared browser calling above class
		String oldPassword = request.getParameter("oldPassword");
		String newPassword = request.getParameter("newPassword");
		String confirmPassword = request.getParameter("confirmPassword");
		if(request.getSession().getAttribute("admin")!=null){
		 m = (Member)request.getSession().getAttribute("admin");
		}
		if(m.getPassword().equals(oldPassword) && newPassword.equals(confirmPassword)){
			int i = loginDAO.changePassword(newPassword, m.getLoginID(), m.getId(), con);
			if(i!=0){
				request.getSession().setAttribute("msg", "Password Changed Successfully");
			}
		}else{
			request.getSession().setAttribute("msg", "Sorry! Please Enter Password Properly");
			
		}
		response.sendRedirect("admin-change-password");		
	}else{
		response.sendRedirect("admin-change-password");		
	}						
 }
}

package com.soft.web.admin;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.renamedgson.Gson;
import com.soft.dao.ChildCategoryDAO;
import com.soft.model.ChildCategory;
import com.soft.utility.ClearCache;
import com.soft.utility.DBConnection;

/**
 * Servlet implementation class AutoSubCategory
 */
@WebServlet("/autosubcategory")
public class AutoSubCategory extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ChildCategoryDAO cDAO = new ChildCategoryDAO();
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}

		response.setContentType("application/json");
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		String name = "";
		String optionList = "";
		try {
			String term = request.getParameter("formType");
			System.out.println("Data from ajax call " + term);
			ArrayList<ChildCategory> al = cDAO.selectChildCategoryListByMainChildCategory(term, con);
			for(ChildCategory c: al){
				optionList +="<option value='"+c.getExtras()+"'>"+c.getExtras()+"</option>";
			}
			 name= "<div id='subCertificateId'><select class='form-control' onclick='return autoProductNameListByCategory()' id='childcategory' name='childcategory'>" +optionList+"</select></div>";
			 String searchList = new Gson().toJson(name);
			response.getWriter().write(searchList);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

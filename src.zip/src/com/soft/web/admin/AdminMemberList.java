package com.soft.web.admin;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.ProfileDAO;
import com.soft.model.Member;
import com.soft.utility.ClearCache;

/**
 * Servlet implementation class AdminMember
 */
@WebServlet("/admin-member-list")
public class AdminMemberList extends HttpServlet {
	private static final long serialVersionUID = 1L;
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		ServletContext context = getServletContext();
		ProfileDAO pfDAO = new ProfileDAO();
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		if(request.getSession().getAttribute("admin")!=null){
			
			ArrayList<Member> list = pfDAO.getFullDataDownLineForGeonology(0, con);
			request.setAttribute("mbrList", list);
			RequestDispatcher rd= context.getRequestDispatcher("/pages/admin/member/member-list.jsp");
		    rd.forward(request, response);	
		}else{
			RequestDispatcher rd= context.getRequestDispatcher("/index.jsp");
		    rd.forward(request, response);		
		}
	}
	
}

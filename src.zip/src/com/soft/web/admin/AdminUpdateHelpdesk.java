package com.soft.web.admin;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.HelpDeskDAO;
import com.soft.model.Helpdesk;
import com.soft.model.Member;
import com.soft.utility.ClearCache;
import com.soft.utility.DBConnection;
import com.soft.utility.SendSMS;

/**
 * Servlet implementation class AdminUpdateHelpdesk
 */
@WebServlet("/admin-update-helpdesk")
public class AdminUpdateHelpdesk extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		ServletContext context = getServletContext();
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		int rowNo=0;
		HelpDeskDAO hdDAO = new HelpDeskDAO();
		if(request.getSession().getAttribute("admin")!=null){
			Member m = (Member)request.getSession().getAttribute("admin");
			if(request.getParameter("id")!=null){
				rowNo = Integer.parseInt(request.getParameter("id"));
			}
			String loginId = request.getParameter("lid");
			Helpdesk al =  hdDAO.getSingleTicketListForAdmin(rowNo, con);
			request.setAttribute("singleTicket", al);

			RequestDispatcher rd= context.getRequestDispatcher("/pages/admin/helpdesk/admin-update-help.jsp");
		    rd.forward(request, response);						
		}else{
			response.sendRedirect("index.jsp");
		}			
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		int rowNo=0;
		HelpDeskDAO hdDAO = new HelpDeskDAO();
		if(request.getSession().getAttribute("admin")!=null){
			Member m = (Member)request.getSession().getAttribute("admin");
			if(request.getParameter("rowID")!=null){
				rowNo = Integer.parseInt(request.getParameter("rowID"));
			}
			String comment = request.getParameter("comment");
			int i=  hdDAO.updateHelpDeskByAdmin(comment, rowNo, con);
			if(i!=0){
				request.getSession().setAttribute("msg", "message saved successfylly");
			}else{
				request.getSession().setAttribute("msg", "Sorry! Please try again later.");
			}
			response.sendRedirect("admin-help-desk");								
		}else{
			response.sendRedirect("index.jsp");			
		}			
	}
}

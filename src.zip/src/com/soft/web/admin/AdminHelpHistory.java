package com.soft.web.admin;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.HelpDeskDAO;
import com.soft.model.Helpdesk;
import com.soft.model.Member;
import com.soft.utility.ClearCache;
import com.soft.utility.DBConnection;
import com.soft.utility.Pagging;
import com.soft.utility.SendSMS;
import com.soft.utility.StaticPropertyName;

/**
 * Servlet implementation class AdminHelpHistory
 */
@WebServlet("/admin-help-history")
public class AdminHelpHistory extends HttpServlet {
	private static final long serialVersionUID = 1L;
	StaticPropertyName spn = new StaticPropertyName();
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		ServletContext context = getServletContext();
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		Pagging pg = new Pagging();
		int rowNo=0;
		HelpDeskDAO hdDAO = new HelpDeskDAO();
		if(request.getSession().getAttribute("admin")!=null){
			Member m = (Member)request.getSession().getAttribute("admin");
			int lstID = hdDAO.getLastTicketId(con);
			if(request.getParameter("rowNo")!=null){
				rowNo = Integer.parseInt(request.getParameter("rowNo"));
			}
			int qsv = pg.extractPaggingNumber(request, lstID, rowNo);
			ArrayList<Helpdesk> al =  hdDAO.getCloseTicketListForAdmin("close", con);
			request.setAttribute("ticketList", al);
			RequestDispatcher rd= context.getRequestDispatcher("/pages/admin/helpdesk/admin-help-history.jsp");
		    rd.forward(request, response);										
			}else{
				response.sendRedirect("index.jsp");
			}			
	}
}

package com.soft.web.admin;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.AccommodationDAO;
import com.soft.utility.ClearCache;
import com.soft.utility.DBConnection;

/**
 * Servlet implementation class AdminDeleteVideo
 */
@WebServlet("/admin-delete-accommodation")
public class AdminDeleteAccommodation extends HttpServlet {
	private static final long serialVersionUID = 1L;
	AccommodationDAO bDAO = new AccommodationDAO();

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		ServletContext context = getServletContext();
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		//-------------------------------------------------------------------------
		if(request.getSession().getAttribute("admin")!=null){
			int  rowNo=0;
			if(request.getParameter("id")!=null){
				rowNo = Integer.parseInt(request.getParameter("id"));
			}
			int i = bDAO.deleteBlog(rowNo, con);
			if(i!=0){
				request.getSession().setAttribute("msg", "Deleted Successfully");
			}else{
				request.getSession().setAttribute("msg", "Sorry! Please try again Later");
			}
			response.sendRedirect("add-accommodation");
		}else{
			RequestDispatcher rd= context.getRequestDispatcher("/index.jsp");
		    rd.forward(request, response);		
		}		
	}
}

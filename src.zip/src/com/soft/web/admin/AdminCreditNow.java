package com.soft.web.admin;

import java.io.IOException;
import java.sql.Connection;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.ProfileDAO;
import com.soft.dao.RequestDAO;
import com.soft.model.Member;
import com.soft.model.RequestUser;
import com.soft.utility.ClearCache;

/**
 * Servlet implementation class AdminCreditNow
 */
@WebServlet("/admin-credit-now")
public class AdminCreditNow extends HttpServlet {
	private static final long serialVersionUID = 1L;
	RequestDAO rqDAO = new RequestDAO();
	ProfileDAO pfDAO = new ProfileDAO();
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		ServletContext context = getServletContext();
		RequestDAO rqDAO = new RequestDAO();
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		int reqID = 0;

		if(request.getSession().getAttribute("admin")!=null){
			
			
			RequestDispatcher rd= context.getRequestDispatcher("/pages/admin/withdrawal/add-income.jsp");
		    rd.forward(request, response);	
		}else{
			response.sendRedirect("index.jsp");	
		}
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		int i= 0;

		RequestUser ru = new RequestUser();
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		Member mb = null;
		if(request.getSession().getAttribute("admin")!=null){
			mb = (Member)request.getSession().getAttribute("admin");
		}
		
		String loginId = "";
		if(request.getParameter("loginId")!=null){
			loginId = request.getParameter("loginId");
		}
		
		Member m = pfDAO.getSilgleMemberDetailsByLoginID(loginId, con);
		
		
		if(m!=null){
		
		float amount=0;
		if(request.getParameter("withdrawalAmount")!=null){
			amount = Float.parseFloat(request.getParameter("withdrawalAmount"));
			ru.setAmount(amount);
		}
		if(request.getParameter("requestBy")!=null){
			ru.setRequestType(request.getParameter("requestBy"));
		}
		
		
		// check last pending transaction
		RequestDAO reqDAO = new RequestDAO();
		int pendingWithdrawals = reqDAO.getTotalWithdrawalAmount(m.getLoginID(), "pending", con);
		
		if(pendingWithdrawals>0){
			request.getSession().setAttribute("msg", "Sorry! Last withdrawal is pending..");
		}else{
		
//		     Random rm = new Random();
//		     int getNum = rm.nextInt();
//		     String ord = "CX"+getNum;
			
			ru.setMemberID(m.getLoginID());
			ru.setOrderID(request.getParameter("txnid"));
			ru.setStatus("CREDITED");
			ru.setWithdrawalType(request.getParameter("withdrawalType"));
			request.getSession().setAttribute("withReqData", ru);
			
			i= rqDAO.withdrawalRequest(ru, con);
			request.getSession().setAttribute("msg", "Withdrawal added successfully.");
		}
		
		response.sendRedirect("admin-credit-now");
		
		}else{
			request.getSession().setAttribute("msg", "Sorry! You have entered wrong ID.");
			response.sendRedirect("admin-credit-now");
		}
	}
}

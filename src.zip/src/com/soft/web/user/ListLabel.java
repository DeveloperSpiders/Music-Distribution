package com.soft.web.user;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.LabelDAO;
import com.soft.model.Label;
import com.soft.model.Member;
import com.soft.utility.ClearCache;

/**
 * Servlet implementation class AdminListVideos
 */
@WebServlet("/list-label")
public class ListLabel extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		ServletContext context = getServletContext();
		LabelDAO vDAO = new LabelDAO();
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		if(request.getSession().getAttribute("user")!=null){
			Member m = (Member)request.getSession().getAttribute("user");
			
			String status = "";
			if(request.getParameter("status")!=null && !request.getParameter("status").equals("")){
				status = request.getParameter("status");
			}
			
			if(status.equals("Approved")){
				ArrayList<Label> list = vDAO.getSingleBlogListByEntryBy(m.getLoginID(), "Approved", con) ;
				request.setAttribute("labelList", list);
				request.setAttribute("pageTitle", "Final Labels");
			}else if(status.equals("Other")){
				ArrayList<Label> list = vDAO.getSingleBlogListByEntryByNot(m.getLoginID(), "Approved", con) ;
				request.setAttribute("labelList", list);
				request.setAttribute("pageTitle", "Currection Labels");
			}else{
				ArrayList<Label> list = vDAO.getSingleBlogListByEntryBy(m.getLoginID(), con) ;
				request.setAttribute("labelList", list);
				request.setAttribute("pageTitle", "All Labels");
			}
			
			
			RequestDispatcher rd= context.getRequestDispatcher("/pages/user/label/list-label.jsp");
		    rd.forward(request, response);	
		}else{
			RequestDispatcher rd= context.getRequestDispatcher("/index.jsp");
		    rd.forward(request, response);		
		}
	}
}

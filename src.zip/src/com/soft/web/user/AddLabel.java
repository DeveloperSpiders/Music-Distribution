package com.soft.web.user;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.LabelDAO;
import com.soft.dao.CategoryDAO;
import com.soft.dao.KitDAO;
import com.soft.dao.VideoDAO;
import com.soft.model.Label;
import com.soft.model.Category;
import com.soft.model.Kit;
import com.soft.model.Member;
import com.soft.model.Video;
import com.soft.utility.ClearCache;
import com.soft.utility.Pagging;
import com.soft.utility.URLMasking;

/**
 * Servlet implementation class AddBlog
 */
@WebServlet("/add-label")
public class AddLabel extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CategoryDAO cDAO = new CategoryDAO();
	LabelDAO bDAO = new LabelDAO();
	VideoDAO vidDAO = new VideoDAO();
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		ServletContext context = getServletContext();
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		Pagging pg = new Pagging();
		int rowNo=0;
		
		if(request.getSession().getAttribute("user")!=null){
			
			
			RequestDispatcher rd= context.getRequestDispatcher("/pages/user/label/add-label.jsp");
			rd.forward(request, response);
		}else{
			RequestDispatcher rd= context.getRequestDispatcher("/index.jsp");
			rd.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		 ServletContext context = request.getServletContext();
		//cleared browser calling above class
		Label b = new Label();
		LabelDAO blDAO = new LabelDAO();
		URLMasking urlmsk = new URLMasking();
		if(request.getSession().getAttribute("user")!=null){
			Member m = (Member)request.getSession().getAttribute("user");
			
			Label bl = new Label();
			 int kitID = 0;
			String url = request.getServletPath();
			url = url.replace("/", "");
			
		  
				
			String[] kitIDArray = request.getParameterValues("kitID");
				
			String[] selectedpageURL = request.getParameterValues("pageURL");
			
			bl.setTitle(request.getParameter("title"));
			bl.setSubject(request.getParameter("subject"));
			 bl.setDescription(request.getParameter("description"));
			 bl.setTextUrl(request.getParameter("textUrl"));
			 bl.setEntryBy(m.getLoginID());
			 bl.setStatus("Awaiting");
			
			
				
				int i = 0;
						
						i = blDAO.addNewBlog(bl,con);
				
		
			if(i!=0){ 
				int id = blDAO.getLastImageBlogID(con);
				request.getSession().setAttribute("blogid", id);
				request.getSession().setAttribute("msg", "BLOG UPDATED SUCCESSFULLY");
				response.sendRedirect("upload-label-image");
			}else{
				request.getSession().setAttribute("msg", "SORRY! PLEASE TRY AGAIN LATER");
			}
		}else{
			RequestDispatcher rd = context.getRequestDispatcher("/index.jsp");
			rd.forward(request, response);
		}
	}
}

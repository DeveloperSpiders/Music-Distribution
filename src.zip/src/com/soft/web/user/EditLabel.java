package com.soft.web.user;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.LabelDAO;
import com.soft.dao.CategoryDAO;
import com.soft.dao.ChildCategoryDAO;
import com.soft.dao.SubCategoryDAO;
import com.soft.model.Label;
import com.soft.model.Category;
import com.soft.model.ChildCategory;
import com.soft.model.Member;
import com.soft.utility.ClearCache;
import com.soft.utility.DBConnection;
import com.soft.utility.Pagging;
import com.soft.utility.URLMasking;

/**
 * Servlet implementation class AddBlog
 */
@WebServlet("/edit-label")
public class EditLabel extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CategoryDAO cDAO = new CategoryDAO();
	LabelDAO bDAO = new LabelDAO();

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		ServletContext context = getServletContext();
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		Pagging pg = new Pagging();
		int id=0;
		
		if(request.getSession().getAttribute("user")!=null){
			
			Label blogSingle = bDAO.getSingleBlogByID(id, con);
			if(blogSingle!=null){
				request.setAttribute("blogSingle", blogSingle);
			}else{
				request.setAttribute("blogSingle", null);
			}
			
			RequestDispatcher rd= context.getRequestDispatcher("/pages/user/label/edit-label.jsp");
			rd.forward(request, response);
		}else{
			RequestDispatcher rd= context.getRequestDispatcher("/index.jsp");
			rd.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		 ServletContext context = request.getServletContext();
		//cleared browser calling above class
		Label b = new Label();
		LabelDAO blDAO = new LabelDAO();
		if(request.getSession().getAttribute("user")!=null){
			Member m = (Member)request.getSession().getAttribute("user");
			 Label bl = new Label();
			int  id=0;
			if(request.getParameter("id")!=null){
				id = Integer.parseInt(request.getParameter("id"));
			}
			bl.setId(Integer.parseInt(request.getParameter("id")));
			bl.setTitle(request.getParameter("title"));
			bl.setSubject(request.getParameter("subject"));
			 bl.setDescription(request.getParameter("description"));
			 bl.setTextUrl(request.getParameter("textUrl"));
			 bl.setEntryBy(m.getLoginID());
			 bl.setStatus("Awaiting");
			 
			int i = blDAO.updateBlogDetails(bl,con);
			if(i!=0){
				request.getSession().setAttribute("msg", "URL SAVED SUCCESSFULLY");
				request.getSession().setAttribute("blogid", i);
			}
			response.sendRedirect("upload-label-images");  
		}else{
			RequestDispatcher rd = context.getRequestDispatcher("/index.jsp");
			rd.forward(request, response);
		}
	}
}

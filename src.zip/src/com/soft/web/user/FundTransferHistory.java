package com.soft.web.user;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.FundWalletDAO;
import com.soft.dao.RequestDAO;
import com.soft.model.Member;
import com.soft.model.Payment;
import com.soft.utility.ClearCache;

/**
 * Servlet implementation class FundTransferHistory
 */
@WebServlet("/fund-transfer-history")
public class FundTransferHistory extends HttpServlet {
	private static final long serialVersionUID = 1L;
	RequestDAO rqDAO = new RequestDAO();
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		ServletContext context = getServletContext();
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
//		PinAmountTransferDAO patDAO = new PinAmountTransferDAO();
		if(request.getSession().getAttribute("user")!=null){
			Member m = (Member)request.getSession().getAttribute("user");
//			ResultSet rs = patDAO.getTransferPinAmountHistory(m.getLoginID());
//			request.setAttribute("fundTransferHistory", rs);
			FundWalletDAO pmDAO = new FundWalletDAO();
			ArrayList<Payment> al = pmDAO.getSilgleMemberFundInWalletDetails(m.getLoginID(), con);
			request.setAttribute("fundTransferHistory", al);
			
			
			float creditFund = pmDAO.getSilgleMemberFundInWalletAmount(m.getLoginID(), "CREDIT", con);
			request.setAttribute("creditFund", creditFund);
			
			float debitFund = pmDAO.getSilgleMemberFundInWalletAmount(m.getLoginID(), "DEBIT", con);
			request.setAttribute("debitFund", debitFund);
			
			float withdrawnAmount = rqDAO.getTotalWithdrawalAmount(m.getLoginID(), con);
			request.setAttribute("withdrawnAmount", withdrawnAmount);
			
			RequestDispatcher rd= context.getRequestDispatcher("/pages/user/donation/fund-transfer-history.jsp");
			rd.forward(request, response);
		}
	}
}

package com.soft.web.user;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.VideoDAO;
import com.soft.model.Gallery;
import com.soft.model.Member;
import com.soft.model.Video;
import com.soft.utility.ClearCache;
import com.soft.utility.DBConnection;
import com.soft.utility.Pagging;

/**
 * Servlet implementation class AdminListVideos
 */
@WebServlet("/list-videos")
public class ListVideos extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		ServletContext context = getServletContext();
		VideoDAO vDAO = new VideoDAO();
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		if(request.getSession().getAttribute("user")!=null){
			Member m = (Member)request.getSession().getAttribute("user");
			
			String status = "";
			if(request.getParameter("status")!=null && !request.getParameter("status").equals("")){
				status = request.getParameter("status");
			}
			
			if(status.equals("Approved")){
				ArrayList<Video> list = vDAO.getSilgleMemberVideoAccountByStatus(m.getLoginID(), "Approved", con) ;
				request.setAttribute("videoList", list);
				request.setAttribute("pageTitle", "Final Release");
			}else if(status.equals("Other")){
				ArrayList<Video> list = vDAO.getSilgleMemberVideoAccountByNotStatus(m.getLoginID(), "Approved", con) ;
				request.setAttribute("videoList", list);
				request.setAttribute("pageTitle", "Currection Items");
			}else{
				ArrayList<Video> list = vDAO.getSilgleMemberVideoAccountDetails(m.getLoginID(), con) ;
				request.setAttribute("videoList", list);
				request.setAttribute("pageTitle", "All Items");
			}
			
			
			RequestDispatcher rd= context.getRequestDispatcher("/pages/user/videos/list-video.jsp");
		    rd.forward(request, response);	
		}else{
			RequestDispatcher rd= context.getRequestDispatcher("/index.jsp");
		    rd.forward(request, response);		
		}
	}
}

package com.soft.web.user;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.FundWalletDAO;
import com.soft.dao.LabelDAO;
import com.soft.dao.ProfileDAO;
import com.soft.dao.RequestDAO;
import com.soft.dao.VideoDAO;
import com.soft.model.Label;
import com.soft.model.Member;
import com.soft.model.Video;
import com.soft.utility.ClearCache;

/**
 * Servlet implementation class UserHome
 */
@WebServlet("/user-home")
public class UserHome extends HttpServlet {
	private static final long serialVersionUID = 1L;
		ProfileDAO pfDAO = new ProfileDAO();
		VideoDAO vDAO = new VideoDAO();
		LabelDAO lDAO = new LabelDAO();
		FundWalletDAO fwDAO = new FundWalletDAO();
		RequestDAO rqDAO = new RequestDAO();
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	@SuppressWarnings("unchecked")
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ServletContext context = getServletContext();
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		
		String pages = "/welcome";
		if(request.getSession().getAttribute("user")!=null){
			Member mbb = (Member)request.getSession().getAttribute("user");
			
			Member mb = pfDAO.getSilgleMemberDetailsByLoginID(mbb.getLoginID(), con);
			
			request.getSession().setAttribute("user", mb);
			//our branch office details
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~CART START HERE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/		
			ArrayList<Video> list = vDAO.getSilgleMemberVideoAccountDetails(mb.getLoginID(), 5, con) ;
			request.setAttribute("videoList", list);
			
			
			ArrayList<Label> labelList = lDAO.getBlogList(mb.getLoginID(), 5, con) ;
			request.setAttribute("labelList", labelList);
			
			
			float creditFund = fwDAO.getSilgleMemberFundInWalletAmount(mb.getLoginID(), "CREDIT", con);
			request.setAttribute("creditFund", creditFund);
			float debitFund = fwDAO.getSilgleMemberFundInWalletAmount(mb.getLoginID(), "DEBIT", con);
			request.setAttribute("debitFund", debitFund);
			
			float withdrawnAmount = rqDAO.getTotalWithdrawalAmount(mb.getLoginID(), con);
			request.setAttribute("withdrawnAmount", withdrawnAmount);
			
			request.getSession().setAttribute("fundWallet", creditFund-(debitFund+withdrawnAmount));
			
						 
			pages = "/pages/user/home/home.jsp";
		 }
		
		RequestDispatcher rd= context.getRequestDispatcher(pages);
		rd.forward(request, response);	
		}

}
	

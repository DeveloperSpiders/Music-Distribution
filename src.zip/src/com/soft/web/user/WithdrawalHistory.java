package com.soft.web.user;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.FundWalletDAO;
import com.soft.dao.RequestDAO;
import com.soft.model.Member;
import com.soft.model.RequestUser;
import com.soft.utility.ClearCache;

/**
 * Servlet implementation class Withdrawal
 */
@WebServlet("/withdrawal-history")
public class WithdrawalHistory extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	FundWalletDAO fwDAO = new FundWalletDAO();
	RequestDAO rqDAO = new RequestDAO();
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		ServletContext context = getServletContext();
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		Member m = null;
		if(request.getSession().getAttribute("user")!=null){
			m = (Member)request.getSession().getAttribute("user");
			
			
			
			
			
//			ResultSet withdrawalList = rqDAO.getPendingWithdrawalRequestListsFilter(m.getLoginID(), null, null, null, null, con);
			ArrayList<RequestUser> withdrawalList = rqDAO.getPendingWithdrawalRequestListForBulk(m.getLoginID(), con);
			request.setAttribute("withdrawalList", withdrawalList);
			
				
				float creditFund = fwDAO.getSilgleMemberFundInWalletAmount(m.getLoginID(), "CREDIT", con);
				float debitFund = fwDAO.getSilgleMemberFundInWalletAmount(m.getLoginID(), "DEBIT", con);
				
				float withdrawnAmount = rqDAO.getTotalWithdrawalAmount(m.getLoginID(), con);
				request.setAttribute("withdrawnAmount", withdrawnAmount);
				
				request.getSession().setAttribute("fundWallet", creditFund-(debitFund+withdrawnAmount));
				
				
				RequestDispatcher rd= context.getRequestDispatcher("/pages/user/withdrawal/withdrawal-history.jsp");
				rd.forward(request, response);	
					
					
		}else{
			response.sendRedirect("index.jsp");
		}
	}

}

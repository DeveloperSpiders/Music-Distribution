package com.soft.web.user;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.LoginDAO;
import com.soft.model.Member;
import com.soft.utility.ClearCache;
import com.soft.utility.DBConnection;
import com.soft.utility.SendSMS;

/**
 * Servlet implementation class ChangePassword
 */
@WebServlet("/change-password")
public class ChangePassword extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		Member m = null;
		LoginDAO loginDAO = new LoginDAO();
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		if(request.getSession().getAttribute("user")!=null){
		String oldPassword = request.getParameter("oldPassword");
		String newPassword = request.getParameter("newPassword");
		String confirmPassword = request.getParameter("confirmPassword");
		if(request.getSession().getAttribute("user")!=null){
		 m = (Member)request.getSession().getAttribute("user");
		}
		if(m.getPassword().equals(oldPassword) && newPassword.equals(confirmPassword)){
			int i = loginDAO.changePassword(newPassword, m.getLoginID(), m.getId(), con);
			if(i!=0){
			   String msg = "Your Password Changed Successfully New Password :"+confirmPassword+" associated with Member ID: "+m.getLoginID()+".";
			   SendSMS ss = new SendSMS();
		       int x = ss.sendSMSToMember(request, m, msg);
		       System.out.println(x);
				request.getSession().setAttribute("msg", "Password Changed Successfully");
			}
		}else{
			request.getSession().setAttribute("msg", "Sorry! Please Enter Password Properly");
			
		}
		response.sendRedirect("view-profile");		
	}else{
		response.sendRedirect("view-profile");		
	}						
 }
}

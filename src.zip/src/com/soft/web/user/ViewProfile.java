package com.soft.web.user;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.ProfileDAO;
import com.soft.model.Member;
import com.soft.utility.ClearCache;
import com.soft.utility.DBConnection;

/**
 * Servlet implementation class EditProfile
 */
@WebServlet("/view-profile")
public class ViewProfile extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ProfileDAO pfDAO = new ProfileDAO();
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ServletContext context = getServletContext();
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		// already available into session
		String pages = "index.jsp";
		if(request.getSession().getAttribute("user")!=null){
			Member m = (Member)request.getSession().getAttribute("user");
			Member mp =  pfDAO.getSilgleMemberDetailsByLoginID(m.getLoginID(), con);
            request.getSession().setAttribute("user", mp);
            
	            RequestDispatcher rd= context.getRequestDispatcher("/pages/user/profile/view-profile.jsp");
				rd.forward(request, response);	
            
		}else{
			RequestDispatcher rd= context.getRequestDispatcher("/index.jsp");
			rd.forward(request, response);		
		}										
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		String pages = "index.jsp";
		Member m = new Member();
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		ProfileDAO pfDAO = new ProfileDAO();
		if(request.getSession().getAttribute("user")!=null){
			Member mb = (Member)request.getSession().getAttribute("user");
			
			
			String accountNo = request.getParameter("accountNo");
			String ifsc = request.getParameter("ifsc");
			String bankName = request.getParameter("bankName");
			String googlePay = request.getParameter("googlePay");
			String phonePe = request.getParameter("phonePe");
			String payTm = request.getParameter("payTm");
			String upiId = request.getParameter("upiId");
			
			m.setId(mb.getId());
			m.setAddress(request.getParameter("address"));
			m.setCity(request.getParameter("city"));
			m.setContactNumber(request.getParameter("contactNumber"));
			m.setEmail(request.getParameter("email"));
			m.setFirstName(request.getParameter("firstName"));
			m.setLastName(request.getParameter("lastName"));
			m.setLoginID(request.getParameter("memberId"));
			m.setPinCode(request.getParameter("pinCode"));
			m.setState(request.getParameter("state"));
			
			
			
			
			int i = pfDAO.updateMemberDetails(m, con);
			if(i!=0){
				Member mm = pfDAO.getSilgleMemberDetails(m.getId(), con);
				request.getSession().setAttribute("user", mm);
				request.getSession().setAttribute("msg", "Profile Updated Successfully");
				pages = "view-profile";
			}else{
				pages = "view-profile";
				request.getSession().setAttribute("msg", "Please try again Later");
			}
			response.sendRedirect(pages);
		}else{
			response.sendRedirect("index.jsp");
		}
	}
	
}

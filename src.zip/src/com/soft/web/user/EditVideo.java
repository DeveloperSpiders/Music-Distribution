package com.soft.web.user;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.CategoryDAO;
import com.soft.dao.VideoDAO;
import com.soft.model.Category;
import com.soft.model.Member;
import com.soft.model.Video;
import com.soft.utility.ClearCache;
import com.soft.utility.Pagging;

/**
 * Servlet implementation class AddVideoGallery
 */
@WebServlet("/edit-video")
public class EditVideo extends HttpServlet {
	private static final long serialVersionUID = 1L;
	VideoDAO vdDAO = new VideoDAO();
	CategoryDAO ctDAO = new CategoryDAO();

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		ServletContext context = getServletContext();
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		//-------------------------------------------------------------------------
		if(request.getSession().getAttribute("user")!=null){
			ArrayList<Category> list = ctDAO.selectCategoryList(con);
			request.setAttribute("categoryList", list);
			
			int id = 0;
			
			if(request.getParameter("id")!=null && !request.getParameter("id").equals("")){
				id = Integer.parseInt(request.getParameter("id"));
			}
			
			Video video = vdDAO.getSilgleVideoAccountDetails(id, con);
			request.setAttribute("video", video);
			
			if(video.getType().equals("audio")){
				RequestDispatcher rd= context.getRequestDispatcher("/pages/user/videos/edit-audio.jsp");
			    rd.forward(request, response);
			}
			if(video.getType().equals("video")){
				RequestDispatcher rd= context.getRequestDispatcher("/pages/user/videos/edit-video.jsp");
			    rd.forward(request, response);
			}
			if(video.getType().equals("film")){
				RequestDispatcher rd= context.getRequestDispatcher("/pages/user/videos/edit-film.jsp");
			    rd.forward(request, response);
			}
			
		}else{
			RequestDispatcher rd= context.getRequestDispatcher("/index.jsp");
		    rd.forward(request, response);		
		}							
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}

		ServletContext context = getServletContext();
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		//-------------------------------------------------------------------------
		if(request.getSession().getAttribute("user")!=null){
			Member m = (Member)request.getSession().getAttribute("user");
			Video v= new Video();
			
			int id = 0;
			
			if(request.getParameter("id")!=null && !request.getParameter("id").equals("")){
				id = Integer.parseInt(request.getParameter("id"));
			}
			
			String category = "";
			if(request.getParameter("category")!=null){
				category = request.getParameter("category");
			}
			String title = "";
			if(request.getParameter("title")!=null){
				title = request.getParameter("title");
			}
			String singer = "";
			if(request.getParameter("singer")!=null){
				singer = request.getParameter("singer");
			}
			String musicDirector = "";
			if(request.getParameter("musicDirector")!=null){
				musicDirector = request.getParameter("musicDirector");
			}
			String lyrics = "";
			if(request.getParameter("lyrics")!=null){
				lyrics = request.getParameter("lyrics");
			}
			String genre = "";
			if(request.getParameter("genre")!=null){
				genre = request.getParameter("genre");
			}
			String mood = "";
			if(request.getParameter("mood")!=null){
				mood = request.getParameter("mood");
			}
			String label = "";
			if(request.getParameter("label")!=null){
				label = request.getParameter("label");
			}
			String publisher = "";
			if(request.getParameter("publisher")!=null){
				publisher = request.getParameter("publisher");
			}
			String language = "";
			if(request.getParameter("language")!=null){
				language = request.getParameter("language");
			}
			String isrc = "";
			if(request.getParameter("isrc")!=null){
				isrc = request.getParameter("isrc");
			}
			String crbtTitle = "";
			if(request.getParameter("crbtTitle")!=null){
				crbtTitle = request.getParameter("crbtTitle");
			}
			String crbtTime = "";
			if(request.getParameter("crbtTime")!=null){
				crbtTime = request.getParameter("crbtTime");
			}
			String trackDuration = "";
			if(request.getParameter("trackDuration")!=null){
				trackDuration = request.getParameter("trackDuration");
			}
			String videoDirector = "";
			if(request.getParameter("videoDirector")!=null){
				videoDirector = request.getParameter("videoDirector");
			}
			String starCast = "";
			if(request.getParameter("starCast")!=null){
				starCast = request.getParameter("starCast");
			}
			String releasingDate = "";
			if(request.getParameter("releasingDate")!=null){
				releasingDate = request.getParameter("releasingDate");
			}
			
			String description = "";
			if(request.getParameter("description")!=null){
				description = request.getParameter("description");
			}
			
			String filmSynopsis = "";
			if(request.getParameter("filmSynopsis")!=null){
				filmSynopsis = request.getParameter("filmSynopsis");
			}
			
			String contentRating = "";
			if(request.getParameter("contentRating")!=null){
				contentRating = request.getParameter("contentRating");
			}
			
			
			Video video = vdDAO.getSilgleVideoAccountDetails(id, con);
			
			if(video!=null && !video.getStatus().equals("") && !video.getStatus().equals("Approved")){
			
			
				v.setId(id);
				v.setCategory(category);
				v.setTitle(title);
				v.setSinger(singer);
				v.setMusicDirector(musicDirector);
				v.setLyrics(lyrics);
				v.setGenre(genre);
				v.setMood(mood);
				v.setLabel(label);
				v.setPublisher(publisher);
				v.setLanguage(language);
				v.setIsrc(isrc);
				v.setCrbtTitle(crbtTitle);
				v.setCrbtTime(crbtTime);
				v.setDuration(trackDuration);
				v.setVideoDirector(videoDirector);
				v.setStarCast(starCast);
				v.setReleasingDate(releasingDate);
				v.setDescription(description);
				v.setEntryBy(m.getLoginID());
				v.setStatus("Awaiting");
				
				v.setFilmSynopsis(filmSynopsis);
				v.setContentRating(contentRating);
				
				
				int i = vdDAO.updateVideo(v, con);
				if(i!=0){
					request.getSession().setAttribute("lstID", id);
					request.getSession().setAttribute("msg", "Video Updated Succesfully!");
					response.sendRedirect("edit-video?id="+id);
				}else{
					request.getSession().setAttribute("msg", "Sorry! Please Try Again Later");
					response.sendRedirect("edit-video?id="+id);
				}
			
			}else{
				request.getSession().setAttribute("msg", "Sorry! This item can not be update.");
				response.sendRedirect("user-home");
			}
			
		}
	}
}

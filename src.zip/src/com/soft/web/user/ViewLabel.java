package com.soft.web.user;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.LabelDAO;
import com.soft.dao.CategoryDAO;
import com.soft.dao.ChildCategoryDAO;
import com.soft.dao.SubCategoryDAO;
import com.soft.model.Label;
import com.soft.model.Category;
import com.soft.model.ChildCategory;
import com.soft.model.Member;
import com.soft.utility.ClearCache;
import com.soft.utility.DBConnection;
import com.soft.utility.Pagging;
import com.soft.utility.URLMasking;

/**
 * Servlet implementation class AddBlog
 */
@WebServlet("/view-label")
public class ViewLabel extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CategoryDAO cDAO = new CategoryDAO();
	LabelDAO bDAO = new LabelDAO();

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		ServletContext context = getServletContext();
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		Pagging pg = new Pagging();
		int id=0;
		
		if(request.getSession().getAttribute("user")!=null){
			
			
			if(request.getParameter("id")!=null && !request.getParameter("id").equals("")){
				id = Integer.parseInt(request.getParameter("id"));
			}
			
			Label blogSingle = bDAO.getSingleBlogByID(id, con);
			if(blogSingle!=null){
				request.setAttribute("blogSingle", blogSingle);
			}else{
				request.setAttribute("blogSingle", null);
			}
			
			RequestDispatcher rd= context.getRequestDispatcher("/pages/user/label/view-label.jsp");
			rd.forward(request, response);
		}else{
			RequestDispatcher rd= context.getRequestDispatcher("/index.jsp");
			rd.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
}

package com.soft.web.visitor;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.AccommodationDAO;
import com.soft.dao.CommentDAO;
import com.soft.dao.GalleryDAO;
import com.soft.dao.TravelDAO;
import com.soft.model.Accommodation;
import com.soft.model.Comment;
import com.soft.model.Gallery;
import com.soft.model.Travel;
import com.soft.utility.ClearCache;

/**
 * Servlet implementation class GalleryFillterImages
 */
@WebServlet("/travel-single")
public class TravelSingle extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String album = null;
	CommentDAO commentDAO = new CommentDAO();
	GalleryDAO gDAO = new GalleryDAO();
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}

		ServletContext context = getServletContext();
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		
		TravelDAO tDAO = new TravelDAO();
		AccommodationDAO aDAO = new AccommodationDAO();
		int  id=0;
		if(request.getParameter("id")!=null){
			id = Integer.parseInt(request.getParameter("id"));
		}
			Travel travelSingle = tDAO.getBlogById(id, con);
			request.setAttribute("travelSingle", travelSingle);
			request.setAttribute("travelName", travelSingle.getSubjectLine());
			
			ArrayList<Accommodation>  acl = aDAO.getBannerFilterListWithLimit(null, travelSingle.getState(), travelSingle.getDistrict(), travelSingle.getCity(), 6, con);
			request.setAttribute("relatedAccommodation", acl);
			
			int viewCount = travelSingle.getViewCount() + 1;
			tDAO.updateBlogViewCount(viewCount, id, con);
			
			ArrayList<Travel>  al = tDAO.getBannerFilterListWithLimit(travelSingle.getTravelCategory(), null, null, null, 4, con);
			request.setAttribute("relatedTravel", al);
			
			ArrayList<Comment> commentList= commentDAO.getCommentListForUser(id, "Travel", con);
//			String landmark =companyDAO.getLandmarkName(company.getLandmark());
			int NumberComment = commentDAO.getTotalCommentID(id, con);
			int totalRate = commentDAO.getTotalRateID(id, con);
			
			if(NumberComment>0){
				request.setAttribute("averageRate", (totalRate/NumberComment));
			}else{
				request.setAttribute("averageRate", 5);
			}
			
			request.setAttribute("NumberComment", NumberComment);
			
			if(commentList!=null)
			{
				request.setAttribute("commentList", commentList);	
			}
			
			ArrayList<Travel> mothViewed = tDAO.getBannerFilterListMostViewed(4, con);
			request.setAttribute("mothViewed", mothViewed);
			
			ArrayList<Gallery> galleryImages = gDAO.getImageGalleryFilterList(travelSingle.getName(), 6, con);
			request.setAttribute("galleryImages", galleryImages);
		
		RequestDispatcher rd= context.getRequestDispatcher("/travel-single.jsp");
		rd.forward(request, response);
		
	}
}
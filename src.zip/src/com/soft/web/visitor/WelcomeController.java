package com.soft.web.visitor;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.AccommodationDAO;
import com.soft.dao.BannerDAO;
import com.soft.dao.LabelDAO;
import com.soft.dao.CategoryDAO;
import com.soft.dao.CommentDAO;
import com.soft.dao.ContactUsDAO;
import com.soft.dao.TravelDAO;
import com.soft.dao.VideoAlbumDAO;
import com.soft.model.Banner;
import com.soft.model.Category;
import com.soft.model.Comment;
import com.soft.model.ContactUs;
import com.soft.model.Travel;
import com.soft.model.VideoAlbumName;
import com.soft.utility.ClearCache;
import com.soft.utility.Pagging;

/**
 * Servlet implementation class WelcomeController
 */
@WebServlet("/welcome")
public class WelcomeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CategoryDAO cDAO = new CategoryDAO();
	String ctg = null;
	BannerDAO bnrDAO = new BannerDAO();
	LabelDAO bDAO = new LabelDAO();
	
	AccommodationDAO acDAO = new AccommodationDAO();
	TravelDAO tDAO = new TravelDAO();
	CommentDAO cmDAO = new CommentDAO();
//	CategoryDAO ctgDAO = new CategoryDAO();
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ServletContext context = getServletContext();
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}

		try{
		}catch (Exception e) {
			e.printStackTrace();
		}
		Pagging pg = new Pagging();
		int rowNo=0;
		
		//cleared browser calling above class
		if(request.getSession().getAttribute("kitList")==null){
			//manage Category and Sub Category
		}
		if(request.getSession().getAttribute("sclhm1")==null){
			//manage Category and Sub Category
//			HashMap<String, HashMap<String, ArrayList<ChildCategory>>> sclhm1 = ctgDAO.selectCompleteMenuTriLayer(con);
//			request.getSession().setAttribute("sclhm1", sclhm1);
		}
		int lstBanner = bnrDAO.getLastImageBannerID(con);
		ArrayList<Banner> al = bnrDAO.getImageBannerListForDisplayAll(con);
		request.setAttribute("banner", al);

		
		ContactUsDAO cuDAO = new ContactUsDAO();
		ArrayList<ContactUs> contactlist = cuDAO.getSilgleContactDetails(0, con);
		request.getSession().setAttribute("ContactDetails2", contactlist);
		
		VideoAlbumDAO vbDAO = new VideoAlbumDAO();
		ArrayList<VideoAlbumName> videolist = vbDAO.selectVideoAlbumList(con);
		request.getSession().setAttribute("videoalbumlist", videolist);
		
		ArrayList<Banner> bannerList = bnrDAO.getImageBannerList(con);
		if(bannerList!=null){
			request.setAttribute("bannerList", bannerList);
		}else{
			request.setAttribute("bannerList", null);
		}
		
		ArrayList<Category> categorylist = cDAO.selectCategoryList(con);
		request.setAttribute("categorylist", categorylist);
		
		ArrayList<Comment> commentList= cmDAO.getCommentListForHomePage(con);
		request.setAttribute("commentList", commentList);
		
		ArrayList<Travel> districtList =  tDAO.getTravelDistrictList(5, con);
		request.setAttribute("districtList", districtList);
		
		int j = 0;
		String dList = "";
		for(Travel t:districtList){
			j++;
			if(j==1){
				dList += "'"+t.getDistrict()+"'";
			}else{
				dList += ", '"+t.getDistrict()+"'";
			}
		}
		
		ArrayList<Travel> travelList =  tDAO.getBannerFilterListWithLimit(dList, null, null, null, null, 30, con);
		request.setAttribute("travelList", travelList);
		
		ArrayList<Travel> cityList  =  tDAO.getTravelCityList(8, con);
		request.setAttribute("cityList", cityList);
		
		RequestDispatcher rd= context.getRequestDispatcher("/welcome.jsp");
		rd.forward(request, response);
	}
}

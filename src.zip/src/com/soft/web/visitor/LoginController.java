package com.soft.web.visitor;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.CategoryDAO;
import com.soft.dao.ContactUsDAO;
import com.soft.dao.LoginDAO;
import com.soft.dao.ProfileDAO;
import com.soft.model.ContactUs;
import com.soft.model.Login;
import com.soft.model.Member;
import com.soft.utility.ClearCache;
import com.soft.utility.DBConnection;

/**
 * Servlet implementation class LoginController
 */
@WebServlet("/login")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CategoryDAO ctgDAO = new CategoryDAO();
	ProfileDAO pfDAO = new ProfileDAO();
	LoginDAO loginDAO = new LoginDAO();
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		ServletContext context = getServletContext();
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
			RequestDispatcher rd= context.getRequestDispatcher("/login.jsp");
		    rd.forward(request, response);	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		
		Login login = new Login();
		  login.setEmailID(request.getParameter("email").toUpperCase());
		  login.setPassword(request.getParameter("password"));
//		  Date date = new Date();
		  String pages ="";
//		  SimpleDateFormat sm = new SimpleDateFormat("yyyy-MM-dd");
		  	Member m = loginDAO.memberLogin(login, con);
				if(m!=null){
					if(m.getLoginID().equals("ADMIN")){
						request.getSession().setAttribute("admin", m);
					}else{
						request.getSession().setAttribute("user", m);
					}
					//THIS IS MENU MANAGEMENT
//					long startdate = user.getEntryDate().getTime();
//					long curDat = date.getTime();
//					long  diff = curDat - startdate;
//					long diffDays = diff / (24 * 60 * 60 * 1000);
					/*if(diffDays<20)
					{*/
//						if(m.getLoginID().equals("admin") || m.getLoginID().equals("ADMIN")){
//						pages="admin-home";
//						}else{
								if(m.getLoginID().equals("ADMIN")){
									pages="admin-home";
								}else{
									pages="user-home";
								}
//						}
					/*}else {
						request.getSession().setAttribute("msg", "Your Software Has Expired. Please Renew");
						pages="/index.jsp";
					}*/
				}
				else{	
					request.getSession().setAttribute("msg", "<span style='color:red;'>You Entered Wrong UserID or Password.? Please Try Again</span>");
					pages="login";
				}
				response.sendRedirect(pages);
			}
	}

package com.soft.web.visitor;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.TravelCategoryDAO;
import com.soft.dao.TravelDAO;
import com.soft.model.Travel;
import com.soft.model.TravelCategory;
import com.soft.utility.ClearCache;
import com.soft.utility.DBConnection;
import com.soft.utility.Pagging;

/**
 * Servlet implementation class GalleryFillterImages
 */
@WebServlet("/all-travel")
public class AllTravel extends HttpServlet {
	private static final long serialVersionUID = 1L;
//	TravelDAO tDAO = new TravelDAO();
	TravelCategoryDAO tcDAO = new TravelCategoryDAO();
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}

		ServletContext context = getServletContext();
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		
		ArrayList<TravelCategory> travelCategoryList =  tcDAO.selectCategoryList(con);
		request.setAttribute("travelCategoryList", travelCategoryList);
		
		/*ArrayList<Travel> travelList = tDAO.getBannerFilterList(null, null, null, null, con);
		request.setAttribute("travelList", travelList);*/
			
		
		RequestDispatcher rd= context.getRequestDispatcher("/all-travel.jsp");
		rd.forward(request, response);
		
	}
}
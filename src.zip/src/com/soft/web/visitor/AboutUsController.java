package com.soft.web.visitor;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.ContactUsDAO;
import com.soft.model.ContactUs;
import com.soft.utility.ClearCache;
import com.soft.utility.DBConnection;

/**
 * Servlet implementation class AboutUsController
 */
@WebServlet("/about-us")
public class AboutUsController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ServletContext context = getServletContext();
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		Connection con= null;
		try{
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		
		RequestDispatcher rd= context.getRequestDispatcher("/about-us.jsp");
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}

package com.soft.web.visitor;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.ContactUsDAO;
import com.soft.dao.VisitorContactDAO;
import com.soft.model.ContactUs;
import com.soft.model.Member;
import com.soft.model.VisitorContact;
import com.soft.utility.ClearCache;
import com.soft.utility.DBConnection;
import com.soft.utility.Pagging;

/**
 * Servlet implementation class ContactUsController
 */
@WebServlet("/contact-us")
public class ContactUsController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	VisitorContactDAO cuDAO = new VisitorContactDAO();

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}

		ServletContext context = getServletContext();
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		int qsv=0;
		RequestDispatcher rd= context.getRequestDispatcher("/contact.jsp");
		rd.forward(request, response);
	}

/**
 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
 */
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}

	ClearCache cc = new ClearCache();
	cc.clearBrowserCache(response);
	VisitorContact vc = new VisitorContact();
		
		vc.setName(request.getParameter("name"));
		vc.setEmail(request.getParameter("email"));
		vc.setContact(request.getParameter("contact"));
		vc.setMessage(request.getParameter("message"));
		vc.setEntryBy(request.getParameter("name"));
		int i= cuDAO.addVisitorContact(vc, con);
		if(i!=0){
			request.getSession().setAttribute("msg", "Message Send Succesfully.");
		}else{
			request.getSession().setAttribute("msg", "Sorry! please try again later.");
		}
		response.sendRedirect("contact-us");
	}
}

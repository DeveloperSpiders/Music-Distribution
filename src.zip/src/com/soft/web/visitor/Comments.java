package com.soft.web.visitor;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.CommentDAO;
import com.soft.model.Comment;
import com.soft.utility.DBConnection;

/**
 * Servlet implementation class CommentController
 */
@WebServlet("/comment")
public class Comments extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}	ServletContext context = getServletContext();
		
			RequestDispatcher rd= context.getRequestDispatcher("/pages/admin/account/Login.jsp");
			rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		String page = "index.jsp";
		//ServletContext context = getServletContext();
		Comment comment = new Comment();
		CommentDAO commentDAO = new CommentDAO();
		int Id =0;
		if(request.getParameter("Id")!=null && request.getParameter("Id")!="")
		{
			Id = Integer.parseInt(request.getParameter("Id"));		
			comment.setCompanyId(Id);
		}
		else
		{
			comment.setCompanyId(0);
		}
		if(request.getParameter("page")!=null && request.getParameter("page")!="")
		{
			page = request.getParameter("page");		
		}
		
		comment.setName(request.getParameter("name"));
		comment.setContactNo(request.getParameter("contact"));
		comment.setEmailId(request.getParameter("emailId"));
		comment.setComment(request.getParameter("comment"));
		comment.setType(request.getParameter("type"));
		comment.setStatus("0");
		int com = Integer.parseInt(request.getParameter("rating"));
		comment.setRating((com));
		commentDAO.addNewComment(comment, con);
		response.sendRedirect(page+"?id="+Id);
	
		
		/*RequestDispatcher rd= context.getRequestDispatcher("/Company?page=companyDetail&id="+companyId);
		rd.forward(request, response);*/
		
		
	}

}

package com.soft.web.visitor;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.ContactUsDAO;
import com.soft.dao.VideoAlbumDAO;
import com.soft.dao.VideoDAO;
import com.soft.model.ContactUs;
import com.soft.model.Gallery;
import com.soft.model.Video;
import com.soft.model.VideoAlbumName;
import com.soft.utility.ClearCache;
import com.soft.utility.DBConnection;
import com.soft.utility.Pagging;

/**
 * Servlet implementation class VideoGalleryController
 */
@WebServlet("/video-gallery")
public class VideoGalleryController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	VideoAlbumDAO vbDAO = new VideoAlbumDAO();
	String album = null;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}

		ServletContext context = getServletContext();
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		
		VideoDAO gDAO = new VideoDAO();
		if(request.getParameter("album")!=null){
			album =request.getParameter("album");
		}else{
			album = null;
		}
		ArrayList<Video> galleryImages = gDAO.getVideoFilterList(album, con);
		request.setAttribute("videoList", galleryImages);
		RequestDispatcher rd= context.getRequestDispatcher("/video-gallery.jsp");
		rd.forward(request, response);
	}
}

package com.soft.web.visitor;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.AccommodationDAO;
import com.soft.dao.CommentDAO;
import com.soft.dao.GalleryDAO;
import com.soft.model.Accommodation;
import com.soft.model.Comment;
import com.soft.model.Gallery;
import com.soft.model.Travel;
import com.soft.utility.ClearCache;
import com.soft.utility.DBConnection;

/**
 * Servlet implementation class GalleryFillterImages
 */
@WebServlet("/accommodation-single")
public class AccommodationSingle extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String album = null;
	CommentDAO commentDAO = new CommentDAO();
	GalleryDAO gDAO = new GalleryDAO();
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}

		ServletContext context = getServletContext();
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		
		AccommodationDAO tDAO = new AccommodationDAO();
		int  id=0;
		if(request.getParameter("id")!=null){
			id = Integer.parseInt(request.getParameter("id"));
		}
			Accommodation accommodationSingle = tDAO.getBlogById(id, con);
			request.setAttribute("accommodationSingle", accommodationSingle);
			request.setAttribute("accommodationName", accommodationSingle.getSubjectLine());
			
			int viewCount = accommodationSingle.getViewCount() + 1;
			tDAO.updateBlogViewCount(viewCount, id, con);
			
			ArrayList<Accommodation>  al = tDAO.getBannerFilterListWithLimit(accommodationSingle.getAccommodationCategory(), null, null, null, 4, con);
			request.setAttribute("relatedAccommodation", al);
			
			ArrayList<Comment> commentList= commentDAO.getCommentListForUser(id, "Accommodation", con);
//			String landmark =companyDAO.getLandmarkName(company.getLandmark());
			int NumberComment = commentDAO.getTotalCommentID(id, con);
			int totalRate = commentDAO.getTotalRateID(id, con);
			
			if(NumberComment>0){
				request.setAttribute("averageRate", (totalRate/NumberComment));
			}else{
				request.setAttribute("averageRate", 5);
			}
			
			request.setAttribute("NumberComment", NumberComment);
			
			if(commentList!=null)
			{
				request.setAttribute("commentList", commentList);	
			}
			
			ArrayList<Accommodation> mothViewed = tDAO.getBannerFilterListMostViewed(4, con);
			request.setAttribute("mothViewed", mothViewed);
			
			ArrayList<Gallery> galleryImages = gDAO.getImageGalleryFilterList(accommodationSingle.getName(), 6, con);
			request.setAttribute("galleryImages", galleryImages);
		
		RequestDispatcher rd= context.getRequestDispatcher("/accommodation-single.jsp");
		rd.forward(request, response);
		
	}
}
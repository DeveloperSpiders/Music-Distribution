package com.soft.web.visitor;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.soft.dao.TravelDAO;
import com.soft.model.Travel;
import com.soft.utility.ClearCache;
import com.soft.utility.DBConnection;
import com.soft.utility.Pagging;

/**
 * Servlet implementation class GalleryFillterImages
 */
@WebServlet("/travel-fillter")
public class TravelFillter extends HttpServlet {
	private static final long serialVersionUID = 1L;
	TravelDAO tDAO = new TravelDAO();
	String category = null;
	String state = null;
	String district = null;
	String city = null;
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Connection con= null;
		try{
			if(request.getAttribute("myDBConnection")!=null){
				con = (Connection)request.getAttribute("myDBConnection");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}

		ServletContext context = getServletContext();
		//clear browser cache memory for receive fresh data
		ClearCache cc = new ClearCache();
		cc.clearBrowserCache(response);
		//cleared browser calling above class
		
		if(request.getParameter("category")!=null){
			category =request.getParameter("category");
		}else{
			category = null;
		}
		if(request.getParameter("state")!=null){
			state =request.getParameter("state");
		}else{
			state = null;
		}
		if(request.getParameter("district")!=null){
			district =request.getParameter("district");
		}else{
			district = null;
		}
		if(request.getParameter("city")!=null){
			city =request.getParameter("city");
		}else{
			city = null;
		}
		
			ArrayList<Travel> travelList = tDAO.getBannerFilterList(category, state, district, city, con);
			request.setAttribute("travelList", travelList);
			
		
		RequestDispatcher rd= context.getRequestDispatcher("/travel-filter.jsp");
		rd.forward(request, response);
		
	}
}
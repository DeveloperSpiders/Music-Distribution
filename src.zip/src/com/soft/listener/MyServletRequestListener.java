package com.soft.listener;

import java.sql.Connection;

import javax.servlet.ServletRequest;
import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;
import javax.servlet.annotation.WebListener;

import com.soft.utility.DBConnection;


@WebListener
public class MyServletRequestListener implements ServletRequestListener {

    public void requestDestroyed(ServletRequestEvent servletRequestEvent) {
    	ServletRequest servletRequest = servletRequestEvent.getServletRequest();
    	
    	//create database connection from init parameters and set it to context
    	Connection con = (Connection)servletRequest.getAttribute("myDBConnection");
    	closeConnection(con);
    }

    public void requestInitialized(ServletRequestEvent servletRequestEvent) {
    	ServletRequest servletRequest = servletRequestEvent.getServletRequest();
    	Connection dbManager = (Connection)DBConnection.getInstance().insertPreparequery();
    	servletRequest.setAttribute("myDBConnection", dbManager);
    }
    public void closeConnection(Connection con) {
		   try{
			   if(con!=null){
				   con.close();
				   con=null;
			   }
		   }catch (Exception e) {
			e.printStackTrace();
		}
	   }
}

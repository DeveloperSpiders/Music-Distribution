package com.soft.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.soft.model.AccommodationCategory;

public class AccommodationCategoryDAO {
	int i=0;
	Statement stmt = null;
	ResultSet rs = null;
//	Connection con = (Connection)DBConnection.getInstance().insertPreparequery();
	PreparedStatement ps = null;
	ResultSet rsCategory = null;
	 ResultSet rs1 = null;
	public int addCategory(AccommodationCategory  c, Connection con) {
		String query = "insert into accommodation_category(ACCOMMODATION_CATEGORY, EXTRAS, ENTRY_BY, ENTRY_DATE) values(?, ?, ?, now())";
		try{
		 ps=(PreparedStatement) con.prepareStatement(query);
		 ps.setString(1, c.getAccommodationCategory());
		 ps.setString(2, c.getExtras());
		 ps.setString(3, c.getEntryBy());
		 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i;
	}
	// he is new joining he will get the details of receiver from him.
			public ArrayList<AccommodationCategory> selectCategoryList(Connection con){		
				AccommodationCategory c = null;
				ArrayList<AccommodationCategory> al = new ArrayList<AccommodationCategory>();
				String query= "select * from accommodation_category order by ID DESC";
				try{	
					  stmt = (Statement)con.createStatement();
					  rs = (ResultSet)stmt.executeQuery(query);
					  while (rs.next()){
						  c = new AccommodationCategory();
						  c.setId(rs.getInt("ID"));
						  c.setEntryBy(rs.getString("ENTRY_BY"));
						  c.setEntryDate(rs.getDate("ENTRY_DATE").toString());
						  c.setExtras(rs.getString("EXTRAS"));
						  c.setAccommodationCategory(rs.getString("ACCOMMODATION_CATEGORY"));
						  al.add(c);
					}
				}
				catch (Exception e) {
					System.out.println("muits List not getting mom Database.");
				}finally{
					try{
						 rs.close();
						 stmt.close();
						}catch (Exception e) {
							e.printStackTrace();
						}
					}
				return al;
			}

			// he is new joining he will get the details of receiver from him.
					public ArrayList<AccommodationCategory> selectCategoryListByMainCategory(String mainCategory, Connection con){		
						AccommodationCategory c = null;
						ArrayList<AccommodationCategory> al = new ArrayList<AccommodationCategory>();
						String query= "select * from accommodation_category where SUB_CATEGORY='"+mainCategory+"' order by SUB_CATEGORY DESC";
						try{	
							  stmt = (Statement)con.createStatement();
							  rs = (ResultSet)stmt.executeQuery(query);
							  while (rs.next()) {
								  c = new AccommodationCategory();
								  c.setId(rs.getInt("ID"));
								  c.setEntryBy(rs.getString("ENTRY_BY"));
								  c.setEntryDate(rs.getDate("ENTRY_DATE").toString());
								  c.setExtras(rs.getString("EXTRAS"));
								  c.setAccommodationCategory(rs.getString("ACCOMMODATION_CATEGORY"));
								  al.add(c);
							}
						}
						catch (Exception e) {
							System.out.println("muits List not getting mom Database.");
						}finally{
							try{
								 rs.close();
								 stmt.close();
								}catch (Exception e) {
									e.printStackTrace();
								}
							}
						return al;
					}
			// he is new joining he will get the details of receiver from him.
					public int totalCategoryCount(Connection con){		
						int count=0;
						String query= "select max(ID) as ID from accommodation_category";
						try{	
							  stmt = (Statement)con.createStatement();
							  rs = (ResultSet)stmt.executeQuery(query);
							  while (rs.next()) {
								count = rs.getInt("ID");
							}
						}
						catch (Exception e) {
							System.out.println("muits List not getting mom Database.");
						}finally{
							try{
								 rs.close();
								 stmt.close();
								}catch (Exception e) {
									e.printStackTrace();
								}
							}
						return count;
					}

					public int deleteCategory(int id, Connection con) {
						String query = "delete from accommodation_category where ID=?";
						int i=0;
						try{
							 ps=(PreparedStatement) con.prepareStatement(query);
							 ps.setInt(1, id);
							 i=ps.executeUpdate();
						}catch (Exception e) {
							e.printStackTrace();
						}finally{
							try{
								 ps.close();
								}catch (Exception e) {
									e.printStackTrace();
								}
							}
						return i;
					}
					
					
					
					
}

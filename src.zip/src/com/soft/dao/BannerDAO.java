package com.soft.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.soft.model.Banner;

public class BannerDAO {
	int i=0;
	Statement stmt = null;
	ResultSet rs = null;
//	Connection con = (Connection)DBConnection.getInstance().insertPreparequery();
	PreparedStatement ps = null;
	public int addNewIamgeInBanner(Banner m, Connection con) {
		String query = "insert into banner(TOP_LINE, SUB_LINE, ABOUT, BANNER_PATH, ENTRY_BY, ENTRY_DATE, SHOPPING_URL) values(?, ?, ?,  ?,  ?, now(), ?)";
		try{
		 ps=(PreparedStatement) con.prepareStatement(query);
		 ps.setString(1, m.getTopLine());
		 ps.setString(2, m.getSubLine());
		 ps.setString(3, m.getAbout());
		 ps.setString(4, "");
		 ps.setString(5, "ADMIN");
		 ps.setString(6, m.getShoppingURL());
		 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return getLastImageBannerID(con);
	}
	public int updateBannerPath(String bannerPath, int  id, Connection con) {
		String query = "update banner set BANNER_PATH=? where ID=?";
		try{
//		 con=dbc.insertPreparequery();
		 ps=(PreparedStatement) con.prepareStatement(query);
		 ps.setString(1, bannerPath);
		 ps.setInt(2, id);
		 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}
		finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i;
	}
	// Get Category List mom database.
	public ArrayList<Banner>  getImageBannerListForDisplay(int id, Connection con){		
		Banner g = null;
		ArrayList<Banner> al = new ArrayList<Banner>();
		String query= "select * from banner where ID BETWEEN "+(id-5)+" AND "+id +" ORDER BY ID DESC";
		try{	
			 stmt = (Statement)con.createStatement();
			  rs = (ResultSet)stmt.executeQuery(query);
			while(rs.next()){		
				g = new Banner();
				g.setEntryBy(rs.getString("ENTRY_BY"));
				g.setEntryDate(rs.getDate("ENTRY_DATE"));
				g.setId(rs.getInt("ID"));
				g.setAbout(rs.getString("ABOUT"));
				g.setSubLine(rs.getString("SUB_LINE"));
				g.setTopLine(rs.getString("TOP_LINE"));
				g.setBannerPath(rs.getString("BANNER_PATH"));
				g.setShoppingURL(rs.getString("SHOPPING_URL"));
				al.add(g);
			}
		}
		catch (Exception e) {
			System.out.println("Image Banner List not getting mom Database.");
		}finally{
			try{
				 rs.close();
				 stmt.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return al;
	}
	
	// Get Category List mom database.
		public ArrayList<Banner>  getImageBannerListForDisplayAll(Connection con){		
			Banner g = null;
			ArrayList<Banner> al = new ArrayList<Banner>();
			String query= "select * from banner ORDER BY ID DESC";
			try{	
				 stmt = (Statement)con.createStatement();
				  rs = (ResultSet)stmt.executeQuery(query);
				while(rs.next()){		
					g = new Banner();
					g.setEntryBy(rs.getString("ENTRY_BY"));
					g.setEntryDate(rs.getDate("ENTRY_DATE"));
					g.setId(rs.getInt("ID"));
					g.setAbout(rs.getString("ABOUT"));
					g.setSubLine(rs.getString("SUB_LINE"));
					g.setTopLine(rs.getString("TOP_LINE"));
					g.setBannerPath(rs.getString("BANNER_PATH"));
					g.setShoppingURL(rs.getString("SHOPPING_URL"));
					al.add(g);
				}
			}
			catch (Exception e) {
				System.out.println("Image Banner List not getting mom Database.");
			}finally{
				try{
					 rs.close();
					 stmt.close();
					}catch (Exception e) {
						e.printStackTrace();
					}
				}
			return al;
		}
				// Get Category List mom database.
		public ArrayList<Banner>  getImageBannerList(int id, Connection con){		
					Banner g = null;
					ArrayList<Banner> al = new ArrayList<Banner>();
					String query= "select * from banner where ID BETWEEN "+(id-20)+" AND "+id;
					try{	
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){		
							g = new Banner();
							g.setEntryBy(rs.getString("ENTRY_BY"));
							g.setEntryDate(rs.getDate("ENTRY_DATE"));
							g.setId(rs.getInt("ID"));
							g.setAbout(rs.getString("ABOUT"));
							g.setSubLine(rs.getString("SUB_LINE"));
							g.setTopLine(rs.getString("TOP_LINE"));
							g.setBannerPath(rs.getString("BANNER_PATH"));
							g.setShoppingURL(rs.getString("SHOPPING_URL"));
							al.add(g);
						}
					}
					catch (Exception e) {
						System.out.println("Image Banner List not getting mom Database.");
					}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
					return al;
				}
		
		
		public ArrayList<Banner>  getImageBannerList(Connection con){		
			Banner g = null;
			ArrayList<Banner> al = new ArrayList<Banner>();
			String query= "select * from banner";
			try{	
				 stmt = (Statement)con.createStatement();
				  rs = (ResultSet)stmt.executeQuery(query);
				while(rs.next()){		
					g = new Banner();
					g.setEntryBy(rs.getString("ENTRY_BY"));
					g.setEntryDate(rs.getDate("ENTRY_DATE"));
					g.setId(rs.getInt("ID"));
					g.setAbout(rs.getString("ABOUT"));
					g.setSubLine(rs.getString("SUB_LINE"));
					g.setTopLine(rs.getString("TOP_LINE"));
					g.setBannerPath(rs.getString("BANNER_PATH"));
					g.setShoppingURL(rs.getString("SHOPPING_URL"));
					al.add(g);
				}
			}
			catch (Exception e) {
				System.out.println("Image Banner List not getting mom Database.");
			}finally {
	    // Always make sure result sets and statements are closed,
	    if (rs != null) {
		      try { rs.close(); } catch (SQLException e) { ; }
		      rs = null;
		    }
	    if (stmt != null) {
	      try { stmt.close(); } catch (SQLException e) { ; }
	      stmt = null;
	    }
	}
			return al;
		}
	// Get Category List mom database.
	public int getLastImageBannerID(Connection con) {
		int id = 0;
//		ResultSet rs = null;
		String query = "select MAX(ID) as ID from banner";
		try {
			 stmt = (Statement)con.createStatement();
			  rs = (ResultSet)stmt.executeQuery(query);
			while (rs.next()) {
				id = rs.getInt("ID");
			}
		} catch (Exception e) {
			System.out.println("Sorry! Please try again later.");
		}finally{
			try{
				 rs.close();
				 stmt.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return id;
	}

	public int deleteIamgeFromBanner(int id, Connection con) {
		String query = "delete from banner where ID=?";
		int i=0;
		try{
			 ps=(PreparedStatement) con.prepareStatement(query);
			 ps.setInt(1, id);
			 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i;
	}
}

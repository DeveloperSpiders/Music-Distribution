package com.soft.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.soft.model.Login;
import com.soft.model.Member;
import com.soft.utility.DBConnection;

public class LoginDAO {
	Statement stmt = null;
	ResultSet rs = null;
	int i=0;
	PreparedStatement ps = null;
//	Connection con = (Connection)DBConnection.getInstance().insertPreparequery();
	public Member memberLogin(Login login, Connection con){
		Member memberDetails =null;
		String query= "select * from member where LOGIN_ID='"+login.getEmailID()+"' AND PASSWORD='"+login.getPassword()+"'";
		  try{			
				 stmt = (Statement)con.createStatement();
				  rs = (ResultSet)stmt.executeQuery(query);
			  while(rs.next()){
				  memberDetails= getSingleStoreEntry(rs);
			  }	
			}catch (Exception e) {
				e.printStackTrace();
			}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
		return memberDetails;
	}
	
	public Member memberLogin(String login, Connection con){
		Member memberDetails =null;
		String query= "select * from member where LOGIN_ID='"+login+"'";
		  try{			
				 stmt = (Statement)con.createStatement();
				  rs = (ResultSet)stmt.executeQuery(query);
			  while(rs.next()){
				  memberDetails= getSingleStoreEntry(rs);
			  }	
			}catch (Exception e) {
				e.printStackTrace();
			}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
		return memberDetails;
	}
	//Get AdminCategory Data Method
	private Member getSingleStoreEntry(ResultSet rs)
			throws SQLException {
		Member m;
		m=new Member();
		m.setId(rs.getInt("ID"));
		m.setFirstName(rs.getString("FIRST_NAME"));
		m.setLastName(rs.getString("LAST_NAME"));
		m.setAddress(rs.getString("ADDRESS"));
		m.setLoginID(rs.getString("LOGIN_ID"));
		m.setCity(rs.getString("CITY"));
		m.setContactNumber(rs.getString("CONTACT_NUMBER"));
		m.setEmail(rs.getString("EMAIL_ID"));
		m.setPassword(rs.getString("PASSWORD"));
		m.setState(rs.getString("STATE"));
		m.setCourse(rs.getString("COURSE"));
		m.setCompanyName(rs.getString("COMPANY_NAME"));
		m.setQualification(rs.getString("QUALIFICATION"));
		m.setExperience(rs.getString("EXPERIENCE"));
		m.setEntryBy(rs.getString("ENTRY_BY"));
		m.setEntryDate(rs.getDate("ENTRY_DATE"));
		m.setPhotoURL(rs.getString("PHOTO_URL"));
		return m;
	}
	//Change User Password. 
	public int changePassword(String newpass, String memberID, int id, Connection con){
		int i = 0;
		String query = "update member set PASSWORD='"+newpass+"' where ID="+id+" AND LOGIN_ID='"+memberID+"'";
		try{
//			 i = dbc.insertquery(query);
			 stmt = (Statement)con.createStatement();
			  i = stmt.executeUpdate(query);	
			if(i!=0){
				 System.out.println(i+" Password updated  successfully");
			 }else {
				 System.out.println(i+" Password Not updated. ? Please Try Again.");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 stmt.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i;
	}
	//Change User Password. 
	public int changeTransactionPassword(String newpass, String memberID, int id, Connection con){
		String query = "update member set TRANSACTION_PASSWORD='"+newpass+"' where ID="+id+" AND LOGIN_ID='"+memberID+"'";
		try{
//			 i = dbc.insertquery(query);
			  stmt = (Statement)con.createStatement();
			  i = stmt.executeUpdate(query);
			 if(i!=0){
				 System.out.println(i+" Password updated  successfully");
			 }else {
				 System.out.println(i+"Password Not updated. ? Please Try Again.");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 stmt.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i;
	}
	
	//Check User Login.
	public Login getLoginDetails(String emailID, Connection con){
		Login memberDetails =null;
		String query= "select * from member where EMAIL_ID='"+emailID+"'";
//		ResultSet rs = dbc.selectquery(query);
		try{		
			 stmt = (Statement)con.createStatement();
			  rs = (ResultSet)stmt.executeQuery(query);	
			while(rs.next()){
				String email = rs.getString("EMAIL_ID").toString();
				String password = rs.getString("PASSWORD").toString();
				String name =rs.getString("NAME").toString();
				memberDetails = new Login();
				memberDetails.setEmailID(email);
				memberDetails.setPassword(password);
				memberDetails.setName(name);
				return memberDetails;
			  }	
			}catch (Exception e) {
				e.printStackTrace();
			}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
		return memberDetails;
	}
	//Check User Login.
	 public ArrayList<Login> getUserList(Connection con){
			Login memberDetails =null;
			ArrayList<Login> al = new ArrayList<Login>();
			String query= "select * from member where NAME!='Admin'";
//			ResultSet rs = dbc.selectquery(query);
			try{		
				 stmt = (Statement)con.createStatement();
				  rs = (ResultSet)stmt.executeQuery(query);	
				while(rs.next()){
					memberDetails = new Login();
					memberDetails.setId(rs.getInt("ID"));
					memberDetails.setEmailID(rs.getString("EMAIL_ID"));
					memberDetails.setPassword(rs.getString("PASSWORD"));
					memberDetails.setName(rs.getString("NAME"));
					memberDetails.setEntryDate(rs.getDate("ENTRY_DATE"));
					memberDetails.setStatus(rs.getString("STATUS"));
					al.add(memberDetails);
				}	
				}catch (Exception e) {
					e.printStackTrace();
				}finally{
					try{
						 rs.close();
						 stmt.close();
						}catch (Exception e) {
							e.printStackTrace();
						}
					}
			return al;
		}
		
		//Delete Guest into Database	
		public int deleteUser(int id, Connection con)	{	
			String query = "delete from member where ID='"+id+"'";
			try{
//				 i = dbc.insertquery(query);
				  stmt = (Statement)con.createStatement();
				  i = stmt.executeUpdate(query);
				 if(i!=0){
					 System.out.println(i+" User Deleted  Successfully");
				 }else {
					 System.out.println(" User not Deleted.? Please try Again.");
				}
			}catch (Exception e) {
				e.printStackTrace();
			}finally{
				try{
					 stmt.close();
					}catch (Exception e) {
						e.printStackTrace();
					}
				}
			return i;	
		}
		
		// Active Status into Database.
		public int activeUserStatus (int id, Connection con){
			String query = "update member set STATUS = 0 where ID='"+id+"'";
			try{
//				 i = dbc.insertquery(query);
				  stmt = (Statement)con.createStatement();
				  i = stmt.executeUpdate(query);
				 if(i!=0){
					 System.out.println(i+"Active Status Updated successfully");
				 }else {
					 System.out.println(i+"Active Status Not updated. ? Please Try Again.");
				}
			}catch (Exception e) {
				e.printStackTrace();
			}finally{
				try{
					 stmt.close();
					}catch (Exception e) {
						e.printStackTrace();
					}
				}
			return i;
		}
		
		// InActive Status into Database.
				public int inActiveUserStatus (int id, Connection con)	{
					String query = "update member set STATUS = 1 where ID='"+id+"'";
					try{
//						 i = dbc.insertquery(query);
						  stmt = (Statement)con.createStatement();
						  i = stmt.executeUpdate(query);
						 if(i!=0){
							 System.out.println(i+"InActive Status Updated successfully");
						 }else {
							 System.out.println(i+"InActive Status Not updated. ? Please Try Again.");
						}
					}catch (Exception e) {
						e.printStackTrace();
					}finally{
						try{
							 stmt.close();
							}catch (Exception e) {
								e.printStackTrace();
							}
						}
					return i;
				}
}

package com.soft.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.soft.model.Helpdesk;
import com.soft.utility.DBConnection;

public class HelpDeskDAO {
//	   DBConnection dbc=new DBConnection();
		int i=0;
		Statement stmt = null;
		ResultSet rs = null;
//		Connection con = (Connection)DBConnection.getInstance().insertPreparequery();
		PreparedStatement ps = null;
		public int addNewHelpQuery(Helpdesk h, Connection con) {
			String query = "insert into help_desk(LOGIN_ID, MEMBER_NAME, SUBJECT, DESCRIPTION, ADMIN_COMMENT, STATUS, ADMIN_COMMENT_DATE, ENTRY_DATE, IMAGE_PATH, PAYMENT_MODE, TOPUP_BY, QUERY_TYPE) values(?, ?, ?, ?,'NA', 'open', now(), now(), 'NA', ?, ?, ?)";
			try{
//			 con=dbc.insertPreparequery();
			 ps=(PreparedStatement) con.prepareStatement(query);
			 ps.setString(1, h.getLoginId());
			 ps.setString(2, h.getMemberName());
			 ps.setString(3, h.getSubject());
			 ps.setString(4, h.getDescription());
			 ps.setString(5, h.getPaymentMethod());
			 ps.setString(6, h.getTopupBy());
			 ps.setString(7, h.getQueryType());
			 i=ps.executeUpdate();
			}catch (Exception e) {
				e.printStackTrace();
			}finally{
				try{
					 ps.close();
					}catch (Exception e) {
						e.printStackTrace();
					}
				}
			return i;
		}

		public int updateHelpDesk(String msg, int id, Connection con) {
			String query = "update help_desk set ADMIN_COMMENT=?, STATUS='close', ADMIN_COMMENT_DATE=now() where ID=?";
			try{
//			 con=dbc.insertPreparequery();
			  ps=(PreparedStatement) con.prepareStatement(query);
			 ps.setString(1, msg);
			 ps.setInt(2, id);
			 i=ps.executeUpdate();
			}catch (Exception e) {
				e.printStackTrace();
			}finally{
				try{
					 ps.close();
					}catch (Exception e) {
						e.printStackTrace();
					}
				}
			return i;
		}

		public int updateHelpDeskUploadSlip(String msg, int id, Connection con) {
			String query = "update help_desk set IMAGE_PATH=? where ID=?";
			try{
//			 con=dbc.insertPreparequery();
			  ps=(PreparedStatement) con.prepareStatement(query);
			 ps.setString(1, msg);
			 ps.setInt(2, id);
			 i=ps.executeUpdate();
			}catch (Exception e) {
				e.printStackTrace();
			}finally{
				try{
					 ps.close();
					}catch (Exception e) {
						e.printStackTrace();
					}
				}
			return i;
		}
		public int updateHelpDeskByAdmin(String msg, int id, Connection con) {
			String query = "update help_desk set ADMIN_COMMENT=?, STATUS='close', ADMIN_COMMENT_DATE=now() where ID=?";
			try{
//			 con=dbc.insertPreparequery();
			  ps=(PreparedStatement) con.prepareStatement(query);
			 ps.setString(1, msg);
			 ps.setInt(2, id);
			 i=ps.executeUpdate();
			}catch (Exception e) {
				e.printStackTrace();
			}finally{
				try{
					 ps.close();
					}catch (Exception e) {
						e.printStackTrace();
					}
				}
			return i;
		}
		// Get Category List mom database.
		public ArrayList<Helpdesk> getTicketList(String loginId, Connection con){		
			Helpdesk h = null;
			ArrayList<Helpdesk> al = new ArrayList<Helpdesk>();
			String query= "select * from help_desk where LOGIN_ID='"+loginId+"' order by ID DESC";
			try{	
//				ResultSet rs = dbc.selectquery(query);
				 stmt = (Statement)con.createStatement();
				  rs = (ResultSet)stmt.executeQuery(query);
				while(rs.next()){		
					h = new Helpdesk();
					h = extractDataFromDB(h);
					al.add(h);
					}
				}
				catch (Exception e) {
				System.out.println("help ticket List not getting from Database.");
				}finally {
				    // Always make sure result sets and statements are closed,
				    if (rs != null) {
					      try { rs.close(); } catch (SQLException e) { ; }
					      rs = null;
					    }
				    if (stmt != null) {
				      try { stmt.close(); } catch (SQLException e) { ; }
				      stmt = null;
				    }
				}
		   return al;
		}
		// Get Category List mom database.
		public ArrayList<Helpdesk> getTicketListForAdmin(int id, Connection con){		
			Helpdesk h = null;
			ArrayList<Helpdesk> al = new ArrayList<Helpdesk>();
			String query= "select * from help_desk where ID between "+(id-20)+" AND "+id+" order by ID DESC";
			try{	
//				ResultSet rs = dbc.selectquery(query);
				 stmt = (Statement)con.createStatement();
				  rs = (ResultSet)stmt.executeQuery(query);
				while(rs.next()){		
					h = new Helpdesk();
					h = extractDataFromDB(h);
					al.add(h);
					}
				}
				catch (Exception e) {
				System.out.println("help ticket List not getting from Database.");
				}finally {
				    // Always make sure result sets and statements are closed,
				    if (rs != null) {
					      try { rs.close(); } catch (SQLException e) { ; }
					      rs = null;
					    }
				    if (stmt != null) {
				      try { stmt.close(); } catch (SQLException e) { ; }
				      stmt = null;
				    }
				}
		   return al;
		}

		// Get Category List mom database.
		public ArrayList<Helpdesk> getCloseTicketListForAdmin( String status, Connection con){		
			Helpdesk h = null;
			ArrayList<Helpdesk> al = new ArrayList<Helpdesk>();
			String query= "select * from help_desk where STATUS='"+status+"' order by ID DESC";
			try{	
//				ResultSet rs = dbc.selectquery(query);
				 stmt = (Statement)con.createStatement();
				  rs = (ResultSet)stmt.executeQuery(query);
				while(rs.next()){		
					h = new Helpdesk();
					h = extractDataFromDB(h);
					al.add(h);
					}
				}
				catch (Exception e) {
				System.out.println("help ticket List not getting from Database.");
				}finally {
				    // Always make sure result sets and statements are closed,
				    if (rs != null) {
					      try { rs.close(); } catch (SQLException e) { ; }
					      rs = null;
					    }
				    if (stmt != null) {
				      try { stmt.close(); } catch (SQLException e) { ; }
				      stmt = null;
				    }
				}
		   return al;
		}

		// Get Category List mom database.
		public ArrayList<Helpdesk> getTicketListForAdminFilter(String loginId, String status, Connection con){		
			Helpdesk h = null;
			String filter = " where 1=1 ";
			if(loginId!=null && !loginId.equals("")){
				filter +=" AND LOGIN_ID='"+loginId+"'";
			}
			if(status!=null && !status.equals("")){
				filter +=" AND STATUS='"+status+"'";
			}
			ArrayList<Helpdesk> al = new ArrayList<Helpdesk>();
			String query= "select * from help_desk "+filter+" order by ID DESC";
			try{	
//				ResultSet rs = dbc.selectquery(query);
				 stmt = (Statement)con.createStatement();
				  rs = (ResultSet)stmt.executeQuery(query);
				while(rs.next()){		
					h = new Helpdesk();
					h = extractDataFromDB(h);
					al.add(h);
					}
				}
				catch (Exception e) {
				System.out.println("help ticket List not getting from Database.");
				}finally {
				    // Always make sure result sets and statements are closed,
				    if (rs != null) {
					      try { rs.close(); } catch (SQLException e) { ; }
					      rs = null;
					    }
				    if (stmt != null) {
				      try { stmt.close(); } catch (SQLException e) { ; }
				      stmt = null;
				    }
				}
		   return al;
		}
		// Get Category List mom database.
		public Helpdesk getSingleTicketListForAdmin(int id, Connection con){		
			Helpdesk h = null;
			String query= "select * from help_desk where ID="+id;
			try{	
//				ResultSet rs = dbc.selectquery(query);
				 stmt = (Statement)con.createStatement();
				  rs = (ResultSet)stmt.executeQuery(query);
				while(rs.next()){		
					h = new Helpdesk();
					h = extractDataFromDB(h);
					}
				}
				catch (Exception e) {
				System.out.println("help ticket List not getting from Database.");
				}finally {
				    // Always make sure result sets and statements are closed,
				    if (rs != null) {
					      try { rs.close(); } catch (SQLException e) { ; }
					      rs = null;
					    }
				    if (stmt != null) {
				      try { stmt.close(); } catch (SQLException e) { ; }
				      stmt = null;
				    }
				}
		   return h;
		}
		/**
		 * @param h
		 * @throws SQLException
		 */
		private Helpdesk extractDataFromDB(Helpdesk h) throws SQLException {
			h.setDescription(rs.getString("DESCRIPTION"));
			h.setEntryDate(rs.getDate("ENTRY_DATE"));
			h.setId(rs.getInt("ID"));
			h.setLoginId(rs.getString("LOGIN_ID"));
			h.setMemberName(rs.getString("MEMBER_NAME"));
			h.setSubject(rs.getString("SUBJECT"));
			h.setAdminComment(rs.getString("ADMIN_COMMENT"));
			h.setAdminCommentDate(rs.getDate("ADMIN_COMMENT_DATE"));
			h.setStatus(rs.getString("STATUS"));
			h.setImagePath(rs.getString("IMAGE_PATH"));
			h.setPaymentMethod(rs.getString("PAYMENT_MODE"));
			h.setTopupBy(rs.getString("TOPUP_BY"));
			h.setQueryType(rs.getString("QUERY_TYPE"));
			return h;
		}

		// Get Category List mom database.
		public int getLastTicketId(Connection con) {
			int id = 0;
//			ResultSet rs = null;
			String query = "select MAX(ID) as ID from help_desk";
			try {
//				rs = dbc.selectquery(query);
				 stmt = (Statement)con.createStatement();
				  rs = (ResultSet)stmt.executeQuery(query);
				while (rs.next()) {
					id = rs.getInt("ID");
				}
			} catch (Exception e) {
				System.out.println("Sorry! Please try again later.");
			}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
			return id;
		}
}

package com.soft.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.soft.model.Gallery;
import com.soft.model.Video;
import com.soft.model.VideoAlbumName;

public class VideoDAO {
//    DBConnection dbc=new DBConnection();
//	Connection con = (Connection)DBConnection.getInstance().insertPreparequery();
    PreparedStatement ps = null;
    ResultSet rs = null;
    Statement stmt = null;
	int i=0;
	
	public int addNewVideoAccount(Video v, Connection con) {
		String query = "insert into video(CATEGORY, FILE_PATH, TITLE, SINGER, MUSIC_DIRECTOR," +
				" LYRICS, GENRE, MOOD, LABEL, PUBLISHER," +
				" LANGUAGE, ISRC, CRBT_TITLE, CRBT_TIME, DURATION," +
				" VIDEO_DIRECTOR, STAR_CAST, RELEASING_DATE, IMAGE_PATH1, IMAGE_PATH2, " +
				" IMAGE_PATH3, ENTRY_BY, DESCRIPTION, TYPE, STATUS," +
				" FILM_SYNOPSIS, REMARK, CONTENT_RATING," +
				" ENTRY_DATE) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, now())";
			try{
				 ps=(PreparedStatement) con.prepareStatement(query);
				 ps.setString(1, v.getCategory());
				 ps.setString(2, v.getFilePath());
				 ps.setString(3, v.getTitle());
				 ps.setString(4, v.getSinger());
				 ps.setString(5, v.getMusicDirector());
				 ps.setString(6, v.getLyrics());
				 ps.setString(7, v.getGenre());
				 ps.setString(8, v.getMood());
				 ps.setString(9, v.getLabel());
				 ps.setString(10, v.getPublisher());
				 ps.setString(11, v.getLanguage());
				 ps.setString(12, v.getIsrc());
				 ps.setString(13, v.getCrbtTitle());
				 ps.setString(14, v.getCrbtTime());
				 ps.setString(15, v.getDuration());
				 ps.setString(16, v.getVideoDirector());
				 ps.setString(17, v.getStarCast());
				 ps.setString(18, v.getReleasingDate());
				 ps.setString(19, v.getImagepath1());
				 ps.setString(20, v.getImagepath2());
				 ps.setString(21, v.getImagepath3());
				 ps.setString(22, v.getEntryBy());
				 ps.setString(23, v.getDescription());
				 ps.setString(24, v.getType());
				 ps.setString(25, v.getStatus());
				 ps.setString(26, v.getFilmSynopsis());
				 ps.setString(27, v.getRemark());
				 ps.setString(28, v.getContentRating());
				 i=ps.executeUpdate();
		 if(i!=0){
			i= getLastVideoAccountID(con);
		 }
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i;
	}
	
	
	public int updateVideo(Video v, Connection con) {
		String query = "update video set CATEGORY=?, TITLE=?, SINGER=?, MUSIC_DIRECTOR=?," +
				" LYRICS=?, GENRE=?, MOOD=?, LABEL=?, PUBLISHER=?," +
				" LANGUAGE=?, ISRC=?, CRBT_TITLE=?, CRBT_TIME=?, DURATION=?," +
				" VIDEO_DIRECTOR=?, STAR_CAST=?, RELEASING_DATE=?, ENTRY_BY=?, " +
				" DESCRIPTION=?, STATUS=?, FILM_SYNOPSIS=?, CONTENT_RATING=?" +
				" where ID=?";
			try{
				 ps=(PreparedStatement) con.prepareStatement(query);
				 ps.setString(1, v.getCategory());
				 ps.setString(2, v.getTitle());
				 ps.setString(3, v.getSinger());
				 ps.setString(4, v.getMusicDirector());
				 ps.setString(5, v.getLyrics());
				 ps.setString(6, v.getGenre());
				 ps.setString(7, v.getMood());
				 ps.setString(8, v.getLabel());
				 ps.setString(9, v.getPublisher());
				 ps.setString(10, v.getLanguage());
				 ps.setString(11, v.getIsrc());
				 ps.setString(12, v.getCrbtTitle());
				 ps.setString(13, v.getCrbtTime());
				 ps.setString(14, v.getDuration());
				 ps.setString(15, v.getVideoDirector());
				 ps.setString(16, v.getStarCast());
				 ps.setString(17, v.getReleasingDate());
				 ps.setString(18, v.getEntryBy());
				 ps.setString(19, v.getDescription());
				 ps.setString(20, v.getStatus());
				 ps.setString(21, v.getFilmSynopsis());
				 ps.setString(22, v.getContentRating());
				 ps.setInt(23, v.getId());
				 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i;
	}
	
	public int updateURLStatus(String status, int id, Connection con) {
		String query = "update video set STATUS=? where ID="+id;
		//DBConnection dbc = new DBConnection();
		int i=0;
		try{
			PreparedStatement ps=(PreparedStatement) con.prepareStatement(query);
			 ps.setString(1,status);
			 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return i;
	}
	
	
	
	
	// Get Category List mom database.
	public ArrayList<Video> getVideosListForAdmin(int count, Connection con){		
		Video mbr = null;
		ArrayList<Video> al = new ArrayList<Video>();
		if(count==0){
			count = getLastVideoAccountID(con);
		}
		String query= "select * from video where  ID between "+(count-20)+" AND "+(count+1)+" order by ID desc";
		try{	
//			ResultSet rs = dbc.selectquery(query);
			 stmt = (Statement)con.createStatement();
			  rs = (ResultSet)stmt.executeQuery(query);
			while(rs.next()){		
				mbr = getSingleVideoEntry(rs);
					al.add(mbr);
				}
			}
			catch (Exception e) {
			System.out.println("bank account List not getting from Database.");
			}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
	   return al;
	}
	// Get Category List mom database.
	public ArrayList<Video> getSIngleAdvertizement(int count, Connection con){		
		Video c = null;
		ArrayList<Video> al = new ArrayList<Video>();
		if(count==0){
			count = getLastVideoAccountID(con);
		}
		String query= "select * from video where STATUS='ACTIVE' AND ID< "+count+"  order by ID desc LIMIT 1";
		try{	
//			ResultSet rs = dbc.selectquery(query);
			 stmt = (Statement)con.createStatement();
			  rs = (ResultSet)stmt.executeQuery(query);
			while(rs.next()){		
				c = getSingleVideoEntry(rs);
				al.add(c);
				}
			}
			catch (Exception e) {
			System.out.println("bank account List not getting from Database.");
			}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
	   return al;
	}
	// Get Category List mom database.
	public ArrayList<Video> getAdvertizementList(int count, int limit, Connection con){		
		Video mbr = null;
		ArrayList<Video> al = new ArrayList<Video>();
		if(count==0){
			count = getLastVideoAccountID(con);
		}if(count<20){
			limit =count;
		}
		String query= "select * from video where ID<= "+count+" order by ID desc LIMIT "+limit;
		try{	
			 stmt = (Statement)con.createStatement();
			  rs = (ResultSet)stmt.executeQuery(query);
			while(rs.next()){		
				mbr = getSingleVideoEntry(rs);
					al.add(mbr);
				}
			}
			catch (Exception e) {
			System.out.println("Video List not getting from Database.");
			}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
	   return al;
	}
	// Get Category List mom database.
	public ArrayList<Video> getSilgleMemberVideoAccountDetails(int id, Connection con){		
		Video mbr = null;
		ArrayList<Video> al = new ArrayList<Video>();
		String query= "select * from video";
		try{	
//			ResultSet rs = dbc.selectquery(query);
			 stmt = (Statement)con.createStatement();
			  rs = (ResultSet)stmt.executeQuery(query);
			while(rs.next()){		
				mbr = getSingleVideoEntry(rs);
					al.add(mbr);
				}
			}
			catch (Exception e) {
			System.out.println("bank account List not getting from Database.");
			}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
	   return al;
	}
	
	public ArrayList<Video> getSilgleMemberVideoAccountDetails(String id, Connection con){		
		Video mbr = null;
		ArrayList<Video> al = new ArrayList<Video>();
		String query= "select * from video where ENTRY_BY='"+id+"'";
		try{	
//			ResultSet rs = dbc.selectquery(query);
			 stmt = (Statement)con.createStatement();
			  rs = (ResultSet)stmt.executeQuery(query);
			while(rs.next()){		
				mbr = getSingleVideoEntry(rs);
					al.add(mbr);
				}
			}
			catch (Exception e) {
			System.out.println("bank account List not getting from Database.");
			}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
	   return al;
	}
	
	public ArrayList<Video> getSilgleMemberVideoAccountByStatus(String id, String status, Connection con){		
		Video mbr = null;
		ArrayList<Video> al = new ArrayList<Video>();
		String query= "select * from video where ENTRY_BY='"+id+"' AND STATUS='"+status+"'";
		try{	
//			ResultSet rs = dbc.selectquery(query);
			 stmt = (Statement)con.createStatement();
			  rs = (ResultSet)stmt.executeQuery(query);
			while(rs.next()){		
				mbr = getSingleVideoEntry(rs);
					al.add(mbr);
				}
			}
			catch (Exception e) {
			System.out.println("bank account List not getting from Database.");
			}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
	   return al;
	}
	
	public ArrayList<Video> getSilgleMemberVideoAccountByNotStatus(String id, String status, Connection con){		
		Video mbr = null;
		ArrayList<Video> al = new ArrayList<Video>();
		String query= "select * from video where ENTRY_BY='"+id+"' AND STATUS!='"+status+"'";
		try{	
//			ResultSet rs = dbc.selectquery(query);
			 stmt = (Statement)con.createStatement();
			  rs = (ResultSet)stmt.executeQuery(query);
			while(rs.next()){		
				mbr = getSingleVideoEntry(rs);
					al.add(mbr);
				}
			}
			catch (Exception e) {
			System.out.println("bank account List not getting from Database.");
			}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
	   return al;
	}
	
	
	public ArrayList<Video> getSilgleMemberVideoAccountDetails(String id, int limit, Connection con){		
		Video mbr = null;
		ArrayList<Video> al = new ArrayList<Video>();
		String query= "select * from video where ENTRY_BY='"+id+"' order by ID DESC limit "+limit+"";
		try{	
//			ResultSet rs = dbc.selectquery(query);
			 stmt = (Statement)con.createStatement();
			  rs = (ResultSet)stmt.executeQuery(query);
			while(rs.next()){		
				mbr = getSingleVideoEntry(rs);
					al.add(mbr);
				}
			}
			catch (Exception e) {
			System.out.println("bank account List not getting from Database.");
			}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
	   return al;
	}
	
	
				// Get Category List mom database.
				public Video getSilgleVideoAccountDetails(int id, Connection con){		
					Video bnk = null;
//					ResultSet rs = null;
					String query= "select * from video where ID="+id;
					try{	
//						 rs = dbc.selectquery(query);
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){		
							bnk = getSingleVideoEntry(rs);
						}
					}
					catch (Exception e) {
						System.out.println("bank account List not getting mom Database.");
					}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
					return bnk;
				}
				
				
				// Get Category List mom database.
				public Video getSilgleVideoAccountDetails(String id, Connection con){		
					Video bnk = null;
//					ResultSet rs = null;
					String query= "select * from video where FILE_PATH='"+id+"'";
					try{	
//						 rs = dbc.selectquery(query);
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){		
							bnk = getSingleVideoEntry(rs);
						}
					}
					catch (Exception e) {
						System.out.println("bank account List not getting mom Database.");
					}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
					return bnk;
				}
				
				
				
				//Get AdminCategory Data Method
				private Video getSingleVideoEntry(ResultSet rs)
						throws SQLException {
					Video b;
					b=new Video();
					
					b.setId(rs.getInt("ID"));
					b.setCategory(rs.getString("CATEGORY"));
					b.setFilePath(rs.getString("FILE_PATH"));
					b.setTitle(rs.getString("TITLE"));
					b.setSinger(rs.getString("SINGER"));
					
					b.setMusicDirector(rs.getString("MUSIC_DIRECTOR"));
					b.setLyrics(rs.getString("LYRICS"));
					b.setGenre(rs.getString("GENRE"));
					b.setMood(rs.getString("MOOD"));
					b.setLabel(rs.getString("LABEL"));
					
					b.setPublisher(rs.getString("PUBLISHER"));
					b.setLanguage(rs.getString("LANGUAGE"));
					b.setIsrc(rs.getString("ISRC"));
					b.setCrbtTitle(rs.getString("CRBT_TITLE"));
					b.setCrbtTime(rs.getString("CRBT_TIME"));
					
					b.setDuration(rs.getString("DURATION"));
					b.setVideoDirector(rs.getString("VIDEO_DIRECTOR"));
					b.setStarCast(rs.getString("STAR_CAST"));
					b.setReleasingDate(rs.getString("RELEASING_DATE"));
					b.setImagepath1(rs.getString("IMAGE_PATH1"));
					b.setImagepath2(rs.getString("IMAGE_PATH2"));
					b.setImagepath3(rs.getString("IMAGE_PATH3"));
					
					b.setDescription(rs.getString("DESCRIPTION"));
					b.setType(rs.getString("TYPE"));
					b.setFilmSynopsis(rs.getString("FILM_SYNOPSIS"));
					b.setRemark(rs.getString("REMARK"));
					b.setContentRating(rs.getString("CONTENT_RATING"));
					b.setStatus(rs.getString("STATUS"));
				    
					b.setEntryBy(rs.getString("ENTRY_BY"));
					b.setEntryDate(rs.getDate("ENTRY_DATE"));
					return b;
				}
	// Get Category List mom database.
	public int getLastVideoAccountID(Connection con) {
		int id = 0;
//		ResultSet rs = null;
		String query = "select MAX(ID) as ID from video";
		try {
//			rs = dbc.selectquery(query);
			 stmt = (Statement)con.createStatement();
			  rs = (ResultSet)stmt.executeQuery(query);
			while (rs.next()) {
				id = rs.getInt("ID");
			}
		} catch (Exception e) {
			System.out.println("Sorry! Please try again later.");
		}finally{
			try{
				 rs.close();
				 stmt.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return id;
	}
	
	// he is new joining he will get the details of receiver from him.
				public ArrayList<Video> selectVideoList(Connection con){		
					Video c = null;
					ArrayList<Video> al = new ArrayList<Video>();
					String query= "select * from video order by ID DESC";
					try{	
						  stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						  while (rs.next()){
							  c = getSingleVideoEntry(rs);
								al.add(c);
						}
					}
					catch (Exception e) {
						System.out.println("muits List not getting mom Database.");
					}finally{
						try{
							 rs.close();
							 stmt.close();
							}catch (Exception e) {
								e.printStackTrace();
							}
						}
					return al;
				}
				
				public int DeleteVideo(int id, Connection con) {
					String query = "delete from video where ID=?";
					int i=0;
					try{
						 ps=(PreparedStatement) con.prepareStatement(query);
						 ps.setInt(1, id);
						 i=ps.executeUpdate();
					}catch (Exception e) {
						e.printStackTrace();
					}finally{
						try{
							 ps.close();
							}catch (Exception e) {
								e.printStackTrace();
							}
						}
					return i;
				}
				
				public int DeleteVideo(int id, String entryBy, Connection con) {
					String query = "delete from video where ID=? AND ENTRY_BY=?";
					int i=0;
					try{
						 ps=(PreparedStatement) con.prepareStatement(query);
						 ps.setInt(1, id);
						 ps.setString(2, entryBy);
						 i=ps.executeUpdate();
					}catch (Exception e) {
						e.printStackTrace();
					}finally{
						try{
							 ps.close();
							}catch (Exception e) {
								e.printStackTrace();
							}
						}
					return i;
				}
				
				// Get Category List mom database.
				public ArrayList<Video>  getVideoFilterList(String album, Connection con){		
					Video c = null;
					String filter = " where 1=1";
					if(album!=null && !album.equals("")){
						filter +=" AND ALBUM_NAME='"+album+"'";
					}
					
					ArrayList<Video> al = new ArrayList<Video>();
					String query= "select * from video "+filter+"  order by ID DESC";
					try{	
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){		
							c = getSingleVideoEntry(rs);
							al.add(c);
						}
					}
					catch (Exception e) {
						System.out.println("Image Gallery List not getting mom Database.");
					}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
					return al;
				}
				
				public int updatVideoImagePath(ArrayList<String> path, long id, Connection con) {
					int i=0;
					String url = "";
					try{
						for(String s : path){
							i = i+1;
							if(i==1){
								url += " IMAGE_PATH"+i+"='"+s+"'";
							}else{
							url += ", IMAGE_PATH"+i+"='"+s+"'";
							}
						}
						
						String query = "update video set "+url+" where ID=?";
						 ps=(PreparedStatement) con.prepareStatement(query);
						 ps.setLong(1, id);
						 i=ps.executeUpdate();
					}catch (Exception e) {
						e.printStackTrace();
					}finally{
						try{
							 ps.close();
							}catch (Exception e) {
								e.printStackTrace();
							}
						}
					return i;
				}
				
				
				public int updatVideoPath(String path, long id, Connection con) {
					int i=0;
					try{
						
						String query = "update video set FILE_PATH='"+path+"' where ID=?";
						 ps=(PreparedStatement) con.prepareStatement(query);
						 ps.setLong(1, id);
						 i=ps.executeUpdate();
					}catch (Exception e) {
						e.printStackTrace();
					}finally{
						try{
							 ps.close();
							}catch (Exception e) {
								e.printStackTrace();
							}
						}
					return i;
				}
}

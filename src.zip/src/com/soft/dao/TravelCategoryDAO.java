package com.soft.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.soft.model.TravelCategory;
import com.soft.model.ChildCategory;
import com.soft.utility.DBConnection;

public class TravelCategoryDAO {
	int i=0;
	Statement stmt = null;
	ResultSet rs = null;
//	Connection con = (Connection)DBConnection.getInstance().insertPreparequery();
	PreparedStatement ps = null;
	ResultSet rsCategory = null;
	 ResultSet rs1 = null;
	public int addCategory(TravelCategory  c, Connection con) {
		String query = "insert into travel_category(TRAVEL_CATEGORY, EXTRAS, ENTRY_BY, ENTRY_DATE) values(?, ?, ?, now())";
		try{
		 ps=(PreparedStatement) con.prepareStatement(query);
		 ps.setString(1, c.getTravelCategory());
		 ps.setString(2, c.getExtras());
		 ps.setString(3, c.getEntryBy());
		 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i;
	}
	// he is new joining he will get the details of receiver from him.
			public ArrayList<TravelCategory> selectCategoryList(Connection con){		
				TravelCategory c = null;
				ArrayList<TravelCategory> al = new ArrayList<TravelCategory>();
				String query= "select * from travel_category order by ID DESC";
				try{	
					  stmt = (Statement)con.createStatement();
					  rs = (ResultSet)stmt.executeQuery(query);
					  while (rs.next()){
						  c = new TravelCategory();
						  c.setId(rs.getInt("ID"));
						  c.setEntryBy(rs.getString("ENTRY_BY"));
						  c.setEntryDate(rs.getDate("ENTRY_DATE").toString());
						  c.setExtras(rs.getString("EXTRAS"));
						  c.setTravelCategory(rs.getString("TRAVEL_CATEGORY"));
						  al.add(c);
					}
				}
				catch (Exception e) {
					System.out.println("muits List not getting mom Database.");
				}finally{
					try{
						 rs.close();
						 stmt.close();
						}catch (Exception e) {
							e.printStackTrace();
						}
					}
				return al;
			}

			// he is new joining he will get the details of receiver from him.
					public ArrayList<TravelCategory> selectCategoryListByMainCategory(String mainCategory, Connection con){		
						TravelCategory c = null;
						ArrayList<TravelCategory> al = new ArrayList<TravelCategory>();
						String query= "select * from travel_category where SUB_CATEGORY='"+mainCategory+"' order by SUB_CATEGORY DESC";
						try{	
							  stmt = (Statement)con.createStatement();
							  rs = (ResultSet)stmt.executeQuery(query);
							  while (rs.next()) {
								  c = new TravelCategory();
								  c.setId(rs.getInt("ID"));
								  c.setEntryBy(rs.getString("ENTRY_BY"));
								  c.setEntryDate(rs.getDate("ENTRY_DATE").toString());
								  c.setExtras(rs.getString("EXTRAS"));
								  c.setTravelCategory(rs.getString("TRAVEL_CATEGORY"));
								  al.add(c);
							}
						}
						catch (Exception e) {
							System.out.println("muits List not getting mom Database.");
						}finally{
							try{
								 rs.close();
								 stmt.close();
								}catch (Exception e) {
									e.printStackTrace();
								}
							}
						return al;
					}
			// he is new joining he will get the details of receiver from him.
					public int totalCategoryCount(Connection con){		
						int count=0;
						String query= "select max(ID) as ID from travel_category";
						try{	
							  stmt = (Statement)con.createStatement();
							  rs = (ResultSet)stmt.executeQuery(query);
							  while (rs.next()) {
								count = rs.getInt("ID");
							}
						}
						catch (Exception e) {
							System.out.println("muits List not getting mom Database.");
						}finally{
							try{
								 rs.close();
								 stmt.close();
								}catch (Exception e) {
									e.printStackTrace();
								}
							}
						return count;
					}

					public int deleteCategory(int id, Connection con) {
						String query = "delete from travel_category where ID=?";
						int i=0;
						try{
							 ps=(PreparedStatement) con.prepareStatement(query);
							 ps.setInt(1, id);
							 i=ps.executeUpdate();
						}catch (Exception e) {
							e.printStackTrace();
						}finally{
							try{
								 ps.close();
								}catch (Exception e) {
									e.printStackTrace();
								}
							}
						return i;
					}
					
					
					
					
}

package com.soft.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.soft.model.VideoAlbumName;

public class VideoAlbumDAO {
	int i=0;
	Statement stmt = null;
	ResultSet rs = null;
//	Connection con = (Connection)DBConnection.getInstance().insertPreparequery();
	PreparedStatement ps = null;
	public int addNewVideoAlbum(VideoAlbumName c, Connection con) {
		String query = "insert into videoalbum_name(ALBUM_NAME, IMAGE_PATH, SUBJECT, ENTRY_BY, ENTRY_DATE) values(?, 'NA', ?, 'ADMIN',  now())";
		try{
		 ps=(PreparedStatement) con.prepareStatement(query);
		 ps.setString(1, c.getAlbumname());
		 ps.setString(2, c.getSubject());
		 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i;
	}
	
	// he is new joining he will get the details of receiver from him.
			public ArrayList<VideoAlbumName> selectVideoAlbumList(Connection con){		
				VideoAlbumName c = null;
				ArrayList<VideoAlbumName> al = new ArrayList<VideoAlbumName>();
				String query= "select * from videoalbum_name order by ID DESC";
				try{	
					  stmt = (Statement)con.createStatement();
					  rs = (ResultSet)stmt.executeQuery(query);
					  while (rs.next()){
						  c = new VideoAlbumName();
						  c.setId(rs.getInt("ID"));
						  c.setAlbumname(rs.getString("ALBUM_NAME"));
						  c.setSubject(rs.getString("SUBJECT"));
						  c.setImagepath(rs.getString("IMAGE_PATH"));
						  c.setEntryBy(rs.getString("ENTRY_BY"));
						  c.setEntryDate(rs.getDate("ENTRY_DATE"));
						  al.add(c);
					}
				}
				catch (Exception e) {
					System.out.println("muits List not getting mom Database.");
				}finally{
					try{
						 rs.close();
						 stmt.close();
						}catch (Exception e) {
							e.printStackTrace();
						}
					}
				return al;
			}
	
	// he is new joining he will get the details of receiver from him.
			public int totalMaxAlbumId(Connection con){		
				int count=0;
				String query= "select max(ID) as ID from videoalbum_name";
				try{	
					  stmt = (Statement)con.createStatement();
					  rs = (ResultSet)stmt.executeQuery(query);
					  while (rs.next()) {
						count = rs.getInt("ID");
					}
				}
				catch (Exception e) {
					System.out.println("products List not getting from Database.");
				}finally {
				    // Always make sure result sets and statements are closed,
				    if (rs != null) {
					      try { rs.close(); } catch (SQLException e) { ; }
					      rs = null;
					    }
				    if (stmt != null) {
				      try { stmt.close(); } catch (SQLException e) { ; }
				      stmt = null;
				    }
				}
				return count;
			}
	
	public int updatImagePath(ArrayList<String> path, long id, Connection con) {
		int i=0;
		String url = "";
		try{
			for(String s : path){
				i = i+1;
				if(i==1){
					url += " IMAGE_PATH='"+s+"'";
				}else{
				url += ", IMAGE_PATH='"+s+"'";
				}
			}
			
			String query = "update videoalbum_name set "+url+" where ID=?";
			 ps=(PreparedStatement) con.prepareStatement(query);
			 ps.setLong(1, id);
			 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i;
	}
	
	public int DeleteAlbumName(int id, Connection con) {
		String query = "delete from videoalbum_name where ID=?";
		int i=0;
		try{
			 ps=(PreparedStatement) con.prepareStatement(query);
			 ps.setInt(1, id);
			 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i;
	}

}

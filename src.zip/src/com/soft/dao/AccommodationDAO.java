package com.soft.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.soft.model.Accommodation;
import com.soft.model.Travel;

public class AccommodationDAO {
//    DBConnection dbc=new DBConnection();
//    Connection con=dbc.insertPreparequery();
    PreparedStatement ps= null;
    ResultSet rs = null;
    Statement stmt = null;
	
	public int addNewBlog(Accommodation ct, Connection con){
		int i=0;
	    try {	
	    	String query = "insert into accommodation_data(ACCOMMODATION_CATEGORY, SUBJECT_LINE, DESCRIPTION, IMAGE_PATH, ENTRY_BY, STATE, DISTRICT, CITY, STATUS, VIEW_COUNT, NAME, VIDEO_PATH, ENTRY_DATE)" 
						+ "VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, now())";	
			  ps=(PreparedStatement) con.prepareStatement(query);
			 ps.setString(1, ct.getAccommodationCategory());
			 ps.setString(2, ct.getSubjectLine());
			 ps.setString(3, ct.getDescription());
			 ps.setString(4, "NA");
			 ps.setString(5, ct.getEntryBy());
			 ps.setString(6, ct.getState());
			 ps.setString(7, ct.getDistrict());
			 ps.setString(8, ct.getCity());
			 ps.setString(9, ct.getStatus());
			 ps.setInt(10, 0);
			 ps.setString(11, ct.getName());
			 ps.setString(12, ct.getVideoPath());
			 i=ps.executeUpdate();
			 if(i!=0){
				 i= getLastBlogID(con);
				 System.out.println(" Blog Inserted  successfully");
			 }else {
				 System.out.println(" Blog is not Inserted");
			}
			 
		}
		 catch (Exception e){
			e.printStackTrace();
		}
		return i;	
	}
	public int updateBlogImagePath(String path, int id, Connection con) {
		String query = "update accommodation_data set IMAGE_PATH='"+path+"' where ID="+id;
		//DBConnection dbc = new DBConnection();
		int i=0;
		try{
			//i = dbc.insertquery(query);
			ps=(PreparedStatement) con.prepareStatement(query);
			i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return i;
	}
	
	public int updateIconPath(String thumbnail, int  id, Connection con) {
		int i=0;
		String query = "update accommodation_data set IMAGE_PATH=? where ID=?";
		try{
//		 con=dbc.insertPreparequery();
		  ps=(PreparedStatement) con.prepareStatement(query);
		 ps.setString(1, thumbnail);
		 ps.setInt(2, id);
		 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i;
	}
	
	public int updateBlogViewCount(int view, int id, Connection con) {
		String query = "update accommodation_data set VIEW_COUNT='"+view+"' where ID="+id;
		//DBConnection dbc = new DBConnection();
		int i=0;
		try{
			//i = dbc.insertquery(query);
			ps=(PreparedStatement) con.prepareStatement(query);
			i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return i;
	}
	
	public int updatImagePath(ArrayList<String> path, long id, Connection con) {
		int i=0;
		String url = "";
		try{
			for(String s : path){
				i = i+1;
				if(i==1){
					url += " IMAGE_PATH='"+s+"'";
				}else{
				url += ", IMAGE_PATH='"+s+"'";
				}
			}
			
			String query = "update accommodation_data set "+url+" where ID=?";
			 ps=(PreparedStatement) con.prepareStatement(query);
			 ps.setLong(1, id);
			 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i;
	}
	
	// Update Existing Category into Database.
	public int updateBlogDetail(Accommodation ct, Connection con){
		int i = 0;
	    try {  
	    	String query = "UPDATE accommodation_data set ACCOMMODATION_CATEGORY=?, SUBJECT_LINE=?, DESCRIPTION=?, ENTRY_BY=?, STATE=?, DISTRICT=?, CITY=?, STATUS=?, NAME=?, VIDEO_PATH=? WHERE ID = ?";
			 ps=(PreparedStatement) con.prepareStatement(query);
			 ps.setString(1, ct.getAccommodationCategory());
			 ps.setString(2, ct.getSubjectLine());
			 ps.setString(3, ct.getDescription());
			 ps.setString(4, ct.getEntryBy());
			 ps.setString(5, ct.getState());
			 ps.setString(6, ct.getDistrict());
			 ps.setString(7, ct.getCity());
			 ps.setString(8, ct.getStatus());
			 ps.setString(9, ct.getName());
			 ps.setString(10, ct.getVideoPath());
			 ps.setInt(11, ct.getId());
			i=ps.executeUpdate();
	    	if(i!=0){
				 System.out.println(i+" Blog Updated  Successfully");
			 }else {
				 System.out.println(" Blog not Updated");
			}
	    	
		}catch (Exception e) {
			e.printStackTrace();
		}
		return i;	
	}
	// Count Total Blog.
			public ArrayList<Accommodation> getBlogList(Connection con){		
				Accommodation ct =null;
				ArrayList<Accommodation> al = new ArrayList<Accommodation>();
				String query = "select * from accommodation_data order by ID DESC";
				try{
					// rs = dbc.selectquery(query);
					stmt = (Statement)con.createStatement();
					  rs = (ResultSet)stmt.executeQuery(query);
					while (rs.next()) {
						ct = new Accommodation();
						fillObjectFromDatabase(ct, con);
						al.add(ct);
					}
				}catch (Exception e) {
					e.printStackTrace();
				}
				return al;
			}
			
			
			// Get Down Line List mom database.
			public ArrayList<Accommodation> getBlogList(int id, Connection con){		
				Accommodation ct = null;
				int start = id - 10;
			    ArrayList<Accommodation> al = new ArrayList<Accommodation>();
				String query= "select * from accommodation_data where ID between "+start+" AND "+id+" ORDER BY ID DESC";
				try{	
					 stmt = (Statement)con.createStatement();
					  rs = (ResultSet)stmt.executeQuery(query);
					while(rs.next()){		
						ct = new Accommodation();
						fillObjectFromDatabase(ct, con);
						al.add(ct);
					}
				}
				catch (Exception e) {
					System.out.println("muits List not getting mom Database.");
				}finally {
		    // Always make sure result sets and statements are closed,
		    if (rs != null) {
			      try { rs.close(); } catch (SQLException e) { ; }
			      rs = null;
			    }
		    if (stmt != null) {
		      try { stmt.close(); } catch (SQLException e) { ; }
		      stmt = null;
		    }
		}
				return al;
			}

			// Count Total Blog.
					public ArrayList<Accommodation> getBlogListByFiiter(String category, Connection con){		
						Accommodation ct =null;
						ArrayList<Accommodation> al = new ArrayList<Accommodation>();
						String query = "select * from accommodation_data where CATEGORY='"+category+"' order by ID DESC";
						try{
							// rs = dbc.selectquery(query);
							stmt = (Statement)con.createStatement();
							  rs = (ResultSet)stmt.executeQuery(query);
							while (rs.next()) {
								ct = new Accommodation();
								fillObjectFromDatabase(ct, con);
								al.add(ct);
							}
						}catch (Exception e) {
							e.printStackTrace();
						}
						return al;
					}
					
					// Get Category List mom database.
					public ArrayList<Accommodation>  getBannerFilterList(String category, String state, String district, String city, Connection con){		
						Accommodation ct = null;
						String filter = " where 1=1";
						if(category!=null && !category.equals("")){
							filter +=" AND ACCOMMODATION_CATEGORY='"+category+"'";
						}
						if(state!=null && !state.equals("")){
							filter +=" AND STATE='"+state+"'";
						}
						if(district!=null && !district.equals("")){
							filter +=" AND DISTRICT='"+district+"'";
						}
						if(city!=null && !city.equals("")){
							filter +=" AND CITY='"+city+"'";
						}
						
						ArrayList<Accommodation> al = new ArrayList<Accommodation>();
						String query= "select * from accommodation_data "+filter+"  order by ID DESC";
						try{	
							 stmt = (Statement)con.createStatement();
							  rs = (ResultSet)stmt.executeQuery(query);
							while(rs.next()){		
								ct = new Accommodation();
								fillObjectFromDatabase(ct, con);
								al.add(ct);
							}
						}
						catch (Exception e) {
							System.out.println("Image Gallery List not getting mom Database.");
						}finally {
				    // Always make sure result sets and statements are closed,
				    if (rs != null) {
					      try { rs.close(); } catch (SQLException e) { ; }
					      rs = null;
					    }
				    if (stmt != null) {
				      try { stmt.close(); } catch (SQLException e) { ; }
				      stmt = null;
				    }
				}
						return al;
					}
					
					
					
					// Get Category List mom database.
					public ArrayList<Accommodation>  getSearchBlogQuote(String key, Connection con){		
						Accommodation ct = null;
						
						ArrayList<Accommodation> al = new ArrayList<Accommodation>();
						String query= "select * from accommodation_data where SUBJECT_LINE LIKE '%"+key+"%' order by ID DESC limit 24";
						try{	
							 stmt = (Statement)con.createStatement();
							  rs = (ResultSet)stmt.executeQuery(query);
							while(rs.next()){		
								ct = new Accommodation();
								fillObjectFromDatabase(ct, con);
								al.add(ct);
							}
						}
						catch (Exception e) {
							System.out.println("Image Gallery List not getting mom Database.");
						}finally {
				    // Always make sure result sets and statements are closed,
				    if (rs != null) {
					      try { rs.close(); } catch (SQLException e) { ; }
					      rs = null;
					    }
				    if (stmt != null) {
				      try { stmt.close(); } catch (SQLException e) { ; }
				      stmt = null;
				    }
				}
						return al;
					}
					
					
					// Get Category List mom database.
					public ArrayList<Accommodation>  getBannerFilterListWithLimit(String mainCategory, String subCategory, String childCategory, int limit, Connection con){		
						Accommodation ct = null;
						String filter = " where 1=1";
						if(mainCategory!=null && !mainCategory.equals("")){
							filter +=" AND STATE='"+mainCategory+"'";
						}
						if(subCategory!=null && !subCategory.equals("")){
							filter +=" AND DISTRICT='"+subCategory+"'";
						}
						if(childCategory!=null && !childCategory.equals("")){
							filter +=" AND CITY='"+childCategory+"'";
						}
						
						
						ArrayList<Accommodation> al = new ArrayList<Accommodation>();
						String query= "select * from accommodation_data "+filter+"  order by ID DESC limit "+limit+"";
						try{	
							 stmt = (Statement)con.createStatement();
							  rs = (ResultSet)stmt.executeQuery(query);
							while(rs.next()){		
								ct = new Accommodation();
								fillObjectFromDatabase(ct, con);
								al.add(ct);
							}
						}
						catch (Exception e) {
							System.out.println("Image Gallery List not getting mom Database.");
						}finally {
				    // Always make sure result sets and statements are closed,
				    if (rs != null) {
					      try { rs.close(); } catch (SQLException e) { ; }
					      rs = null;
					    }
				    if (stmt != null) {
				      try { stmt.close(); } catch (SQLException e) { ; }
				      stmt = null;
				    }
				}
						return al;
					}
					
					// Get Category List mom database.
					public ArrayList<Accommodation>  getBannerFilterListWithLimit(String category, String state, String district, String city, int limit, Connection con){		
						Accommodation ct = null;
						String filter = " where 1=1";
						if(category!=null && !category.equals("")){
							filter +=" AND ACCOMMODATION_CATEGORY='"+category+"'";
						}
						if(state!=null && !state.equals("")){
							filter +=" AND STATE='"+state+"'";
						}
						if(district!=null && !district.equals("")){
							filter +=" AND DISTRICT='"+district+"'";
						}
						if(city!=null && !city.equals("")){
							filter +=" AND CITY='"+city+"'";
						}
						
						
						ArrayList<Accommodation> al = new ArrayList<Accommodation>();
						String query= "select * from accommodation_data "+filter+"  order by ID DESC limit "+limit+"";
						try{	
							 stmt = (Statement)con.createStatement();
							  rs = (ResultSet)stmt.executeQuery(query);
							while(rs.next()){		
								ct = new Accommodation();
								fillObjectFromDatabase(ct, con);
								al.add(ct);
							}
						}
						catch (Exception e) {
							System.out.println("Image Gallery List not getting mom Database.");
						}finally {
				    // Always make sure result sets and statements are closed,
				    if (rs != null) {
					      try { rs.close(); } catch (SQLException e) { ; }
					      rs = null;
					    }
				    if (stmt != null) {
				      try { stmt.close(); } catch (SQLException e) { ; }
				      stmt = null;
				    }
				}
						return al;
					}
					
					
					// Get Category List mom database.
					public ArrayList<Accommodation>  getBannerFilterListMostViewed(int limit, Connection con){		
						Accommodation ct = null;
						ArrayList<Accommodation> al = new ArrayList<Accommodation>();
						String query= "select * from accommodation_data order by VIEW_COUNT DESC limit "+limit+"";
						try{	
							 stmt = (Statement)con.createStatement();
							  rs = (ResultSet)stmt.executeQuery(query);
							while(rs.next()){		
								ct = new Accommodation();
								fillObjectFromDatabase(ct, con);
								al.add(ct);
							}
						}
						catch (Exception e) {
							System.out.println("Image Gallery List not getting mom Database.");
						}finally {
				    // Always make sure result sets and statements are closed,
				    if (rs != null) {
					      try { rs.close(); } catch (SQLException e) { ; }
					      rs = null;
					    }
				    if (stmt != null) {
				      try { stmt.close(); } catch (SQLException e) { ; }
				      stmt = null;
				    }
				}
						return al;
					}
					
					// Get Category List mom database.
					public ArrayList<Accommodation>  getBannerFilterList(int limit, Connection con){		
						Accommodation ct = null;
												
						ArrayList<Accommodation> al = new ArrayList<Accommodation>();
						String query= "select * from accommodation_data order by ID DESC limit "+limit+"";
						try{	
							 stmt = (Statement)con.createStatement();
							  rs = (ResultSet)stmt.executeQuery(query);
							while(rs.next()){		
								ct = new Accommodation();
								fillObjectFromDatabase(ct, con);
								al.add(ct);
							}
						}
						catch (Exception e) {
							System.out.println("Image Gallery List not getting mom Database.");
						}finally {
				    // Always make sure result sets and statements are closed,
				    if (rs != null) {
					      try { rs.close(); } catch (SQLException e) { ; }
					      rs = null;
					    }
				    if (stmt != null) {
				      try { stmt.close(); } catch (SQLException e) { ; }
				      stmt = null;
				    }
				}
						return al;
					}
					
					
					// Get Category List mom database.
					public ArrayList<Accommodation>  getAccommodationList(int limit, Connection con){		
						Accommodation ct = null;
												
						ArrayList<Accommodation> al = new ArrayList<Accommodation>();
						String query= "select NAME from accommodation_data GROUP BY NAME";
						try{	
							 stmt = (Statement)con.createStatement();
							  rs = (ResultSet)stmt.executeQuery(query);
							while(rs.next()){		
								ct = new Accommodation();
								ct.setName(rs.getString("NAME"));
								al.add(ct);
							}
						}
						catch (Exception e) {
							System.out.println("Image Gallery List not getting mom Database.");
						}finally {
				    // Always make sure result sets and statements are closed,
				    if (rs != null) {
					      try { rs.close(); } catch (SQLException e) { ; }
					      rs = null;
					    }
				    if (stmt != null) {
				      try { stmt.close(); } catch (SQLException e) { ; }
				      stmt = null;
				    }
				}
						return al;
					}
					
					
					// Get Category List mom database.
					public ArrayList<Accommodation>  getAccommodationDistrictList(int limit, Connection con){		
						Accommodation ct = null;
												
						ArrayList<Accommodation> al = new ArrayList<Accommodation>();
						String query= "select DISTINCT DISTRICT from accommodation_data limit "+limit+"";
						try{	
							 stmt = (Statement)con.createStatement();
							  rs = (ResultSet)stmt.executeQuery(query);
							while(rs.next()){		
								ct = new Accommodation();
								ct.setDistrict(rs.getString("DISTRICT"));
								al.add(ct);
							}
						}
						catch (Exception e) {
							System.out.println("Image Gallery List not getting mom Database.");
						}finally {
				    // Always make sure result sets and statements are closed,
				    if (rs != null) {
					      try { rs.close(); } catch (SQLException e) { ; }
					      rs = null;
					    }
				    if (stmt != null) {
				      try { stmt.close(); } catch (SQLException e) { ; }
				      stmt = null;
				    }
				}
						return al;
					}
					
					
					// Get Category List mom database.
					public ArrayList<Accommodation>  getBlogSubCategoryList(int limit, Connection con){		
						Accommodation ct = null;
												
						ArrayList<Accommodation> al = new ArrayList<Accommodation>();
						String query= "select ACCOMMODATION_CATEGORY, count(ID) as ID from accommodation_data GROUP BY ACCOMMODATION_CATEGORY";
						try{	
							 stmt = (Statement)con.createStatement();
							  rs = (ResultSet)stmt.executeQuery(query);
							while(rs.next()){		
								ct = new Accommodation();
								ct.setAccommodationCategory(rs.getString("ACCOMMODATION_CATEGORY"));
								ct.setId(rs.getInt("ID"));
								al.add(ct);
							}
						}
						catch (Exception e) {
							System.out.println("Image Gallery List not getting mom Database.");
						}finally {
				    // Always make sure result sets and statements are closed,
				    if (rs != null) {
					      try { rs.close(); } catch (SQLException e) { ; }
					      rs = null;
					    }
				    if (stmt != null) {
				      try { stmt.close(); } catch (SQLException e) { ; }
				      stmt = null;
				    }
				}
						return al;
					}
					
					


					// Count Total Blog.
					public Accommodation getSingleBlogByCategoryFiiter(String category, Connection con){		
						Accommodation ct =null;
						String query = "select * from accommodation_data where CATEGORY='"+category+"' order by ID DESC LIMIT 1";
						try{
							// rs = dbc.selectquery(query);
							stmt = (Statement)con.createStatement();
							  rs = (ResultSet)stmt.executeQuery(query);
							while (rs.next()) {
								ct = new Accommodation();
								fillObjectFromDatabase(ct, con);
							}
						}catch (Exception e) {
							e.printStackTrace();
						}
						return ct;
					}
			
			/**
			 * @param ct
			 * @throws SQLException
			 */
			private void fillObjectFromDatabase(Accommodation ct, Connection con) throws SQLException {
				ct.setId(rs.getInt("ID"));
				ct.setViewCount(rs.getInt("VIEW_COUNT"));
				ct.setAccommodationCategory(rs.getString("ACCOMMODATION_CATEGORY"));
				ct.setSubjectLine(rs.getString("SUBJECT_LINE"));
				ct.setDescription(rs.getString("DESCRIPTION"));
				ct.setImagePath(rs.getString("IMAGE_PATH"));
				ct.setVideoPath(rs.getString("VIDEO_PATH"));
				ct.setEntryBy(rs.getString("ENTRY_BY"));
				ct.setState(rs.getString("STATE"));
				ct.setDistrict(rs.getString("DISTRICT"));
				ct.setCity(rs.getString("CITY"));
				ct.setStatus(rs.getString("STATUS"));
				ct.setName(rs.getString("NAME"));
				ct.setEntryDate(rs.getDate("ENTRY_DATE"));
				
			}
			// Count Total Blog.
						public Accommodation getBlogById(int id, Connection con){		
							Accommodation ct =null;
							String query = "select * from accommodation_data where ID="+id;
							try{
								 //rs = dbc.selectquery(query);
								stmt = (Statement)con.createStatement();
								  rs = (ResultSet)stmt.executeQuery(query);
								while (rs.next()) {
									ct = new Accommodation();
									fillObjectFromDatabase(ct, con);
								}
							}catch (Exception e) {
								e.printStackTrace();
							}
							return ct;
						}

						public Accommodation getBlogByURL(String url, Connection con){		
							Accommodation ct =null;
							String query = "select * from accommodation_data where TEXT_URL='"+url+"'";
							try{
								 //rs = dbc.selectquery(query);
								stmt = (Statement)con.createStatement();
								  rs = (ResultSet)stmt.executeQuery(query);
								while (rs.next()) {
									ct = new Accommodation();
									fillObjectFromDatabase(ct, con);
								}
							}catch (Exception e) {
								e.printStackTrace();
							}
							return ct;
						}
	// Count Total Blog.
		public int getLastBlogID(Connection con){		
			int i=0;
			String query = "select max(ID) as id from accommodation_data";
			try{
				//rs = dbc.selectquery(query);
				stmt = (Statement)con.createStatement();
				  rs = (ResultSet)stmt.executeQuery(query);
				while (rs.next()) {
					i = rs.getInt("id");
				}
				 if(i!=0){
					 System.out.println(i+" Row Selected");
				 }else {
					 System.out.println(i+" Please try Again.");
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
			return i;
		}

		//Delete Category into Database	
		public int deleteBlog(int id, Connection con){
			int i=0;
			String query = "delete from accommodation_data where ID="+id;
			try{
				// i = dbc.insertquery(query);
				ps=(PreparedStatement) con.prepareStatement(query);
				i=ps.executeUpdate();
				 if(i!=0){
					 System.out.println(i+" Blog Deleted  Successfully");
				 }else {
					 System.out.println(" Blog not Deleted.? Please try Again.");
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
			return i;	
		}
}

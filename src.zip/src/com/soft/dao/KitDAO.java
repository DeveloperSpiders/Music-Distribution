package com.soft.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

import com.soft.model.Kit;

public class KitDAO {
//    DBConnection dbc=new DBConnection();
	int i=0;
	Statement stmt = null;
	ResultSet rs = null;
//	Connection con =(Connection)DBConnection.getInstance().insertPreparequery();
	PreparedStatement ps = null;
	ResultSet rs1 = null;
	public int addNewKit(Kit m, Connection con) {
		String query = "insert into kit_program(KIT_NAME, COMMISSION_LEVEL1, COMMISSION_LEVEL2, COMMISSION_LEVEL3, COMMISSION_LEVEL4, COMMISSION_LEVEL5, COMMISSION_LEVEL6, COMMISSION_LEVEL7, COMMISSION_LEVEL8, COMMISSION_LEVEL9, COMMISSION_LEVEL10, COMMISSION_LEVEL11, COMMISSION_LEVEL12, COMMISSION_LEVEL13, COMMISSION_LEVEL14, COMMISSION_LEVEL15, COMMISSION_LEVEL16, KIT_DESCRIPTION, ENTRY_BY, ENTRY_DATE, KIT_AMOUNT, KIT_POINT_VALUE, CATEGORY, KIT_WEIGHT, GST_AMOUNT, GST_RATE, TOTAL_KIT) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, now(), ?, ?, ?, ?, ?, ?, 0)";
		try{
		 ps=(PreparedStatement) con.prepareStatement(query);
		 ps.setString(1, m.getKitName());
		 ps.setFloat(2, m.getFirstLevelCommission());
		 ps.setFloat(3, m.getCommissionLevel2());
		 ps.setFloat(4, m.getCommissionLevel3());
		 ps.setFloat(5, m.getCommissionLevel4());
		 ps.setFloat(6, m.getCommissionLevel5());
		 ps.setFloat(7, m.getCommissionLevel6());
		 ps.setFloat(8, m.getCommissionLevel7());
		 ps.setFloat(9, m.getCommissionLevel8());
		 ps.setFloat(10, m.getCommissionLevel9());
		 ps.setFloat(11, m.getCommissionLevel10());
		 ps.setFloat(12, m.getCommissionLevel11());
		 ps.setFloat(13, m.getCommissionLevel12());
		 ps.setFloat(14, m.getCommissionLevel13());
		 ps.setFloat(15, m.getCommissionLevel14());
		 ps.setFloat(16, m.getCommissionLevel15());
		 ps.setFloat(17, m.getCommissionLevel16());
		 ps.setString(18, m.getKitDescription());
		 ps.setString(19, m.getEntryBy());
		 ps.setFloat(20, m.getKitAmount());
		 ps.setInt(21, m.getKitPointValue());
		 ps.setString(22, m.getCategory());
		 ps.setFloat(23, m.getKitWeight());
		 ps.setFloat(24, m.getGstAmount());
		 ps.setFloat(25, m.getGstRate());
		 i=ps.executeUpdate();
		 if(i!=0){
			i= getLastBankAccountID(con);
		 }
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i;
	}

	public int updateTotalKit(int totalkit,  int kitID, Connection con) {
		String query = "update kit_program set TOTAL_KIT=TOTAL_KIT+"+totalkit+" where ID=?";
		try{
		  ps=(PreparedStatement) con.prepareStatement(query);
			 ps.setInt(1, kitID);
		 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i;
	}
	public int updateTotalKitIfPurchasedOrderDone(int kitID, Connection con) {
		String query = "update kit_program set TOTAL_KIT=TOTAL_KIT-1 where ID=?";
		try{
		  ps=(PreparedStatement) con.prepareStatement(query);
			 ps.setInt(1, kitID);
		 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i;
	}
	// Get Category List mom database.
	public ArrayList<Kit> getKitList(Connection con){		
		Kit mbr = null;
		ArrayList<Kit> al = new ArrayList<Kit>();
		String query= "select * from kit_program";
		try{	
//			ResultSet rs = dbc.selectquery(query);
			 stmt = (Statement)con.createStatement();
			  rs = (ResultSet)stmt.executeQuery(query);
			while(rs.next()){		
				mbr = getSingleBankEntry(rs);
					al.add(mbr);
				}
			}
			catch (Exception e) {
			System.out.println("bank account List not getting from Database.");
			}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
	   return al;
	}
	
				// Get Category List mom database.
				public Kit getSilglekitDetails(int id, Connection con){		
					Kit bnk = null;
//					ResultSet rs = null;
					String query= "select * from kit_program where ID="+id;
					try{	
//						 rs = dbc.selectquery(query);
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){		
							bnk = getSingleBankEntry(rs);
						}
					}
					catch (Exception e) {
						System.out.println("bank account List not getting mom Database.");
					}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
					return bnk;
				}
				// Get Category List mom database.
				public Kit getSilglekitDetailsByName(String kitName, Connection con){		
					Kit bnk = null;
//					ResultSet rs = null;
					String query= "select * from kit_program where KIT_NAME='"+kitName+"'";
					try{	
//						 rs = dbc.selectquery(query);
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){		
							bnk = getSingleBankEntry(rs);
						}
					}
					catch (Exception e) {
						System.out.println("bank account List not getting mom Database.");
					}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
					return bnk;
				}
				
				//Get AdminCategory Data Method
				private Kit getSingleBankEntry(ResultSet rs)
						throws SQLException {
					Kit b;
					b=new Kit();
					b.setId(rs.getInt("ID"));
					b.setKitName(rs.getString("KIT_NAME"));
					b.setEntryBy(rs.getString("ENTRY_BY"));
					b.setEntryDate(rs.getDate("ENTRY_DATE"));
					b.setKitDescription(rs.getString("KIT_DESCRIPTION"));
					b.setCategory(rs.getString("CATEGORY"));
					b.setCommissionLevel1(rs.getFloat("COMMISSION_LEVEL1"));
					b.setCommissionLevel2(rs.getFloat("COMMISSION_LEVEL2"));
					b.setCommissionLevel3(rs.getFloat("COMMISSION_LEVEL3"));
					b.setCommissionLevel4(rs.getFloat("COMMISSION_LEVEL4"));
					b.setCommissionLevel5(rs.getFloat("COMMISSION_LEVEL5"));
					b.setCommissionLevel6(rs.getFloat("COMMISSION_LEVEL6"));
					b.setCommissionLevel7(rs.getFloat("COMMISSION_LEVEL7"));
					b.setCommissionLevel8(rs.getFloat("COMMISSION_LEVEL8"));
					b.setCommissionLevel9(rs.getFloat("COMMISSION_LEVEL9"));
					b.setCommissionLevel10(rs.getFloat("COMMISSION_LEVEL10"));
					b.setCommissionLevel11(rs.getFloat("COMMISSION_LEVEL11"));
					b.setCommissionLevel12(rs.getFloat("COMMISSION_LEVEL12"));
					b.setCommissionLevel13(rs.getFloat("COMMISSION_LEVEL13"));
					b.setCommissionLevel14(rs.getFloat("COMMISSION_LEVEL14"));
					b.setCommissionLevel15(rs.getFloat("COMMISSION_LEVEL15"));
					b.setCommissionLevel16(rs.getFloat("COMMISSION_LEVEL16"));
					b.setKitPointValue(rs.getInt("KIT_POINT_VALUE"));
					b.setKitAmount(rs.getFloat("KIT_AMOUNT"));
					b.setKitWeight(rs.getFloat("KIT_WEIGHT"));
					b.setGstAmount(rs.getFloat("GST_AMOUNT"));
					b.setGstRate(rs.getFloat("GST_RATE"));
					b.setTotalKit(rs.getInt("TOTAL_KIT"));
					return b;
				}
	// Get Category List mom database.
	public int getLastBankAccountID(Connection con) {
		int id = 0;
		String query = "select MAX(ID) as ID from kit_program";
		try {
			 stmt = (Statement)con.createStatement();
			  rs = (ResultSet)stmt.executeQuery(query);
			while (rs.next()) {
				id = rs.getInt("ID");
			}
		} catch (Exception e) {
			System.out.println("Sorry! Please try again later.");
		}finally{
			// Always make sure result sets and statements are closed,
		    if (rs != null) {
			      try { rs.close(); } catch (SQLException e) { ; }
			      rs = null;
			    }
		    if (stmt != null) {
		      try { stmt.close(); } catch (SQLException e) { ; }
		      stmt = null;
		    }
			}
		return id;
	}
	public int deleteKit(int id, Connection con) {
		String query = "delete from kit_program where ID=?";
		int i=0;
		try{
			 ps=(PreparedStatement) con.prepareStatement(query);
			 ps.setInt(1, id);
			 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			// Always make sure result sets and statements are closed,
		    if (ps != null) {
			      try { ps.close(); } catch (SQLException e) { ; }
			      ps = null;
			    }
		    
			}
		return i;
	}

	// he is new joining he will get the details of receiver from him.
			public HashMap<String, ArrayList<Kit>> selectKitListByCategoryForDIsplay(Connection con){		
				String query1 = null;
				Kit b = null;
				String category = null;
				ArrayList<Kit> chldList = null;
				HashMap<String, ArrayList<Kit>> hm = new HashMap<String, ArrayList<Kit>>();
				String query = "select * from category order by ID ASC";
				try{	
					  stmt = (Statement)con.createStatement();
					  rs = (ResultSet)stmt.executeQuery(query);
					  while (rs.next()){
						  category = rs.getString("MAIN_CATEGORY");
						  // here sub Category
						  query1= "select * from kit_program where CATEGORY='"+category+"' AND TOTAL_KIT>0 order by KIT_NAME ASC";
						  stmt = (Statement)con.createStatement();
						  rs1 = (ResultSet)stmt.executeQuery(query1);
						  chldList = new ArrayList<Kit>();
						  while (rs1.next()){
							    b= new Kit();
								b.setId(rs1.getInt("ID"));
								b.setKitName(rs1.getString("KIT_NAME"));
								b.setCategory(rs1.getString("CATEGORY"));
								b.setKitAmount(rs1.getFloat("KIT_AMOUNT"));
							  chldList.add(b); 
						  }
						hm.put(category, chldList);
					}
				}
				catch (Exception e) {
					System.out.println("muits List not getting mom Database.");
				}finally{
					// Always make sure result sets and statements are closed,
				    if (rs != null) {
					      try { rs.close(); } catch (SQLException e) { ; }
					      rs = null;
					    }
				    if (stmt != null) {
				      try { stmt.close(); } catch (SQLException e) { ; }
				      stmt = null;
				    }
					}
				return hm;
			}
}

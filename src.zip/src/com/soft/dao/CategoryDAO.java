package com.soft.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;

import com.soft.model.Category;
import com.soft.model.ChildCategory;
import com.soft.utility.DBConnection;

public class CategoryDAO {
	int i=0;
	Statement stmt = null;
	ResultSet rs = null;
//	Connection con = (Connection)DBConnection.getInstance().insertPreparequery();
	PreparedStatement ps = null;
	ResultSet rsCategory = null;
	 ResultSet rs1 = null;
	public int addCategory(Category  c, Connection con) {
		String query = "insert into category(MAIN_CATEGORY, SUB_CATEGORY, EXTRAS, ENTRY_BY, ENTRY_DATE) values(?, ?, ?, ?, now())";
		try{
		 ps=(PreparedStatement) con.prepareStatement(query);
		 ps.setString(1, c.getMainCategory());
		 ps.setString(2, c.getSubCategory());
		 ps.setString(3, c.getExtras());
		 ps.setString(4, c.getEntryBy());
		 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i;
	}
	// he is new joining he will get the details of receiver from him.
			public ArrayList<Category> selectCategoryList(Connection con){		
				Category c = null;
				ArrayList<Category> al = new ArrayList<Category>();
				String query= "select * from category order by ID DESC";
				try{	
					  stmt = (Statement)con.createStatement();
					  rs = (ResultSet)stmt.executeQuery(query);
					  while (rs.next()){
						  c = new Category();
						  c.setId(rs.getInt("ID"));
						  c.setEntryBy(rs.getString("ENTRY_BY"));
						  c.setEntryDate(rs.getDate("ENTRY_DATE").toString());
						  c.setExtras(rs.getString("EXTRAS"));
						  c.setMainCategory(rs.getString("MAIN_CATEGORY"));
						  c.setSubCategory(rs.getString("SUB_CATEGORY"));
						  al.add(c);
					}
				}
				catch (Exception e) {
					System.out.println("muits List not getting mom Database.");
				}finally{
					try{
						 rs.close();
						 stmt.close();
						}catch (Exception e) {
							e.printStackTrace();
						}
					}
				return al;
			}

			// he is new joining he will get the details of receiver from him.
					public ArrayList<Category> selectCategoryListByMainCategory(String mainCategory, Connection con){		
						Category c = null;
						ArrayList<Category> al = new ArrayList<Category>();
						String query= "select * from category where SUB_CATEGORY='"+mainCategory+"' order by SUB_CATEGORY DESC";
						try{	
							  stmt = (Statement)con.createStatement();
							  rs = (ResultSet)stmt.executeQuery(query);
							  while (rs.next()) {
								  c = new Category();
								  c.setId(rs.getInt("ID"));
								  c.setEntryBy(rs.getString("ENTRY_BY"));
								  c.setEntryDate(rs.getDate("ENTRY_DATE").toString());
								  c.setExtras(rs.getString("EXTRAS"));
								  c.setMainCategory(rs.getString("MAIN_CATEGORY"));
								  c.setSubCategory(rs.getString("SUB_CATEGORY"));
								  al.add(c);
							}
						}
						catch (Exception e) {
							System.out.println("muits List not getting mom Database.");
						}finally{
							try{
								 rs.close();
								 stmt.close();
								}catch (Exception e) {
									e.printStackTrace();
								}
							}
						return al;
					}
			// he is new joining he will get the details of receiver from him.
					public int totalCategoryCount(Connection con){		
						int count=0;
						String query= "select max(ID) as ID from category";
						try{	
							  stmt = (Statement)con.createStatement();
							  rs = (ResultSet)stmt.executeQuery(query);
							  while (rs.next()) {
								count = rs.getInt("ID");
							}
						}
						catch (Exception e) {
							System.out.println("muits List not getting mom Database.");
						}finally{
							try{
								 rs.close();
								 stmt.close();
								}catch (Exception e) {
									e.printStackTrace();
								}
							}
						return count;
					}

					public int deleteCategory(int id, Connection con) {
						String query = "delete from category where ID=?";
						int i=0;
						try{
							 ps=(PreparedStatement) con.prepareStatement(query);
							 ps.setInt(1, id);
							 i=ps.executeUpdate();
						}catch (Exception e) {
							e.printStackTrace();
						}finally{
							try{
								 ps.close();
								}catch (Exception e) {
									e.printStackTrace();
								}
							}
						return i;
					}
					
					// he is new joining he will get the details of receiver from him.
					public LinkedHashMap<String, LinkedHashMap<String, ArrayList<ChildCategory>>> selectCompleteMenuTriLayer(Connection con){		
						LinkedHashMap<String, ArrayList<ChildCategory>> scMenu = null;
						LinkedHashMap<String, LinkedHashMap<String, ArrayList<ChildCategory>>> menuhm = new LinkedHashMap<String, LinkedHashMap<String,ArrayList<ChildCategory>>>();
						String query= "select * from category";
						try{	
							  stmt = (Statement)con.createStatement();
							  rsCategory = (ResultSet)stmt.executeQuery(query);
							  while (rsCategory.next()) {
								 scMenu = new LinkedHashMap<String, ArrayList<ChildCategory>>();
								 scMenu = selectCategoryListForDIsplay(rsCategory.getString("MAIN_CATEGORY"), con);
								 menuhm.put(rsCategory.getString("MAIN_CATEGORY"), scMenu);
								 System.out.println(rsCategory.getString("MAIN_CATEGORY")+" : CATEGORY ");
							}
						}
						catch (Exception e) {
							System.out.println("muits List not getting mom Database.");
						}finally{
							try{
								rsCategory.close();
								 stmt.close();
								}catch (Exception e) {
									e.printStackTrace();
								}
							}
						return menuhm;
					}
					
					// he is new joining he will get the details of receiver from him.
					public LinkedHashMap<String, ArrayList<ChildCategory>> selectCategoryListForDIsplay(String category, Connection con){		
						String query1 = null;
						String subCategory = null;
						ChildCategory cc = null;
						ArrayList<ChildCategory> chldList = null;
						LinkedHashMap<String, ArrayList<ChildCategory>> hm = new LinkedHashMap<String, ArrayList<ChildCategory>>();
						String query = "select * from top_category where MAIN_CATEGORY='"+category+"' order by ID ASC";
						try{	
							  stmt = (Statement)con.createStatement();
							  rs = (ResultSet)stmt.executeQuery(query);
							  while (rs.next()){
								  subCategory = rs.getString("SUB_CATEGORY");
									 System.out.println(rs.getString("SUB_CATEGORY")+" UNDER CHILD CATEGORY: ");
								  // here sub Category
								  query1= "select * from child_category where SUB_CATEGORY='"+subCategory+"' AND MAIN_CATEGORY='"+category+"' order by ID ASC";
								  stmt = (Statement)con.createStatement();
								  rs1 = (ResultSet)stmt.executeQuery(query1);
								  chldList = new ArrayList<ChildCategory>();
								  while (rs1.next()){
									  cc= new ChildCategory();
									  cc.setExtras(rs1.getString("EXTRAS"));
									  cc.setCategory(rs1.getString("MAIN_CATEGORY"));
									  cc.setSubcategory(rs1.getString("SUB_CATEGORY"));
									  chldList.add(cc); 
//										 System.out.println(rs1.getString("SUB_CATEGORY")+" SUBCTG LOOP IN CHILD CATEGORY:  "+rs1.getString("EXTRAS"));
								  }
								hm.put(subCategory, chldList);
							}
						}
						catch (Exception e) {
							System.out.println("muits List not getting mom Database.");
						}finally{
							try{
								 rs1.close();
								 rs.close();
								 stmt.close();
								}catch (Exception e) {
									e.printStackTrace();
								}
							}
						return hm;
					}
					

					// he is new joining he will get the details of receiver from him.
							public HashMap<String, ArrayList<String>> selectCategoryListForDIsplay(Connection con){		
								String query1 = null;
								String mainCategory = null;
								ChildCategory cc = null;
								ArrayList<String> subList = null;
								HashMap<String, ArrayList<String>> hm = new HashMap<String, ArrayList<String>>();
								String query = "select * from category order by ID ASC";
								try{	
									  stmt = (Statement)con.createStatement();
									  rs = (ResultSet)stmt.executeQuery(query);
									  while (rs.next()){
										  mainCategory = rs.getString("MAIN_CATEGORY");
											 System.out.println(rs.getString("MAIN_CATEGORY")+" UNDER CHILD CATEGORY: ");
										  // here sub Category
										  query1= "select * from top_category where MAIN_CATEGORY='"+mainCategory+"' order by ID ASC";
										  stmt = (Statement)con.createStatement();
										  rs1 = (ResultSet)stmt.executeQuery(query1);
										  subList = new ArrayList<String>();
										  while (rs1.next()){
											  subList.add(rs1.getString("SUB_CATEGORY")); 
//												 System.out.println(rs1.getString("SUB_CATEGORY")+" SUBCTG LOOP IN CHILD CATEGORY:  "+rs1.getString("EXTRAS"));
										  }
										hm.put(mainCategory, subList);
									}
								}
								catch (Exception e) {
									System.out.println("muits List not getting mom Database.");
								}finally{
									try{
										 rs1.close();
										 rs.close();
										 stmt.close();
										}catch (Exception e) {
											e.printStackTrace();
										}
									}
								return hm;
							}
					
}

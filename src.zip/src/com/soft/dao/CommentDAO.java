package com.soft.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.soft.model.Comment;

public class CommentDAO {
	
	int i=0;
	 PreparedStatement ps= null;
	 ResultSet rs = null;
	 Statement stmt = null;
//	Connection con = null;
//    DBConnection dbc=new DBConnection();
    //Insert Comment Into Database
	public int addNewComment(Comment comment, Connection con)
	{			
	    try
	    {	String query = "insert into comment(BLOG_ID, TYPE, NAME, CONTACT_NO, EMAIL_ID, COMMENT, STATUS, RATTING)" 
						+ "VALUES(?, ?, ?, ?, ?, ?, ?, ?)";	
			 //con=dbc.insertPreparequery();
			 PreparedStatement ps=(PreparedStatement) con.prepareStatement(query);
			 setCommentmethod(comment, ps);
			 i=ps.executeUpdate();
			 if(i!=0){
				 System.out.println(" Comment Inserted  successfully");
			 }else {
				 System.out.println(" Comment is not Inserted");
			}
			 
		}
		 catch (Exception e)
		 {
			e.printStackTrace();
		}
		return i;	
	}
	
	// Count Total Comment.
	public int getLastCommentID(Connection con)
	{		
		String query = "select max(ID) as ID from comment";
		try{
			//ResultSet rs = dbc.selectquery(query);
			stmt = (Statement)con.createStatement();
			  rs = (ResultSet)stmt.executeQuery(query);
			while (rs.next()) {
				i = rs.getInt("ID");
			}
			 if(i!=0){
				 System.out.println(i+" Row Selected");
			 }else {
				 System.out.println(i+" Please try Again.");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return i;
	}
	
// Get Comment List from database.
	public ArrayList<Comment> getCommentDetailListOne(int rowNo, Connection con)
	{		
		Comment comment=null;
		ArrayList<Comment> arraylist = new ArrayList<Comment>();
		int firstNo = 1;
		int lastNo = rowNo;
		if(rowNo>20)
			firstNo = rowNo-19;
		String query= "select * from comment where STATUS='1' AND ID BETWEEN "+firstNo+" AND "+lastNo+" ORDER BY ID DESC";
		try{	
			// ResultSet rs = dbc.selectquery(query);
			stmt = (Statement)con.createStatement();
			  rs = (ResultSet)stmt.executeQuery(query);
			while(rs.next())
			{		
				comment = gettingCommentMethod(rs);
				arraylist.add(comment);
			}
			}catch (Exception e) {
				System.out.println("Comment List not getting from Database.");
			}
		return arraylist;
	}
	
	// Get Comment List from database.
		public ArrayList<Comment> getCommentDetailListTwo(int rowNo, Connection con)
		{		
			Comment comment=null;
			ArrayList<Comment> arraylist = new ArrayList<Comment>();
			int firstNo = 1;
			int lastNo = rowNo;
			if(rowNo>20)
				firstNo = rowNo-19;
			String query= "select * from comment where STATUS='0' AND ID BETWEEN "+firstNo+" AND "+lastNo+" ORDER BY ID DESC";
			try{	
				// ResultSet rs = dbc.selectquery(query);
				stmt = (Statement)con.createStatement();
				  rs = (ResultSet)stmt.executeQuery(query);
				while(rs.next())
				{		
					comment = gettingCommentMethod(rs);
					arraylist.add(comment);
				}
				}catch (Exception e) {
					System.out.println("Comment List not getting from Database.");
				}
			return arraylist;
		}
		
		
		// Get Comment List from database.
				public ArrayList<Comment> getCommentDetailList(int rowNo, Connection con)
				{		
					Comment comment=null;
					ArrayList<Comment> arraylist = new ArrayList<Comment>();
					int firstNo = 1;
					int lastNo = rowNo;
					if(rowNo>20)
						firstNo = rowNo-19;
					String query= "select * from comment where ID BETWEEN "+firstNo+" AND "+lastNo+" ORDER BY ID DESC";
					try{	
						// ResultSet rs = dbc.selectquery(query);
						stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next())
						{		
							comment = gettingCommentMethod(rs);
							arraylist.add(comment);
						}
						}catch (Exception e) {
							System.out.println("Comment List not getting from Database.");
						}
					return arraylist;
				}
	// Get Comment List from database.
		public ArrayList<Comment> getCommentListForUser(int companyId, String type, Connection con)
		{		
			Comment comment=null;
			ArrayList<Comment> arraylist = new ArrayList<Comment>();
			String query= "select * from comment where BLOG_ID='"+companyId+"' AND TYPE='"+type+"' AND STATUS='1'";
			try{	
				 //ResultSet rs = dbc.selectquery(query);
				stmt = (Statement)con.createStatement();
				  rs = (ResultSet)stmt.executeQuery(query);
				while(rs.next())
				{		
					comment = gettingCommentMethod(rs);
					arraylist.add(comment);
				}
				}catch (Exception e) {
					System.out.println("Comment not getting from Database.");
				}
			return arraylist;
		}

		// Get Comment List from database.
			public ArrayList<Comment> getCommentListForHomePage(Connection con)
			{		
				Comment comment=null;
				ArrayList<Comment> arraylist = new ArrayList<Comment>();
				String query= "select * from comment where STATUS='1' Order By ID  LIMIT 20";
				try{	
					// ResultSet rs = dbc.selectquery(query);
					stmt = (Statement)con.createStatement();
					  rs = (ResultSet)stmt.executeQuery(query);
					while(rs.next())
					{		
						comment = gettingCommentMethod(rs);
						arraylist.add(comment);
					}
					}catch (Exception e) {
						System.out.println("Comment not getting from Database.");
					}
				return arraylist;
			}
	//Get total Comment
		public int getTotalCommentID(int companyId, Connection con)
		{		
			String query = "select COUNT(BLOG_ID) as BLOG_ID from comment where BLOG_ID='"+companyId+"' AND STATUS='1'";
			try{
				//ResultSet rs = dbc.selectquery(query);
				stmt = (Statement)con.createStatement();
				  rs = (ResultSet)stmt.executeQuery(query);
				while (rs.next()) {
					i = rs.getInt("BLOG_ID");
				}
				 if(i!=0){
					 System.out.println(i+" Row Selected");
				 }else {
					 System.out.println(i+" Please try Again.");
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
			return i;
		}
		
		public int getTotalRateID(int companyId, Connection con)
		{		
			String query = "select SUM(RATTING) as RATTING from comment where BLOG_ID='"+companyId+"' AND STATUS='1'";
			try{
				//ResultSet rs = dbc.selectquery(query);
				stmt = (Statement)con.createStatement();
				  rs = (ResultSet)stmt.executeQuery(query);
				while (rs.next()) {
					i = rs.getInt("RATTING");
				}
				 if(i!=0){
					 System.out.println(i+" Row Selected");
				 }else {
					 System.out.println(i+" Please try Again.");
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
			return i;
		}
	
	
	//Delete Comment into Database	
	public int deleteComment(int id, Connection con)
	{	
		String query = "delete from comment where ID='"+id+"'";
		try{
			 //i = dbc.insertquery(query);
			ps=(PreparedStatement) con.prepareStatement(query);
			i=ps.executeUpdate();
			 if(i!=0){
				 System.out.println(i+" Comment Deleted  Successfully");
			 }else {
				 System.out.println(" Comment not Deleted.? Please try Again.");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return i;	
	}
	
	
	public int editStatus(int id, String status, Connection con)
	{
			String query = "update comment set STATUS='"+status+"' where ID='"+id+"'";
			try{
				// i = dbc.insertquery(query);
				ps=(PreparedStatement) con.prepareStatement(query);
				i=ps.executeUpdate();
				 if(i!=0){
						System.out.println(i+" Row updated  successfully");
				 }else {
					 System.out.println(" Table Not updated  successfully. ? Please Try Again.");
				 }
			  }catch (Exception e) {
				e.printStackTrace();
	          }
		return i;
	}
	
	// set Comment Data method
	private void setCommentmethod(Comment comment, PreparedStatement ps)
			throws SQLException {
		ps.setInt(1, comment.getCompanyId());
		ps.setString(2, comment.getType());
		ps.setString(3, comment.getName());
		ps.setString(4, comment.getContactNo());
		ps.setString(5, comment.getEmailId());
		ps.setString(6, comment.getComment());
		ps.setString(7, comment.getStatus());
		ps.setInt(8, comment.getRating());
		
	}
	
	//Get Comment Data Method
	private Comment gettingCommentMethod(ResultSet rs)
			throws SQLException {
		Comment comment;
		comment=new Comment();
		comment.setId(rs.getInt("ID"));
		comment.setCompanyId(rs.getInt("BLOG_ID"));	
		comment.setName(rs.getString("NAME"));
		comment.setContactNo(rs.getString("CONTACT_NO"));
		comment.setEmailId(rs.getString("EMAIL_ID"));
		comment.setComment(rs.getString("COMMENT"));
		comment.setRating(rs.getInt("RATTING"));
		comment.setStatus(rs.getString("STATUS"));
		comment.setType(rs.getString("TYPE"));
		return comment;
	}

}

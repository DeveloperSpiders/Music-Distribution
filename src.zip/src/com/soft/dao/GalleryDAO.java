package com.soft.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.soft.model.AlbumName;
import com.soft.model.Gallery;

public class GalleryDAO {

//    DBConnection dbc=new DBConnection();
	int i=0;
	Statement stmt = null;
	ResultSet rs = null;
//	Connection con = (Connection)DBConnection.getInstance().insertPreparequery();
	PreparedStatement ps = null;
	public int addNewIamgeInGallery(Gallery m, Connection con) {
		String query = "insert into image_gallery(SUBJECT_LINE, ALBUM_NAME, IAMGE_PATH, ENTRY_BY, ENTRY_DATE) values(?, ?, 'NA', 'ADMIN', now())";
		try{
//		 con=dbc.insertPreparequery();
		 ps=(PreparedStatement) con.prepareStatement(query);
		 ps.setString(1, m.getSubject());
		 ps.setString(2, m.getAlbumName());
		 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return getLastImageGalleryID(con);
	}
	public int updateIconPath(String iconPath, int  id, Connection con) {
		String query = "update image_gallery set ICON_PATH=? where ID=?";
		try{
//		 con=dbc.insertPreparequery();
		  ps=(PreparedStatement) con.prepareStatement(query);
		 ps.setString(1, iconPath);
		 ps.setInt(2, id);
		 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i;
	}
	
	public int updatImagePath(ArrayList<String> path, long id, Connection con) {
		int i=0;
		String url = "";
		try{
			for(String s : path){
				i = i+1;
				if(i==1){
					url += " IAMGE_PATH='"+s+"'";
				}else{
				url += ", IAMGE_PATH='"+s+"'";
				}
			}
			
			String query = "update image_gallery set "+url+" where ID=?";
			 ps=(PreparedStatement) con.prepareStatement(query);
			 ps.setLong(1, id);
			 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i;
	}
				// Get Category List mom database.
				public ArrayList<AlbumName>  getAlbumList(int id, Connection con){		
					AlbumName g = null;
					ArrayList<AlbumName> al = new ArrayList<AlbumName>();
					String query= "select * from album_name ";
					try{	
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){		
							g = new AlbumName();
							g.setSubject(rs.getString("SUBJECT"));
							g.setImagePath(rs.getString("IMAGE_PATH"));
							g.setEntryBy(rs.getString("ENTRY_BY"));
							g.setId(rs.getInt("ID"));
							al.add(g);
						}
					}
					catch (Exception e) {
						System.out.println("Image Gallery List not getting mom Database.");
					}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
					return al;
				}
				
				// Get Category List mom database.
				public ArrayList<Gallery>  getImageGalleryList(int id, Connection con){		
					Gallery g = null;
					ArrayList<Gallery> al = new ArrayList<Gallery>();
					String query= "select * from image_gallery ";
					try{	
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){		
							g = new Gallery();
							g.setEntryBy(rs.getString("ENTRY_BY"));
							g.setEntryDate(rs.getDate("ENTRY_DATE"));
							g.setAlbumName(rs.getString("ALBUM_NAME"));
							g.setImagePath(rs.getString("IAMGE_PATH"));
							g.setSubject(rs.getString("SUBJECT_LINE"));
							g.setId(rs.getInt("ID"));
							al.add(g);
						}
					}
					catch (Exception e) {
						System.out.println("Image Gallery List not getting mom Database.");
					}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
					return al;
				}
	// Get Category List mom database.
	public int getLastImageGalleryID(Connection con) {
		int id = 0;
//		ResultSet rs = null;
		String query = "select MAX(ID) as ID from image_gallery";
		try {
			 stmt = (Statement)con.createStatement();
			  rs = (ResultSet)stmt.executeQuery(query);
			while (rs.next()) {
				id = rs.getInt("ID");
			}
		} catch (Exception e) {
			System.out.println("Sorry! Please try again later.");
		}finally{
			try{
				 rs.close();
				 stmt.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return id;
	}

	public int deleteIamgeFromGallery(int id, Connection con) {
		String query = "delete from image_gallery where ID=?";
		int i=0;
		try{
			 ps=(PreparedStatement) con.prepareStatement(query);
			 ps.setInt(1, id);
			 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i;
	}
	
	
	// Get Category List mom database.
	public ArrayList<Gallery>  getImageGalleryFilterList(String album, Connection con){		
		Gallery g = null;
		String filter = " where 1=1";
		if(album!=null && !album.equals("")){
			filter +=" AND ALBUM_NAME='"+album+"'";
		}
		
		ArrayList<Gallery> al = new ArrayList<Gallery>();
		String query= "select * from image_gallery "+filter+"  order by ID DESC";
		try{	
			 stmt = (Statement)con.createStatement();
			  rs = (ResultSet)stmt.executeQuery(query);
			while(rs.next()){		
				g = new Gallery();
				g.setEntryBy(rs.getString("ENTRY_BY"));
				g.setEntryDate(rs.getDate("ENTRY_DATE"));
				g.setAlbumName(rs.getString("ALBUM_NAME"));
				g.setImagePath(rs.getString("IAMGE_PATH"));
				g.setSubject(rs.getString("SUBJECT_LINE"));
				g.setId(rs.getInt("ID"));
				al.add(g);
			}
		}
		catch (Exception e) {
			System.out.println("Image Gallery List not getting mom Database.");
		}finally {
    // Always make sure result sets and statements are closed,
    if (rs != null) {
	      try { rs.close(); } catch (SQLException e) { ; }
	      rs = null;
	    }
    if (stmt != null) {
      try { stmt.close(); } catch (SQLException e) { ; }
      stmt = null;
    }
}
		return al;
	}
	
	
	// Get Category List mom database.
		public ArrayList<Gallery>  getImageGalleryFilterList(String album, int limit, Connection con){		
			Gallery g = null;
			String filter = " where 1=1";
			if(album!=null && !album.equals("")){
				filter +=" AND ALBUM_NAME='"+album+"'";
			}
			
			ArrayList<Gallery> al = new ArrayList<Gallery>();
			String query= "select * from image_gallery "+filter+"  order by ID DESC limit "+limit+"";
			try{	
				 stmt = (Statement)con.createStatement();
				  rs = (ResultSet)stmt.executeQuery(query);
				while(rs.next()){		
					g = new Gallery();
					g.setEntryBy(rs.getString("ENTRY_BY"));
					g.setEntryDate(rs.getDate("ENTRY_DATE"));
					g.setAlbumName(rs.getString("ALBUM_NAME"));
					g.setImagePath(rs.getString("IAMGE_PATH"));
					g.setSubject(rs.getString("SUBJECT_LINE"));
					g.setId(rs.getInt("ID"));
					al.add(g);
				}
			}
			catch (Exception e) {
				System.out.println("Image Gallery List not getting mom Database.");
			}finally {
	    // Always make sure result sets and statements are closed,
	    if (rs != null) {
		      try { rs.close(); } catch (SQLException e) { ; }
		      rs = null;
		    }
	    if (stmt != null) {
	      try { stmt.close(); } catch (SQLException e) { ; }
	      stmt = null;
	    }
	}
			return al;
		}
	
	
}

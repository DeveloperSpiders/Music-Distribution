package com.soft.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import com.soft.model.Label;
import com.soft.model.Video;

public class LabelDAO {
 // DBConnection dbc=new DBConnection();
	int i=0;
	Statement stmt = null;
	ResultSet rs = null;
	ResultSet rs1 = null;
	//Connection con = (Connection)dbc.insertPreparequery();
	PreparedStatement ps = null;
	public int addNewBlog(Label s,Connection con) {
		String query = "insert into label_list(TITLE, SUBJECT_LINE, VIEW_COUNT, DESCRIPTION, IMAGE_PATH, TEXT_URL, ENTRY_BY, ENTRY_DATE, STATUS) values(?, ?, ?, ?, 'NA', ?, ?, now(), ?)";
		try{
		 ps=(PreparedStatement) con.prepareStatement(query);
		 ps.setString(1, s.getTitle());
		 ps.setString(2, s.getSubject());
		 ps.setInt(3, 1);
		 ps.setString(4, s.getDescription());
		 ps.setString(5, s.getTextUrl());
		 ps.setString(6, s.getEntryBy());
		 ps.setString(7, s.getStatus());
		 i=ps.executeUpdate();
		 if(i!=0){
			 i = getLastImageBlogID(con);
		 }
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return getLastImageBlogID(con);
	}
	
	public int updateBlogDetails(Label s, Connection con) {
		String query = "update label_list set TITLE=?, SUBJECT_LINE=?, DESCRIPTION=?, TEXT_URL=?, ENTRY_BY=?, STATUS=? where ID=?";
		//DBConnection dbc = new DBConnection();
		int i=0;
		try{
			PreparedStatement ps=(PreparedStatement) con.prepareStatement(query);
			ps.setString(1, s.getTitle());
			 ps.setString(2, s.getSubject());
			 ps.setString(3, s.getDescription());
			 ps.setString(4, s.getTextUrl());
			 ps.setString(5, s.getEntryBy());
			 ps.setString(6, s.getStatus());
			 ps.setInt(7, s.getId());
			 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return i;
	}
	
	public int updateURLDetails(Label s, Connection con) {
		String query = "update label_list set SUBJECT_LINE=?, DESCRIPTION=?, STATUS=? where ID="+s.getId();
		//DBConnection dbc = new DBConnection();
		int i=0;
		try{
			PreparedStatement ps=(PreparedStatement) con.prepareStatement(query);
			 ps.setString(1, s.getSubject());
			 ps.setString(2, s.getDescription());
			 ps.setString(3, s.getStatus());
			 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return i;
	}
	
	
	public int updateURLStatus(String status, int id, Connection con) {
		String query = "update label_list set STATUS=? where ID="+id;
		//DBConnection dbc = new DBConnection();
		int i=0;
		try{
			PreparedStatement ps=(PreparedStatement) con.prepareStatement(query);
			 ps.setString(1,status);
			 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return i;
	}
	
	
	public int updateBlogImagePath(String imagePath, int id, Connection con) {
		String query = "update label_list set IMAGE_PATH='"+imagePath+"' where ID="+id;
		//DBConnection dbc = new DBConnection();
		int i=0;
		try{
			ps=(PreparedStatement) con.prepareStatement(query);
			i = ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return i;
	}
	
	
	// Get Category List mom database.
		public ArrayList<Label>  getImageBlogListForDisplay(int id, Connection con){		
			Label g = null;
			ArrayList<Label> al = new ArrayList<Label>();
			String query= "select * from label_list where ID='"+id+"'";
			try{	
				 stmt = (Statement)con.createStatement();
				  rs = (ResultSet)stmt.executeQuery(query);
				while(rs.next()){		
					g = new Label();
					g.setEntryBy(rs.getString("ENTRY_BY"));
					g.setEntryDate(rs.getDate("ENTRY_DATE"));
					g.setId(rs.getInt("ID"));
					g.setViewCount(rs.getInt("VIEW_COUNT"));
					g.setDescription(rs.getString("DESCRIPTION"));
					g.setImagePath(rs.getString("IMAGE_PATH"));
					g.setTextUrl(rs.getString("TEXT_URL"));
					g.setSubject(rs.getString("SUBJECT_LINE"));
					g.setStatus(rs.getString("STATUS"));
					g.setTitle(rs.getString("TITLE"));
					
					al.add(g);
				}
			}
			catch (Exception e) {
				System.out.println("Image Banner List not getting mom Database.");
			}finally{
				try{
					 rs.close();
					 stmt.close();
					}catch (Exception e) {
						e.printStackTrace();
					}
				}
			return al;
		}
	
		
		// Get Category List mom database.
				public ArrayList<Label>  getSingleBlogListByEntryBy(String id, Connection con){		
					Label g = null;
					ArrayList<Label> al = new ArrayList<Label>();
					String query= "select * from label_list where ENTRY_BY='"+id+"'";
					try{	
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){		
							g = new Label();
							g.setEntryBy(rs.getString("ENTRY_BY"));
							g.setEntryDate(rs.getDate("ENTRY_DATE"));
							g.setId(rs.getInt("ID"));
							g.setViewCount(rs.getInt("VIEW_COUNT"));
							g.setDescription(rs.getString("DESCRIPTION"));
							g.setImagePath(rs.getString("IMAGE_PATH"));
							g.setTextUrl(rs.getString("TEXT_URL"));
							g.setSubject(rs.getString("SUBJECT_LINE"));
							g.setStatus(rs.getString("STATUS"));
							g.setTitle(rs.getString("TITLE"));
							
							al.add(g);
						}
					}
					catch (Exception e) {
						System.out.println("Image Banner List not getting mom Database.");
					}finally{
						try{
							 rs.close();
							 stmt.close();
							}catch (Exception e) {
								e.printStackTrace();
							}
						}
					return al;
				}
				
				
				public ArrayList<Label>  getSingleBlogListByEntryBy(String id, String status, Connection con){		
					Label g = null;
					ArrayList<Label> al = new ArrayList<Label>();
					String query= "select * from label_list where ENTRY_BY='"+id+"' AND STATUS='"+status+"'";
					try{	
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){		
							g = new Label();
							g.setEntryBy(rs.getString("ENTRY_BY"));
							g.setEntryDate(rs.getDate("ENTRY_DATE"));
							g.setId(rs.getInt("ID"));
							g.setViewCount(rs.getInt("VIEW_COUNT"));
							g.setDescription(rs.getString("DESCRIPTION"));
							g.setImagePath(rs.getString("IMAGE_PATH"));
							g.setTextUrl(rs.getString("TEXT_URL"));
							g.setSubject(rs.getString("SUBJECT_LINE"));
							g.setStatus(rs.getString("STATUS"));
							g.setTitle(rs.getString("TITLE"));
							
							al.add(g);
						}
					}
					catch (Exception e) {
						System.out.println("Image Banner List not getting mom Database.");
					}finally{
						try{
							 rs.close();
							 stmt.close();
							}catch (Exception e) {
								e.printStackTrace();
							}
						}
					return al;
				}
				
				public ArrayList<Label>  getSingleBlogListByEntryByNot(String id, String status, Connection con){		
					Label g = null;
					ArrayList<Label> al = new ArrayList<Label>();
					String query= "select * from label_list where ENTRY_BY='"+id+"' AND STATUS!='"+status+"'";
					try{	
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){		
							g = new Label();
							g.setEntryBy(rs.getString("ENTRY_BY"));
							g.setEntryDate(rs.getDate("ENTRY_DATE"));
							g.setId(rs.getInt("ID"));
							g.setViewCount(rs.getInt("VIEW_COUNT"));
							g.setDescription(rs.getString("DESCRIPTION"));
							g.setImagePath(rs.getString("IMAGE_PATH"));
							g.setTextUrl(rs.getString("TEXT_URL"));
							g.setSubject(rs.getString("SUBJECT_LINE"));
							g.setStatus(rs.getString("STATUS"));
							g.setTitle(rs.getString("TITLE"));
							
							al.add(g);
						}
					}
					catch (Exception e) {
						System.out.println("Image Banner List not getting mom Database.");
					}finally{
						try{
							 rs.close();
							 stmt.close();
							}catch (Exception e) {
								e.printStackTrace();
							}
						}
					return al;
				}
				
				// Get Category List mom database.
				public ArrayList<Label>  getAdminBlogList( Connection con){		
					Label g = null;
					Date today = new Date();
					ArrayList<Label> al = new ArrayList<Label>();
					String query= "select * from label_list order by ID DESC";
					try{	
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){		
							g = new Label();
							g.setEntryBy(rs.getString("ENTRY_BY"));
							g.setEntryDate(rs.getDate("ENTRY_DATE"));
							g.setId(rs.getInt("ID"));
							g.setViewCount(rs.getInt("VIEW_COUNT"));
							g.setDescription(rs.getString("DESCRIPTION"));
							g.setImagePath(rs.getString("IMAGE_PATH"));
							g.setTextUrl(rs.getString("TEXT_URL"));
							g.setSubject(rs.getString("SUBJECT_LINE"));
							g.setStatus(rs.getString("STATUS"));
							g.setTitle(rs.getString("TITLE"));
							al.add(g);
						}
					}
					catch (Exception e) {
						System.out.println("Image Banner List not getting mom Database.");
					}finally{
						try{
							 rs.close();
							 stmt.close();
							}catch (Exception e) {
								e.printStackTrace();
							}
						}
					return al;
				}
				
				// Get Category List mom database.
				public ArrayList<Label>  getAdminBlogList(int id, Connection con){		
					Label g = null;
					ArrayList<Label> al = new ArrayList<Label>();
					String query= "select * from label_list  where ID between "+(id-20) +" AND "+id+" AND PAGE_PRIORITY=1 order by ID DESC";
					try{	
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){		
							g = new Label();
							g.setEntryBy(rs.getString("ENTRY_BY"));
							g.setEntryDate(rs.getDate("ENTRY_DATE"));
							g.setId(rs.getInt("ID"));
							g.setViewCount(rs.getInt("VIEW_COUNT"));
							g.setDescription(rs.getString("DESCRIPTION"));
							g.setImagePath(rs.getString("IMAGE_PATH"));
							g.setTextUrl(rs.getString("TEXT_URL"));
							g.setSubject(rs.getString("SUBJECT_LINE"));
							g.setStatus(rs.getString("STATUS"));
							g.setTitle(rs.getString("TITLE"));
							
							al.add(g);
						}
					}
					catch (Exception e) {
						System.out.println("Image Banner List not getting mom Database.");
					}finally{
						try{
							 rs.close();
							 stmt.close();
							}catch (Exception e) {
								e.printStackTrace();
							}
						}
					return al;
				}
				
				
				// Get Category List mom database.
				public ArrayList<Label> getAdvertizementList(int count, int limit, Connection con){		
					Label g = null;
					ArrayList<Label> al = new ArrayList<Label>();
					if(count==0){
						count = getLastImageBlogID(con);
					}if(count<20){
						limit =count;
					}
					String query= "select * from label_list where ID<= "+count+" order by ID desc LIMIT "+limit;
					try{	
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){		
							g = new Label();
							g.setEntryBy(rs.getString("ENTRY_BY"));
							g.setEntryDate(rs.getDate("ENTRY_DATE"));
							g.setId(rs.getInt("ID"));
							g.setViewCount(rs.getInt("VIEW_COUNT"));
							g.setDescription(rs.getString("DESCRIPTION"));
							g.setImagePath(rs.getString("IMAGE_PATH"));
							g.setTextUrl(rs.getString("TEXT_URL"));
							g.setSubject(rs.getString("SUBJECT_LINE"));
							g.setStatus(rs.getString("STATUS"));
							g.setTitle(rs.getString("TITLE"));
							
							al.add(g);
							}
						}
						catch (Exception e) {
						System.out.println("Video List not getting from Database.");
						}finally {
						    // Always make sure result sets and statements are closed,
						    if (rs != null) {
							      try { rs.close(); } catch (SQLException e) { ; }
							      rs = null;
							    }
						    if (stmt != null) {
						      try { stmt.close(); } catch (SQLException e) { ; }
						      stmt = null;
						    }
						}
				   return al;
				}
				
				
				// Get Category List mom database.
				public ArrayList<Label>  getAdminURLList(int id, Connection con){		
					Label g = null;
					Date today = new Date();
					ArrayList<Label> al = new ArrayList<Label>();
					String query= "select * from label_list where ID between "+(id-20) +" AND "+id+" order by ID DESC";
					try{	
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){		
							g = new Label();
							g.setEntryBy(rs.getString("ENTRY_BY"));
							g.setEntryDate(rs.getDate("ENTRY_DATE"));
							g.setId(rs.getInt("ID"));
							g.setViewCount(rs.getInt("VIEW_COUNT"));
							g.setDescription(rs.getString("DESCRIPTION"));
							g.setImagePath(rs.getString("IMAGE_PATH"));
							g.setTextUrl(rs.getString("TEXT_URL"));
							g.setSubject(rs.getString("SUBJECT_LINE"));
							g.setStatus(rs.getString("STATUS"));
							g.setTitle(rs.getString("TITLE"));
							
							al.add(g);
						}
					}
					catch (Exception e) {
						System.out.println("Image Banner List not getting mom Database.");
					}finally{
						try{
							 rs.close();
							 stmt.close();
							}catch (Exception e) {
								e.printStackTrace();
							}
						}
					return al;
				}
				
				
				public ArrayList<Label> getBlogList(String id, int limit, Connection con){		
					Label g = null;
					ArrayList<Label> al = new ArrayList<Label>();
					String query= "select * from label_list where ENTRY_BY='"+id+"' order by ID DESC limit "+limit+"";
					try{	
//						ResultSet rs = dbc.selectquery(query);
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){		
							g = new Label();
							g.setEntryBy(rs.getString("ENTRY_BY"));
							g.setEntryDate(rs.getDate("ENTRY_DATE"));
							g.setId(rs.getInt("ID"));
							g.setViewCount(rs.getInt("VIEW_COUNT"));
							g.setDescription(rs.getString("DESCRIPTION"));
							g.setImagePath(rs.getString("IMAGE_PATH"));
							g.setTextUrl(rs.getString("TEXT_URL"));
							g.setSubject(rs.getString("SUBJECT_LINE"));
							g.setStatus(rs.getString("STATUS"));
							g.setTitle(rs.getString("TITLE"));
							al.add(g);
							}
						}
						catch (Exception e) {
						System.out.println("bank account List not getting from Database.");
						}finally {
						    // Always make sure result sets and statements are closed,
						    if (rs != null) {
							      try { rs.close(); } catch (SQLException e) { ; }
							      rs = null;
							    }
						    if (stmt != null) {
						      try { stmt.close(); } catch (SQLException e) { ; }
						      stmt = null;
						    }
						}
				   return al;
				}
				
				// Get Category List mom database.
				public ArrayList<Label>  getBlogList( Connection con){		
					Label g = null;
					Date today = new Date();
					ArrayList<Label> al = new ArrayList<Label>();
					//String query= "select b.ENTRY_BY, b.ENTRY_DATE, b.PAGE_PRIORITY, b.ID, b.DESCRIPTION, b.CATEGORY, b.PAGE_URL, b.SHORT_DESCRIPTION, b.BLOG_IMAGES, w.PAGE_URL as ws from label_list b left join today_watched_ads w on b.PAGE_URL=w.PAGE_URL where b.ENTRY_DATE='"+new java.sql.Date(today.getTime())+"' order by b.ID DESC LIMIT 30";
					String query= "select * from label_list  order by ID DESC LIMIT 30";
					try{	
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){		
							g = new Label();
							g.setEntryBy(rs.getString("ENTRY_BY"));
							g.setEntryDate(rs.getDate("ENTRY_DATE"));
							g.setId(rs.getInt("ID"));
							g.setViewCount(rs.getInt("VIEW_COUNT"));
							g.setDescription(rs.getString("DESCRIPTION"));
							g.setImagePath(rs.getString("IMAGE_PATH"));
							g.setTextUrl(rs.getString("TEXT_URL"));
							g.setSubject(rs.getString("SUBJECT_LINE"));
							g.setStatus(rs.getString("STATUS"));
							g.setTitle(rs.getString("TITLE"));
							al.add(g);
						}
					}
					catch (Exception e) {
						System.out.println("Image Banner List not getting mom Database.");
					}finally{
						try{
							 rs.close();
							 stmt.close();
							}catch (Exception e) {
								e.printStackTrace();
							}
						}
					return al;
				}
				
				
		
		// Get Category List mom database.
		public ArrayList<Label>  getDistinctBlogList(String category, Connection con){
			Label g = null;
			Date today = new Date();
			ArrayList<Label> al = new ArrayList<Label>();
			String query= "select * from label_list where PAGE_PRIORITY=1 AND STATUS='DISPLAY' AND CATEGORY='"+category+"' order by ID DESC LIMIT 30";
			try{	
				 stmt = (Statement)con.createStatement();
				  rs = (ResultSet)stmt.executeQuery(query);
				while(rs.next()){		
					g = new Label();
					g.setEntryBy(rs.getString("ENTRY_BY"));
					g.setEntryDate(rs.getDate("ENTRY_DATE"));
					g.setId(rs.getInt("ID"));
					g.setViewCount(rs.getInt("VIEW_COUNT"));
					g.setDescription(rs.getString("DESCRIPTION"));
					g.setImagePath(rs.getString("IMAGE_PATH"));
					g.setTextUrl(rs.getString("TEXT_URL"));
					g.setSubject(rs.getString("SUBJECT_LINE"));
					g.setStatus(rs.getString("STATUS"));
					g.setTitle(rs.getString("TITLE"));
					
					al.add(g);
				}
			}
			catch (Exception e) {
				System.out.println("Image Banner List not getting mom Database.");
			}finally{
				try{
					 rs.close();
					 stmt.close();
					}catch (Exception e) {
						e.printStackTrace();
					}
				}
			return al;
		}	
		
		// Get Category List mom database.
				public ArrayList<Label>  getBlogList1( Connection con){		
					Label g = null;
					Date today = new Date();
					ArrayList<Label> al = new ArrayList<Label>();
					String query= "select * from label_list where PAGE_PRIORITY=1 order by ID DESC LIMIT 30";
					try{	
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){		
							g = new Label();
							g.setEntryBy(rs.getString("ENTRY_BY"));
							g.setEntryDate(rs.getDate("ENTRY_DATE"));
							g.setId(rs.getInt("ID"));
							g.setViewCount(rs.getInt("VIEW_COUNT"));
							g.setDescription(rs.getString("DESCRIPTION"));
							g.setImagePath(rs.getString("IMAGE_PATH"));
							g.setTextUrl(rs.getString("TEXT_URL"));
							g.setSubject(rs.getString("SUBJECT_LINE"));
							g.setStatus(rs.getString("STATUS"));
							g.setTitle(rs.getString("TITLE"));
							
							al.add(g);
						}
					}
					catch (Exception e) {
						System.out.println("Image Banner List not getting mom Database.");
					}finally{
						try{
							 rs.close();
							 stmt.close();
							}catch (Exception e) {
								e.printStackTrace();
							}
						}
					return al;
				}
		
				// Get Category List mom database.
				public Label  getSingleBlogByURL(String pageURL, Connection con){		
					Label g = null;
					String query= "select * from label_list where PAGE_URL='"+pageURL+"'";
					try{	
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){		
							g = new Label();
							g.setEntryBy(rs.getString("ENTRY_BY"));
							g.setEntryDate(rs.getDate("ENTRY_DATE"));
							g.setId(rs.getInt("ID"));
							g.setViewCount(rs.getInt("VIEW_COUNT"));
							g.setDescription(rs.getString("DESCRIPTION"));
							g.setImagePath(rs.getString("IMAGE_PATH"));
							g.setTextUrl(rs.getString("TEXT_URL"));
							g.setSubject(rs.getString("SUBJECT_LINE"));
							g.setStatus(rs.getString("STATUS"));
							g.setTitle(rs.getString("TITLE"));
						}
					}
					catch (Exception e) {
						System.out.println("Image Banner List not getting mom Database.");
					}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
					return g;
				}
				
				
				// Get Category List mom database.
				public Label  getSingleBlogBySubject(String pageURL, Connection con){		
					Label g = null;
					String query= "select * from label_list where SHORT_DESCRIPTION='"+pageURL+"'";
					try{	
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){		
							g = new Label();
							g.setEntryBy(rs.getString("ENTRY_BY"));
							g.setEntryDate(rs.getDate("ENTRY_DATE"));
							g.setId(rs.getInt("ID"));
							g.setViewCount(rs.getInt("VIEW_COUNT"));
							g.setDescription(rs.getString("DESCRIPTION"));
							g.setImagePath(rs.getString("IMAGE_PATH"));
							g.setTextUrl(rs.getString("TEXT_URL"));
							g.setSubject(rs.getString("SUBJECT_LINE"));
							g.setStatus(rs.getString("STATUS"));
							g.setTitle(rs.getString("TITLE"));
						}
					}
					catch (Exception e) {
						System.out.println("Image Banner List not getting mom Database.");
					}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
					return g;
				}
				
				
				// Get Category List mom database.
				public Label  getSingleBlogByURL1(String pageURL, Connection con){		
					Label g = null;
					String query= "select * from label_list where PAGE_URL='%"+pageURL+"'";
					try{	
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){		
							g = new Label();
							g.setEntryBy(rs.getString("ENTRY_BY"));
							g.setEntryDate(rs.getDate("ENTRY_DATE"));
							g.setId(rs.getInt("ID"));
							g.setViewCount(rs.getInt("VIEW_COUNT"));
							g.setDescription(rs.getString("DESCRIPTION"));
							g.setImagePath(rs.getString("IMAGE_PATH"));
							g.setTextUrl(rs.getString("TEXT_URL"));
							g.setSubject(rs.getString("SUBJECT_LINE"));
							g.setStatus(rs.getString("STATUS"));
							g.setTitle(rs.getString("TITLE"));
						}
					}
					catch (Exception e) {
						System.out.println("Image Banner List not getting mom Database.");
					}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
					return g;
				}
				
				
				// Get Category List mom database.
				public Label  getSingleBlogByID(int id, Connection con){		
					Label g = null;
					String query= "select * from label_list where ID='"+id+"'";
					try{	
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){		
							g = new Label();
							g.setEntryBy(rs.getString("ENTRY_BY"));
							g.setEntryDate(rs.getDate("ENTRY_DATE"));
							g.setId(rs.getInt("ID"));
							g.setViewCount(rs.getInt("VIEW_COUNT"));
							g.setDescription(rs.getString("DESCRIPTION"));
							g.setImagePath(rs.getString("IMAGE_PATH"));
							g.setTextUrl(rs.getString("TEXT_URL"));
							g.setSubject(rs.getString("SUBJECT_LINE"));
							g.setStatus(rs.getString("STATUS"));
							g.setTitle(rs.getString("TITLE"));
							
							
						}
					}
					catch (Exception e) {
						System.out.println("Image Banner List not getting mom Database.");
					}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
					return g;
				}
	// Get Category List mom database.
	public int getLastImageBlogID( Connection con) {
		int id = 0;
//		ResultSet rs = null;
		String query = "select MAX(ID) as ID from label_list";
		try {
			 stmt = (Statement)con.createStatement();
			  rs = (ResultSet)stmt.executeQuery(query);
			while (rs.next()) {
				id = rs.getInt("ID");
			}
		} catch (Exception e) {
			System.out.println("Sorry! Please try again later.");
		}finally{
			try{
				 rs.close();
				 stmt.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return id;
	}

	public int deleteIamgeFromBlog(int id, Connection con) {
		String query = "delete from label_list where ID=?";
		int i=0;
		try{
			 ps=(PreparedStatement) con.prepareStatement(query);
			 ps.setInt(1, id);
			 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i;
	}
	
	public int deleteIamgeFromBlog(int id, String entryBy, Connection con) {
		String query = "delete from label_list where ID=? AND ENTRY_BY=?";
		int i=0;
		try{
			 ps=(PreparedStatement) con.prepareStatement(query);
			 ps.setInt(1, id);
			 ps.setString(2, entryBy);
			 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i;
	}
	

}

package com.soft.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.soft.model.Payment;

public class FundWalletDAO {
	int i=0;
	Statement stmt = null;
	ResultSet rs = null;
	PreparedStatement ps = null;
	public int addNewFundInWallet(Payment p, Connection con) {
		String query = "insert into fund_wallet(ORDER_ID, LOGIN_ID, PAYMENT_VIA, PAYMENT_TYPE, TOTAL_AMOUNT, PAYMENT_STATUS, PAYMENT_DATE) values(?, ?, ?,  ?, ?, ?, now())";
		try{
		 ps=(PreparedStatement) con.prepareStatement(query);
		 ps.setInt(1, p.getOrderID());
		 ps.setString(2, p.getLoginID());
		 ps.setString(3, p.getPaymentvia());
		 ps.setString(4, p.getPaymentType());
		 ps.setFloat(5, p.getTotalAmount());
		 ps.setString(6, p.getPaymentStatus());
		 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i;
	}

	// Get Category List mom database.
	public ArrayList<Payment> getSilgleMemberFundInWalletDetails(String  loginID, Connection con){		
		Payment p = null;
		ArrayList<Payment> al = new ArrayList<Payment>();
		String query= "select f.LOGIN_ID, f.ORDER_ID, f.ID, f.PAYMENT_DATE, f.PAYMENT_STATUS, f.PAYMENT_TYPE, " +
				" f.PAYMENT_VIA, f.TOTAL_AMOUNT, m.FIRST_NAME as pVia from fund_wallet f left join member m on f.PAYMENT_VIA=m.LOGIN_ID where f.LOGIN_ID='"+loginID+"' order by f.ID DESC";
		try{	
//			ResultSet rs = dbc.selectquery(query);
			  stmt = (Statement)con.createStatement();
			  rs = (ResultSet)stmt.executeQuery(query);
			while(rs.next()){		
				p = new Payment();
				p.setLoginID(rs.getString("LOGIN_ID"));
				p.setOrderID(rs.getInt("ORDER_ID"));
				p.setId(rs.getInt("ID"));
				p.setPaymentDate(rs.getDate("PAYMENT_DATE"));
				p.setPaymentStatus(rs.getString("PAYMENT_STATUS"));
				p.setPaymentType(rs.getString("PAYMENT_TYPE"));
				p.setPaymentvia(rs.getString("PAYMENT_VIA"));
				p.setTotalAmount(rs.getFloat("TOTAL_AMOUNT"));
				p.setPaymentviaName(rs.getString("pVia"));
				
					al.add(p);
				}
			}
			catch (Exception e) {
			System.out.println("bank account List not getting from Database.");
			}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
	   return al;
	}
	
	
	// Get Category List mom database.
		public ArrayList<Payment> getSilgleMemberFundInWalletDetails(Connection con){		
			Payment p = null;
			ArrayList<Payment> al = new ArrayList<Payment>();
			String query= "select f.LOGIN_ID, f.ORDER_ID, f.ID, f.PAYMENT_DATE, f.PAYMENT_STATUS, f.PAYMENT_TYPE, " +
					" f.PAYMENT_VIA, f.TOTAL_AMOUNT, m.FIRST_NAME as pVia from fund_wallet f left join member m on f.PAYMENT_VIA=m.LOGIN_ID order by f.ID DESC";
			try{	
//				ResultSet rs = dbc.selectquery(query);
				  stmt = (Statement)con.createStatement();
				  rs = (ResultSet)stmt.executeQuery(query);
				while(rs.next()){		
					p = new Payment();
					p.setLoginID(rs.getString("LOGIN_ID"));
					p.setOrderID(rs.getInt("ORDER_ID"));
					p.setId(rs.getInt("ID"));
					p.setPaymentDate(rs.getDate("PAYMENT_DATE"));
					p.setPaymentStatus(rs.getString("PAYMENT_STATUS"));
					p.setPaymentType(rs.getString("PAYMENT_TYPE"));
					p.setPaymentvia(rs.getString("PAYMENT_VIA"));
					p.setTotalAmount(rs.getFloat("TOTAL_AMOUNT"));
					p.setPaymentviaName(rs.getString("pVia"));
					
						al.add(p);
					}
				}
				catch (Exception e) {
				System.out.println("bank account List not getting from Database.");
				}finally {
				    // Always make sure result sets and statements are closed,
				    if (rs != null) {
					      try { rs.close(); } catch (SQLException e) { ; }
					      rs = null;
					    }
				    if (stmt != null) {
				      try { stmt.close(); } catch (SQLException e) { ; }
				      stmt = null;
				    }
				}
		   return al;
		}
	
	
	// Get Category List mom database.
	public float getSilgleMemberFundInWalletAmount(String loginID, String status, Connection con){	
		float totalAmount = 0;
		String query= "select sum(TOTAL_AMOUNT) as TOTAL_AMOUNT from fund_wallet where LOGIN_ID='"+loginID+"' AND PAYMENT_STATUS='"+status+"'";
		try{	
			  stmt = (Statement)con.createStatement();
			  rs = (ResultSet)stmt.executeQuery(query);
			while(rs.next()){		
				totalAmount = rs.getFloat("TOTAL_AMOUNT");
				}
			}
			catch (Exception e) {
			System.out.println("getSilgleMemberFundInWalletAmount not getting from Database.");
			}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
	   return totalAmount;
	}
	
	
	// Get Category List mom database.
		public float getSilgleMemberFundInWalletAmountAdmin(String type, String status, Connection con){	
			float totalAmount = 0;
			String query= "select sum(TOTAL_AMOUNT) as TOTAL_AMOUNT from fund_wallet where PAYMENT_TYPE='"+type+"' AND PAYMENT_STATUS='"+status+"'";
			try{	
				  stmt = (Statement)con.createStatement();
				  rs = (ResultSet)stmt.executeQuery(query);
				while(rs.next()){		
					totalAmount = rs.getFloat("TOTAL_AMOUNT");
					}
				}
				catch (Exception e) {
				System.out.println("getSilgleMemberFundInWalletAmount not getting from Database.");
				}finally {
				    // Always make sure result sets and statements are closed,
				    if (rs != null) {
					      try { rs.close(); } catch (SQLException e) { ; }
					      rs = null;
					    }
				    if (stmt != null) {
				      try { stmt.close(); } catch (SQLException e) { ; }
				      stmt = null;
				    }
				}
		   return totalAmount;
		}
		
		
		public float getSilgleMemberFundInWalletAmountAdmin(String status, Connection con){	
			float totalAmount = 0;
			String query= "select sum(TOTAL_AMOUNT) as TOTAL_AMOUNT from fund_wallet where PAYMENT_STATUS='"+status+"'";
			try{	
				  stmt = (Statement)con.createStatement();
				  rs = (ResultSet)stmt.executeQuery(query);
				while(rs.next()){		
					totalAmount = rs.getFloat("TOTAL_AMOUNT");
					}
				}
				catch (Exception e) {
				System.out.println("getSilgleMemberFundInWalletAmount not getting from Database.");
				}finally {
				    // Always make sure result sets and statements are closed,
				    if (rs != null) {
					      try { rs.close(); } catch (SQLException e) { ; }
					      rs = null;
					    }
				    if (stmt != null) {
				      try { stmt.close(); } catch (SQLException e) { ; }
				      stmt = null;
				    }
				}
		   return totalAmount;
		}
		
		
		

	// Get Category List mom database.
	public Payment getSilgleFundInWallet(int  orderID, Connection con){		
		Payment p = null;
		String query= "select * from fund_wallet where ORDER_ID="+orderID;
		try{	
//			ResultSet rs = dbc.selectquery(query);
			  stmt = (Statement)con.createStatement();
			  rs = (ResultSet)stmt.executeQuery(query);
			while(rs.next()){		
				p = new Payment();
				p.setLoginID(rs.getString("LOGIN_ID"));
				p.setOrderID(rs.getInt("ORDER_ID"));
				p.setId(rs.getInt("ID"));
				p.setPaymentDate(rs.getDate("PAYMENT_DATE"));
				p.setPaymentStatus(rs.getString("PAYMENT_STATUS"));
				p.setPaymentType(rs.getString("PAYMENT_TYPE"));
				p.setPaymentvia(rs.getString("PAYMENT_VIA"));
				p.setTotalAmount(rs.getFloat("TOTAL_AMOUNT"));
				}
			}
			catch (Exception e) {
			System.out.println("bank account List not getting from Database.");
			}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
	   return p;
	}
}

package com.soft.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;

import com.soft.model.RequestUser;

public class RequestDAO {
//         //DBConnection dbc=new DBConnection();
	int i=0;
	Statement stmt = null;
	ResultSet rs = null;
	Statement stmt1 = null;
	ResultSet rs1 = null;
//	//Connection con = dbc.insertPreparequery();
	public int withdrawalRequest(RequestUser r, Connection con) {
		int amount =(int)r.getAmount();
		String query = "insert into request_list(MEMBER_ID, REQUEST_TYPE, STATUS, BANK_ID, ORDER_ID, AMOUNT,WITHDRAWAL_TYPE, ENTRY_DATE, TDS_RATE, EXTRA_CHARGES, TDS_AMOUNT, PAN_NUMBER, NARRATION) values(?, ?, ?, ?, ?, ?, ?, now(), ?, ?, ?, ?, ?)";
		try{
//		 con=dbc.insertPreparequery();
		 PreparedStatement ps=(PreparedStatement) con.prepareStatement(query);
		 ps=(PreparedStatement) con.prepareStatement(query);
		 ps.setString(1, r.getMemberID());
		 ps.setString(2, r.getRequestType());
		 ps.setString(3, r.getStatus());
		 ps.setInt(4, r.getBankID());
		 ps.setString(5, r.getOrderID());
		 ps.setFloat(6, amount);
		 ps.setString(7, r.getWithdrawalType());
		 ps.setFloat(8, r.getTdsRate());
		 ps.setFloat(9, r.getExtraCharges());
		 ps.setFloat(10, r.getTdsAmount());
		 ps.setString(11, r.getPanNumber());
		 ps.setString(12, r.getNarration());
		 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return i;
	}
	
	
	
	// Get Category List mom database.
	public ResultSet getWithdrawalRequestList(Connection con){		
		ResultSet rs = null;
		String query= "select r.STATUS,  r.REQUEST_TYPE, m.KYC_STATUS, b.ACCOUNT_HOLDER_NAME, b.ACCOUNT_NUMBER, b.BANK_NAME, b.IFSC_CODE, r.WITHDRAWAL_TYPE, r.ENTRY_DATE, r.ID as reqID, r.AMOUNT, m.ID, m.CITY, m.FIRST_NAME, m.LOGIN_ID, m.LAST_NAME, m.EMAIL_ID, m.CONTACT_NUMBER from member m left join request_list r on r.MEMBER_ID = m.LOGIN_ID left outer join bank_account b on b.MEMBER_ID = m.ID where r.STATUS = 'pending'  order by r.ENTRY_DATE, r.ID ASC";
		try{	
//			 rs = dbc.selectquery(query);
			 stmt = (Statement)con.createStatement();
			  rs = (ResultSet)stmt.executeQuery(query);
		}
		catch (Exception e) {
			System.out.println("bank account List not getting from Database.");
		}
		return rs;
	}
	
	
	public ArrayList<RequestUser> getWithdrawalRequestListMatching(String firstName, String loginId, Connection con){		
		
		Date yesterday = new Date();
		RequestUser r = null;
		ArrayList<RequestUser> al = new ArrayList<RequestUser>();
		String query1= null;
		int totalIncome = 0;
		String narration = "";
		String filter = " where 1=1";
		if(loginId!=null && !loginId.equals("")){
			filter +=" AND m.LOGIN_ID='"+loginId+"'";
		}
		if(firstName!=null){
			filter +=" AND m.FIRST_NAME LIKE '"+firstName+"%'";
		}
		String query= "select m.KYC_STATUS, b.ACCOUNT_HOLDER_NAME, b.ACCOUNT_NUMBER, b.BANK_NAME, b.IFSC_CODE, m.ID, b.ID as bnkID, b.PAN_NUMBER," +
				"m.FIRST_NAME, m.LOGIN_ID, m.CONTACT_NUMBER from member m left outer join bank_account b on b.MEMBER_ID = m.ID " +
				" "+filter+" order by m.ID ASC";
		try{	
//			 rs = dbc.selectquery(query);
			 stmt = (Statement)con.createStatement();
			  rs = (ResultSet)stmt.executeQuery(query);
			  while(rs.next()){
				  
				  r = new RequestUser();
				  totalIncome = 0;
				  narration = "";
				  
				  query1= "select sum(AMOUNT) as biAmount from binary_income where LOGIN_ID='"+rs.getString("LOGIN_ID")+"' AND ENTRY_DATE<'"+ new java.sql.Date(yesterday.getTime()) +"'";
				  stmt1 = (Statement)con.createStatement();
				  rs1 = (ResultSet)stmt1.executeQuery(query1);
				  while(rs1.next()){
					  totalIncome += rs1.getInt("biAmount");
					  narration += ", Binary: "+rs1.getInt("biAmount")+" ";
				  }
				  
				  
				  query1= "select sum(AMOUNT) as siAmount from sponsor_income where LOGIN_ID='"+rs.getString("LOGIN_ID")+"' AND ENTRY_DATE<'"+ new java.sql.Date(yesterday.getTime()) +"'";
				  stmt1 = (Statement)con.createStatement();
				  rs1 = (ResultSet)stmt1.executeQuery(query1);
				  while(rs1.next()){
					  totalIncome += rs1.getInt("siAmount");
					  narration += ", Sponsor: "+rs1.getInt("siAmount")+" ";
				  }
				  
				  query1= "select sum(AMOUNT) as liAmount from leadership_bonus where LOGIN_ID='"+rs.getString("LOGIN_ID")+"' AND ENTRY_DATE<'"+ new java.sql.Date(yesterday.getTime()) +"'";
				  stmt1 = (Statement)con.createStatement();
				  rs1 = (ResultSet)stmt1.executeQuery(query1);
				  while(rs1.next()){
					  totalIncome += rs1.getInt("liAmount");
					  narration += ", Leadership: "+rs1.getInt("liAmount")+" ";
				  }
				  r.setTotalIncome(totalIncome);
				  
				  query1= "select sum(AMOUNT) as mwAmount from request_list where MEMBER_ID='"+rs.getString("LOGIN_ID")+"' AND WITHDRAWAL_TYPE='MATCHINGWALLET'";
				  stmt1 = (Statement)con.createStatement();
				  rs1 = (ResultSet)stmt1.executeQuery(query1);
				  while(rs1.next()){
					  r.setMatchingWithdrawal(rs1.getFloat("mwAmount"));
					  narration += ", LastWithdrawn: (-)"+rs1.getFloat("mwAmount")+" ";
				  }
				  
				  if(((r.getTotalIncome())-r.getMatchingWithdrawal())>=200){
				  r.setStatus("pending");
				  r.setKycStatus(rs.getString("KYC_STATUS"));
				  r.setAccountHolderName(rs.getString("ACCOUNT_HOLDER_NAME"));
				  r.setAccountNumber(rs.getString("ACCOUNT_NUMBER"));
				  r.setBankName(rs.getString("BANK_NAME"));
				  r.setIfscCode(rs.getString("IFSC_CODE"));
				  r.setWithdrawalType("MATCHINGWALLET");
				  r.setEntryDate(new Date());
				  r.setReqID(0);
				  r.setId(rs.getInt("ID"));
				  r.setBnkID(rs.getInt("bnkID"));
				  r.setName(rs.getString("FIRST_NAME"));
				  r.setPanNumber(rs.getString("PAN_NUMBER"));
				  r.setLoginId(rs.getString("LOGIN_ID"));
				  r.setContactNumber(rs.getString("CONTACT_NUMBER"));
				  r.setNarration(narration);
				  
				  al.add(r);
				  
			  }
				 }
		}
		catch (Exception e) {
			System.out.println(e);
		}
		return al;
	}
	
	
	
	
public ArrayList<RequestUser> getWithdrawalRequestListMatchingAll(String firstName, String loginId, Connection con){		
		
		Date yesterday = new Date();
		RequestUser r = null;
		ArrayList<RequestUser> al = new ArrayList<RequestUser>();
		String query1= null;
		int totalIncome = 0;
		String narration = "";
		String filter = " where 1=1";
		if(loginId!=null && !loginId.equals("")){
			filter +=" AND m.LOGIN_ID='"+loginId+"'";
		}
		if(firstName!=null){
			filter +=" AND m.FIRST_NAME LIKE '"+firstName+"%'";
		}
		String query= "select m.KYC_STATUS, b.ACCOUNT_HOLDER_NAME, b.ACCOUNT_NUMBER, b.BANK_NAME, b.IFSC_CODE, m.ID, b.ID as bnkID, b.PAN_NUMBER," +
				"m.FIRST_NAME, m.LOGIN_ID, m.CONTACT_NUMBER from member m left outer join bank_account b on b.MEMBER_ID = m.ID " +
				" "+filter+" order by m.ID ASC";
		try{	
//			 rs = dbc.selectquery(query);
			 stmt = (Statement)con.createStatement();
			  rs = (ResultSet)stmt.executeQuery(query);
			  while(rs.next()){
				  
				  r = new RequestUser();
				  totalIncome = 0;
				  narration = "";
				  
				  query1= "select sum(AMOUNT) as biAmount from binary_income where LOGIN_ID='"+rs.getString("LOGIN_ID")+"' AND ENTRY_DATE<'"+ new java.sql.Date(yesterday.getTime()) +"'";
				  stmt1 = (Statement)con.createStatement();
				  rs1 = (ResultSet)stmt1.executeQuery(query1);
				  while(rs1.next()){
					  totalIncome += rs1.getInt("biAmount");
					  narration += ", Binary: "+rs1.getInt("biAmount")+" ";
				  }
				  
				  
				  query1= "select sum(AMOUNT) as siAmount from sponsor_income where LOGIN_ID='"+rs.getString("LOGIN_ID")+"' AND ENTRY_DATE<'"+ new java.sql.Date(yesterday.getTime()) +"'";
				  stmt1 = (Statement)con.createStatement();
				  rs1 = (ResultSet)stmt1.executeQuery(query1);
				  while(rs1.next()){
					  totalIncome += rs1.getInt("siAmount");
					  narration += ", Sponsor: "+rs1.getInt("siAmount")+" ";
				  }
				  
				  query1= "select sum(AMOUNT) as liAmount from leadership_bonus where LOGIN_ID='"+rs.getString("LOGIN_ID")+"' AND ENTRY_DATE<'"+ new java.sql.Date(yesterday.getTime()) +"'";
				  stmt1 = (Statement)con.createStatement();
				  rs1 = (ResultSet)stmt1.executeQuery(query1);
				  while(rs1.next()){
					  totalIncome += rs1.getInt("liAmount");
					  narration += ", Leadership: "+rs1.getInt("liAmount")+" ";
				  }
				  r.setTotalIncome(totalIncome);
				  
				  query1= "select sum(AMOUNT) as mwAmount from request_list where MEMBER_ID='"+rs.getString("LOGIN_ID")+"' AND WITHDRAWAL_TYPE='MATCHINGWALLET' AND ENTRY_DATE<'"+ new java.sql.Date(yesterday.getTime()) +"'";
				  stmt1 = (Statement)con.createStatement();
				  rs1 = (ResultSet)stmt1.executeQuery(query1);
				  while(rs1.next()){
					  r.setMatchingWithdrawal(rs1.getFloat("mwAmount"));
					  narration += ", LastWithdrawn: (-)"+rs1.getFloat("mwAmount")+" ";
				  }
				  
				  if(((r.getTotalIncome())-r.getMatchingWithdrawal())>0){
				  r.setStatus("pending");
				  r.setKycStatus(rs.getString("KYC_STATUS"));
				  r.setAccountHolderName(rs.getString("ACCOUNT_HOLDER_NAME"));
				  r.setAccountNumber(rs.getString("ACCOUNT_NUMBER"));
				  r.setBankName(rs.getString("BANK_NAME"));
				  r.setIfscCode(rs.getString("IFSC_CODE"));
				  r.setWithdrawalType("MATCHINGWALLET");
				  r.setEntryDate(new Date());
				  r.setReqID(0);
				  r.setId(rs.getInt("ID"));
				  r.setBnkID(rs.getInt("bnkID"));
				  r.setName(rs.getString("FIRST_NAME"));
				  r.setPanNumber(rs.getString("PAN_NUMBER"));
				  r.setLoginId(rs.getString("LOGIN_ID"));
				  r.setContactNumber(rs.getString("CONTACT_NUMBER"));
				  r.setNarration(narration);
				  
				  al.add(r);
				  }
				 }
		}
		catch (Exception e) {
			System.out.println(e);
		}
		return al;
	}
	
	
	
	public ArrayList<RequestUser> getWithdrawalRequestListRepurchase(String firstName, String loginId, Connection con){		
		Date yesterday = new Date();
		RequestUser r = null;
		ArrayList<RequestUser> al = new ArrayList<RequestUser>();
		String query1= null;
		int totalIncome = 0;
		String narration = "";
		String filter = " where 1=1";
		if(loginId!=null && !loginId.equals("")){
			filter +=" AND m.LOGIN_ID='"+loginId+"'";
		}
		if(firstName!=null){
			filter +=" AND m.FIRST_NAME LIKE '"+firstName+"%'";
		}
		String query= "select m.KYC_STATUS, b.ACCOUNT_HOLDER_NAME, b.ACCOUNT_NUMBER, b.BANK_NAME, b.IFSC_CODE, m.ID, b.ID as bnkID, b.PAN_NUMBER," +
				"m.FIRST_NAME, m.LOGIN_ID, m.CONTACT_NUMBER from member m left outer join bank_account b on b.MEMBER_ID = m.ID " +
				" "+filter+" order by m.ID ASC";
		try{	
//			 rs = dbc.selectquery(query);
			 stmt = (Statement)con.createStatement();
			  rs = (ResultSet)stmt.executeQuery(query);
			  while(rs.next()){
				  
				  r = new RequestUser();
				  totalIncome = 0;
				  narration = "";
				  
				  query1= "select sum(AMOUNT) as rliAmount from royalty_leadership_bonus where LOGIN_ID='"+rs.getString("LOGIN_ID")+"' AND ENTRY_DATE<'"+ new java.sql.Date(yesterday.getTime()) +"'";
				  stmt1 = (Statement)con.createStatement();
				  rs1 = (ResultSet)stmt1.executeQuery(query1);
				  while(rs1.next()){
					  totalIncome += rs1.getInt("rliAmount");
					  narration += ", RoyaltyLeadership: "+rs1.getInt("rliAmount")+" ";
				  }
				  
				  query1= "select sum(ROYALTY_AMOUNT) as riAmount from royalty_income where LOGIN_ID='"+rs.getString("LOGIN_ID")+"' AND ENTRY_DATE<'"+ new java.sql.Date(yesterday.getTime()) +"'";
				  stmt1 = (Statement)con.createStatement();
				  rs1 = (ResultSet)stmt1.executeQuery(query1);
				  while(rs1.next()){
					  totalIncome += rs1.getInt("riAmount");
					  narration += ", Royalty"+rs1.getInt("riAmount")+" ";
				  }
				  
				  query1= "select sum(AMOUNT) as ciAmount from champion_income where LOGIN_ID='"+rs.getString("LOGIN_ID")+"' AND ENTRY_DATE<'"+ new java.sql.Date(yesterday.getTime()) +"'";
				  stmt1 = (Statement)con.createStatement();
				  rs1 = (ResultSet)stmt1.executeQuery(query1);
				  while(rs1.next()){
					  totalIncome += rs1.getInt("ciAmount");
					  narration += ", Champion: "+rs1.getInt("ciAmount")+" ";
				  }
				  
				  query1= "select sum(AMOUNT) as tdiAmount from team_development_income where LOGIN_ID='"+rs.getString("LOGIN_ID")+"' AND ENTRY_DATE<'"+ new java.sql.Date(yesterday.getTime()) +"'";
				  stmt1 = (Statement)con.createStatement();
				  rs1 = (ResultSet)stmt1.executeQuery(query1);
				  while(rs1.next()){
					  totalIncome += rs1.getInt("tdiAmount");
					  narration += ", TeamDevelopment: "+rs1.getInt("tdiAmount")+" ";
				  }
				  
				  query1= "select sum(ROYALTY_AMOUNT) as ntiAmount from national_tunover_royalty_income where LOGIN_ID='"+rs.getString("LOGIN_ID")+"' AND ENTRY_DATE<'"+ new java.sql.Date(yesterday.getTime()) +"'";
				  stmt1 = (Statement)con.createStatement();
				  rs1 = (ResultSet)stmt1.executeQuery(query1);
				  while(rs1.next()){
					  totalIncome += rs1.getInt("ntiAmount");
					  narration += ", NationalTurnover: "+rs1.getInt("ntiAmount")+" ";
				  }
				  
				  query1= "select sum(AMOUNT) as twAmount from topup_wallet where LOGIN_ID='"+rs.getString("LOGIN_ID")+"' AND TRANSACTION_TYPE='CREDIT' AND ENTRY_DATE<'"+ new java.sql.Date(yesterday.getTime()) +"'";
				  stmt1 = (Statement)con.createStatement();
				  rs1 = (ResultSet)stmt1.executeQuery(query1);
				  while(rs1.next()){
					  totalIncome += rs1.getInt("twAmount");
					  narration += ", TopupWallet: "+rs1.getInt("twAmount")+" ";
				  }
				  
				  query1= "select sum(TOTAL_AMOUNT) as fwAmount from fund_wallet where LOGIN_ID='"+rs.getString("LOGIN_ID")+"' AND PAYMENT_DATE<'"+ new java.sql.Date(yesterday.getTime()) +"'";
				  stmt1 = (Statement)con.createStatement();
				  rs1 = (ResultSet)stmt1.executeQuery(query1);
				  while(rs1.next()){
					  totalIncome += rs1.getInt("fwAmount");
					  narration += ", FundWallet: "+rs1.getInt("fwAmount")+" ";
				  }
				  
				  
				  query1= "select sum(TOTAL_AMOUNT) as coAmount from customer_order where CUSTOMER_NAME='"+rs.getString("LOGIN_ID")+"' AND ENTRY_DATE<'"+ new java.sql.Date(yesterday.getTime()) +"'";
				  stmt1 = (Statement)con.createStatement();
				  rs1 = (ResultSet)stmt1.executeQuery(query1);
				  while(rs1.next()){
					  totalIncome -= rs1.getInt("coAmount");
					  narration += ", Purchase: (-)"+rs1.getInt("coAmount")+" ";
				  }
				  
				  
				  r.setTotalIncome(totalIncome);
				  
				  query1= "select sum(AMOUNT) as rwAmount from request_list where MEMBER_ID='"+rs.getString("LOGIN_ID")+"' AND WITHDRAWAL_TYPE='REPURCHASE'";
				  stmt1 = (Statement)con.createStatement();
				  rs1 = (ResultSet)stmt1.executeQuery(query1);
				  while(rs1.next()){
					  r.setMatchingWithdrawal(rs1.getFloat("rwAmount"));
					  narration += ", LastWithdrawn: (-)"+rs1.getFloat("rwAmount")+" ";
				  }
				  
				  if(((r.getTotalIncome())-r.getMatchingWithdrawal())>=200){
				  r.setStatus("pending");
				  r.setKycStatus(rs.getString("KYC_STATUS"));
				  r.setAccountHolderName(rs.getString("ACCOUNT_HOLDER_NAME"));
				  r.setAccountNumber(rs.getString("ACCOUNT_NUMBER"));
				  r.setBankName(rs.getString("BANK_NAME"));
				  r.setIfscCode(rs.getString("IFSC_CODE"));
				  r.setWithdrawalType("REPURCHASE");
				  r.setEntryDate(new Date());
				  r.setReqID(0);
				  r.setId(rs.getInt("ID"));
				  r.setBnkID(rs.getInt("bnkID"));
				  r.setName(rs.getString("FIRST_NAME"));
				  r.setPanNumber(rs.getString("PAN_NUMBER"));
				  r.setLoginId(rs.getString("LOGIN_ID"));
				  r.setContactNumber(rs.getString("CONTACT_NUMBER"));
				  r.setNarration(narration);
				  
				  al.add(r);
				  
			  }
				 }
		}
		catch (Exception e) {
			System.out.println(e);
		}
		return al;
	}
	
	
	
	
	public ArrayList<RequestUser> getWithdrawalRequestListRepurchaseAll(String firstName, String loginId, Connection con){		
		Date yesterday = new Date();
		RequestUser r = null;
		ArrayList<RequestUser> al = new ArrayList<RequestUser>();
		String query1= null;
		int totalIncome = 0;
		String narration = "";
		String filter = " where 1=1";
		if(loginId!=null && !loginId.equals("")){
			filter +=" AND m.LOGIN_ID='"+loginId+"'";
		}
		if(firstName!=null){
			filter +=" AND m.FIRST_NAME LIKE '"+firstName+"%'";
		}
		String query= "select m.KYC_STATUS, b.ACCOUNT_HOLDER_NAME, b.ACCOUNT_NUMBER, b.BANK_NAME, b.IFSC_CODE, m.ID, b.ID as bnkID, b.PAN_NUMBER," +
				"m.FIRST_NAME, m.LOGIN_ID, m.CONTACT_NUMBER from member m left outer join bank_account b on b.MEMBER_ID = m.ID " +
				" "+filter+" order by m.ID ASC";
		try{	
//			 rs = dbc.selectquery(query);
			 stmt = (Statement)con.createStatement();
			  rs = (ResultSet)stmt.executeQuery(query);
			  while(rs.next()){
				  
				  r = new RequestUser();
				  totalIncome = 0;
				  narration = "";
				  
				  query1= "select sum(AMOUNT) as rliAmount from royalty_leadership_bonus where LOGIN_ID='"+rs.getString("LOGIN_ID")+"' AND ENTRY_DATE<'"+ new java.sql.Date(yesterday.getTime()) +"'";
				  stmt1 = (Statement)con.createStatement();
				  rs1 = (ResultSet)stmt1.executeQuery(query1);
				  while(rs1.next()){
					  totalIncome += rs1.getInt("rliAmount");
					  narration += ", RoyaltyLeadership: "+rs1.getInt("rliAmount")+" ";
				  }
				  
				  query1= "select sum(ROYALTY_AMOUNT) as riAmount from royalty_income where LOGIN_ID='"+rs.getString("LOGIN_ID")+"' AND ENTRY_DATE<'"+ new java.sql.Date(yesterday.getTime()) +"'";
				  stmt1 = (Statement)con.createStatement();
				  rs1 = (ResultSet)stmt1.executeQuery(query1);
				  while(rs1.next()){
					  totalIncome += rs1.getInt("riAmount");
					  narration += ", Royalty"+rs1.getInt("riAmount")+" ";
				  }
				  
				  query1= "select sum(AMOUNT) as ciAmount from champion_income where LOGIN_ID='"+rs.getString("LOGIN_ID")+"' AND ENTRY_DATE<'"+ new java.sql.Date(yesterday.getTime()) +"'";
				  stmt1 = (Statement)con.createStatement();
				  rs1 = (ResultSet)stmt1.executeQuery(query1);
				  while(rs1.next()){
					  totalIncome += rs1.getInt("ciAmount");
					  narration += ", Champion: "+rs1.getInt("ciAmount")+" ";
				  }
				  
				  query1= "select sum(AMOUNT) as tdiAmount from team_development_income where LOGIN_ID='"+rs.getString("LOGIN_ID")+"' AND ENTRY_DATE<'"+ new java.sql.Date(yesterday.getTime()) +"'";
				  stmt1 = (Statement)con.createStatement();
				  rs1 = (ResultSet)stmt1.executeQuery(query1);
				  while(rs1.next()){
					  totalIncome += rs1.getInt("tdiAmount");
					  narration += ", TeamDevelopment: "+rs1.getInt("tdiAmount")+" ";
				  }
				  
				  query1= "select sum(ROYALTY_AMOUNT) as ntiAmount from national_tunover_royalty_income where LOGIN_ID='"+rs.getString("LOGIN_ID")+"' AND ENTRY_DATE<'"+ new java.sql.Date(yesterday.getTime()) +"'";
				  stmt1 = (Statement)con.createStatement();
				  rs1 = (ResultSet)stmt1.executeQuery(query1);
				  while(rs1.next()){
					  totalIncome += rs1.getInt("ntiAmount");
					  narration += ", NationalTurnover: "+rs1.getInt("ntiAmount")+" ";
				  }
				  
				  query1= "select sum(AMOUNT) as twAmount from topup_wallet where LOGIN_ID='"+rs.getString("LOGIN_ID")+"' AND TRANSACTION_TYPE='CREDIT' AND ENTRY_DATE<'"+ new java.sql.Date(yesterday.getTime()) +"'";
				  stmt1 = (Statement)con.createStatement();
				  rs1 = (ResultSet)stmt1.executeQuery(query1);
				  while(rs1.next()){
					  totalIncome += rs1.getInt("twAmount");
					  narration += ", TopupWallet: "+rs1.getInt("twAmount")+" ";
				  }
				  
				  query1= "select sum(TOTAL_AMOUNT) as fwAmount from fund_wallet where LOGIN_ID='"+rs.getString("LOGIN_ID")+"' AND PAYMENT_DATE<'"+ new java.sql.Date(yesterday.getTime()) +"'";
				  stmt1 = (Statement)con.createStatement();
				  rs1 = (ResultSet)stmt1.executeQuery(query1);
				  while(rs1.next()){
					  totalIncome += rs1.getInt("fwAmount");
					  narration += ", FundWallet: "+rs1.getInt("fwAmount")+" ";
				  }
				  
				  
				  query1= "select sum(TOTAL_AMOUNT) as coAmount from customer_order where CUSTOMER_NAME='"+rs.getString("LOGIN_ID")+"' AND ENTRY_DATE<'"+ new java.sql.Date(yesterday.getTime()) +"'";
				  stmt1 = (Statement)con.createStatement();
				  rs1 = (ResultSet)stmt1.executeQuery(query1);
				  while(rs1.next()){
					  totalIncome -= rs1.getInt("coAmount");
					  narration += ", Purchase: (-)"+rs1.getInt("coAmount")+" ";
				  }
				  
				  
				  r.setTotalIncome(totalIncome);
				  
				  query1= "select sum(AMOUNT) as rwAmount from request_list where MEMBER_ID='"+rs.getString("LOGIN_ID")+"' AND WITHDRAWAL_TYPE='REPURCHASE' AND ENTRY_DATE<'"+ new java.sql.Date(yesterday.getTime()) +"'";
				  stmt1 = (Statement)con.createStatement();
				  rs1 = (ResultSet)stmt1.executeQuery(query1);
				  while(rs1.next()){
					  r.setMatchingWithdrawal(rs1.getFloat("rwAmount"));
					  narration += ", LastWithdrawn: (-)"+rs1.getFloat("rwAmount")+" ";
				  }
				  
				  
				  if(((r.getTotalIncome())-r.getMatchingWithdrawal())>0){
				  r.setStatus("pending");
				  r.setKycStatus(rs.getString("KYC_STATUS"));
				  r.setAccountHolderName(rs.getString("ACCOUNT_HOLDER_NAME"));
				  r.setAccountNumber(rs.getString("ACCOUNT_NUMBER"));
				  r.setBankName(rs.getString("BANK_NAME"));
				  r.setIfscCode(rs.getString("IFSC_CODE"));
				  r.setWithdrawalType("REPURCHASE");
				  r.setEntryDate(new Date());
				  r.setReqID(0);
				  r.setId(rs.getInt("ID"));
				  r.setBnkID(rs.getInt("bnkID"));
				  r.setName(rs.getString("FIRST_NAME"));
				  r.setPanNumber(rs.getString("PAN_NUMBER"));
				  r.setLoginId(rs.getString("LOGIN_ID"));
				  r.setContactNumber(rs.getString("CONTACT_NUMBER"));
				  r.setNarration(narration);
				  
				  al.add(r);
				  }
				 }
		}
		catch (Exception e) {
			System.out.println(e);
		}
		return al;
	}
	
	

	// Display Processing Order into Desktop Page at user Panel.
		public ResultSet getPendingWithdrawalRequestListsFilter(String loginID, String firstName, String lastName, String status, String date, Connection con){		
//			ResultSet rs = null;
		    String filter = " 1 = 1 ";
		    if(firstName!=null && !firstName.equals("")){
		    	filter +="AND m.FIRST_NAME='"+firstName+"'";
		    }
		    if(lastName!=null && !lastName.equals("")){
		    	filter +="AND m.LAST_NAME='"+lastName+"'";
		    }
		    if(loginID!=null && !loginID.equals("")){
		    	filter +="AND r.MEMBER_ID='"+loginID+"'";
		    }
		    if(status!=null && !status.equals("")){
		    	filter +=" AND r.STATUS = '"+status+"'";
		    }
		    if(date!=null && !date.equals("")){
		    	filter +="AND r.ENTRY_DATE LIKE '%"+date+"%'";
		    }
			String query= "select r.STATUS, r.ENTRY_DATE as orderDate, r.ORDER_ID,  r.REQUEST_TYPE, m.BANK_NAME, m.ACCOUNT_NO, m.IFSC, m.GOOGLE_PAY, m.PHONE_PE, m.PAY_TM, m.UPI_ID, r.WITHDRAWAL_TYPE, r.ENTRY_DATE, r.ID as reqID, r.AMOUNT, m.ID, m.CITY, m.FIRST_NAME, m.LOGIN_ID, m.LAST_NAME, m.EMAIL_ID, m.CONTACT_NUMBER from request_list r left join member m on r.MEMBER_ID = m.LOGIN_ID where "+filter+" order by r.STATUS, r.ID DESC";
			try{	
//				 rs = dbc.selectquery(query);
				 stmt = (Statement)con.createStatement();
				  rs = (ResultSet)stmt.executeQuery(query);
			}
			catch (Exception e) {
				System.out.println("bank account List not getting from Database.");
			}
			return rs;
		}
	// Get Category List mom database.
		public ResultSet getPendingWithdrawalRequestList(String loginID, Connection con){		
//			ResultSet rs = null;
			String query= "select * from request_list where STATUS = 'pending' AND MEMBER_ID='"+loginID+"'";
			try{	
//				 rs = dbc.selectquery(query);
				 stmt = (Statement)con.createStatement();
				  rs = (ResultSet)stmt.executeQuery(query);
			}
			catch (Exception e) {
				System.out.println("bank account List not getting from Database.");
			}
			return rs;
		}

		// Get Category List mom database.
			public RequestUser getCompletedWithdrawalRequestList(int id, Connection con){		
				RequestUser r = null;
				String query= "select * from request_list where ID='"+id+"'";
				try{	
//					 rs = dbc.selectquery(query);
					 stmt = (Statement)con.createStatement();
					  rs = (ResultSet)stmt.executeQuery(query);
					  while (rs.next()) {
						r = new RequestUser();
						r.setAmount(rs.getFloat("AMOUNT"));
						r.setBankID(rs.getInt("BANK_ID"));
						r.setEntryDate(rs.getDate("ENTRY_DATE"));
						r.setEntryDate2(rs.getString("ENTRY_DATE"));
						r.setId(rs.getInt("ID"));
						r.setMemberID(rs.getString("MEMBER_ID"));
						r.setOrderID(rs.getString("ORDER_ID"));
						r.setRequestType(rs.getString("REQUEST_TYPE"));
						r.setStatus(rs.getString("STATUS"));
						r.setWithdrawalType(rs.getString("WITHDRAWAL_TYPE"));
					}
				}
				catch (Exception e) {
					System.out.println("bank account List not getting from Database.");
				}
				return r;
			}
		
	// Display Processing Order into Desktop Page at user Panel.
		public ResultSet getWithdrawalRequestListinProcess(String memberLoginID, Connection con){		
//			ResultSet rs = null;
			String query= "select o.STATUS, o.WITHDRAWAL_TYPE, o.ENTRY_DATE, o.ORDER_NO, o.GIVING_ID, o.TAKING_ID, m.FIRST_NAME, m.LOGIN_ID, m.LAST_NAME, m.EMAIL_ID, m.CONTACT_NUMBER, g.FIRST_NAME as fn, g.LOGIN_ID as gi, g.LAST_NAME as ln, g.EMAIL_ID as email, g.CONTACT_NUMBER as cn from member m left join order_list o on o.GIVING_ID = m.LOGIN_ID left outer join member g on g.LOGIN_ID = o.TAKING_ID where o.STATUS = 'PROCESS' AND  o.TAKING_ID='"+memberLoginID+"' OR o.GIVING_ID='"+memberLoginID+"'";
			try{	
//				 rs = dbc.selectquery(query);
				 stmt = (Statement)con.createStatement();
				  rs = (ResultSet)stmt.executeQuery(query);
			}
			catch (Exception e) {
				System.out.println("bank account List not getting from Database.");
			}
			return rs;
		}
		
	//Update by Admin
	public int updateRequestStatusByAdmin(String status, String memberID, int id, Connection con) {
		int i = 0;
		String query = "update request_list set STATUS=?, CREDIT_DATE=now() where ID=? AND MEMBER_ID=? AND STATUS='pending'";
		try{
//		 con=dbc.insertPreparequery();
		 PreparedStatement ps=(PreparedStatement) con.prepareStatement(query);
		 ps.setString(1, status);
		 ps.setInt(2, id);
		 ps.setString(3, memberID);
		 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return i;
	}
	
	// Get Category List mom database.
		public int getTotalWithdrawalRequest(String loginID, String withdrawalType, Connection con) {
			int id = 0;
//			ResultSet rs = null;
			String query = "select sum(AMOUNT) as amount from request_list where MEMBER_ID='"+loginID+"' AND WITHDRAWAL_TYPE='"+withdrawalType+"'";
			try {
//				rs = dbc.selectquery(query);
				 stmt = (Statement)con.createStatement();
				  rs = (ResultSet)stmt.executeQuery(query);
				while (rs.next()) {
					id = rs.getInt("amount");
				}
			} catch (Exception e) {
				System.out.println("Sorry! Please try again later.");
			}/*finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      con = null;
				    }
			    if (con != null) {
			      try { con.close(); } catch (SQLException e) { ; }
			      con = null;
			    }
			}*/
			return id;
		}
		
		// Get Category List mom database.
				public int getTotalWithdrawalAmount(String loginID, String status, Connection con) {
					int id = 0;
//					ResultSet rs = null;
					String query = "select sum(AMOUNT) as amount from request_list where MEMBER_ID='"+loginID+"' AND STATUS='"+status+"'";
					try {
//						rs = dbc.selectquery(query);
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while (rs.next()) {
							id = rs.getInt("amount");
						}
					} catch (Exception e) {
						System.out.println("Sorry! Please try again later.");
					}/*finally {
					    // Always make sure result sets and statements are closed,
					    if (rs != null) {
						      try { rs.close(); } catch (SQLException e) { ; }
						      con = null;
						    }
					    if (con != null) {
					      try { con.close(); } catch (SQLException e) { ; }
					      con = null;
					    }
					}*/
					return id;
				}
				
				
				
				// Get Category List mom database.
				public int getTotalWithdrawalAmount(String loginID, String withdrawalType, Date fromDate, Date toDate, Connection con) {
					int id = 0;
//					ResultSet rs = null;
					String query = "select sum(AMOUNT) as amount from request_list where MEMBER_ID='"+loginID+"' AND WITHDRAWAL_TYPE='"+withdrawalType+"'  AND ENTRY_DATE between '"+new java.sql.Date(fromDate.getTime())+"' AND '"+new java.sql.Date(toDate.getTime())+"'";
					try {
//						rs = dbc.selectquery(query);
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while (rs.next()) {
							id = rs.getInt("amount");
						}
					} catch (Exception e) {
						System.out.println("Sorry! Please try again later.");
					}/*finally {
					    // Always make sure result sets and statements are closed,
					    if (rs != null) {
						      try { rs.close(); } catch (SQLException e) { ; }
						      con = null;
						    }
					    if (con != null) {
					      try { con.close(); } catch (SQLException e) { ; }
					      con = null;
					    }
					}*/
					return id;
				}
				
				
				// Get Category List mom database.
				public int getTotalWithdrawalAmount(String withdrawalType, Date fromDate, Date toDate, Connection con) {
					int id = 0;
//					ResultSet rs = null;
					String query = "select sum(AMOUNT) as amount from request_list where WITHDRAWAL_TYPE='"+withdrawalType+"'  AND ENTRY_DATE between '"+new java.sql.Date(fromDate.getTime())+"' AND '"+new java.sql.Date(toDate.getTime())+"'";
					try {
//						rs = dbc.selectquery(query);
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while (rs.next()) {
							id = rs.getInt("amount");
						}
					} catch (Exception e) {
						System.out.println("Sorry! Please try again later.");
					}/*finally {
					    // Always make sure result sets and statements are closed,
					    if (rs != null) {
						      try { rs.close(); } catch (SQLException e) { ; }
						      con = null;
						    }
					    if (con != null) {
					      try { con.close(); } catch (SQLException e) { ; }
					      con = null;
					    }
					}*/
					return id;
				}
				
				// Get Category List mom database.
				public int getTotalWithdrawalAmount(String loginID, Connection con) {
					int id = 0;
//					ResultSet rs = null;
					String query = "select sum(AMOUNT) as amount from request_list where MEMBER_ID='"+loginID+"'";
					try {
//						rs = dbc.selectquery(query);
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while (rs.next()) {
							id = rs.getInt("amount");
						}
					} catch (Exception e) {
						System.out.println("Sorry! Please try again later.");
					}/*finally {
					    // Always make sure result sets and statements are closed,
					    if (rs != null) {
						      try { rs.close(); } catch (SQLException e) { ; }
						      con = null;
						    }
					    if (con != null) {
					      try { con.close(); } catch (SQLException e) { ; }
					      con = null;
					    }
					}*/
					return id;
				}
				
				
				// Get Category List mom database.
				public long getTotalWithdrawalAmount(Connection con) {
					long id = 0;
//					ResultSet rs = null;
					String query = "select sum(AMOUNT) as amount from request_list";
					try {
//						rs = dbc.selectquery(query);
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while (rs.next()) {
							id = rs.getLong("amount");
						}
					} catch (Exception e) {
						System.out.println("Sorry! Please try again later.");
					}/*finally {
					    // Always make sure result sets and statements are closed,
					    if (rs != null) {
						      try { rs.close(); } catch (SQLException e) { ; }
						      con = null;
						    }
					    if (con != null) {
					      try { con.close(); } catch (SQLException e) { ; }
					      con = null;
					    }
					}*/
					return id;
				}
				
				// Get Category List mom database.
				public float getPendingWithdrawalAmountByLoginIDStatus(String loginID, Connection con) {
					float id = 0;
					String query = "select sum(AMOUNT) as amount from request_list where MEMBER_ID='"+loginID+"' AND STATUS!='CREDITED'";
					try {
							stmt = (Statement)con.createStatement();
						    rs = (ResultSet)stmt.executeQuery(query);
						while (rs.next()) {
							id = rs.getFloat("amount");
						}
					} catch (Exception e) {
						System.out.println("Sorry! Please try again later.");
					}finally {
					    // Always make sure result sets and statements are closed,
					    if (rs != null) {
						      try { rs.close(); } catch (SQLException e) { ; }
						      rs = null;
						    }
					    if (stmt != null) {
					      try { stmt.close(); } catch (SQLException e) { ; }
					      stmt = null;
					    }
					}
					return id;
				}
				
				
				
				// Get Category List mom database.
				public int getTotalWithdrawalRequest(Connection con) {
					int id = 0;
//					ResultSet rs = null;
					String query = "select sum(AMOUNT) as amount from request_list";
					try {
//						rs = dbc.selectquery(query);
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while (rs.next()) {
							id = rs.getInt("amount");
						}
					} catch (Exception e) {
						System.out.println("Sorry! Please try again later.");
					}/*finally {
					    // Always make sure result sets and statements are closed,
					    if (rs != null) {
						      try { rs.close(); } catch (SQLException e) { ; }
						      con = null;
						    }
					    if (con != null) {
					      try { con.close(); } catch (SQLException e) { ; }
					      con = null;
					    }
					}*/
					return id;
				}
				
				// Get Category List mom database.
				public int getTotalWithdrawalAmountByStatus(String status, Connection con) {
					int id = 0;
//					ResultSet rs = null;
					String query = "select sum(AMOUNT) as amount from request_list where STATUS='"+status+"'";
					try {
//						rs = dbc.selectquery(query);
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while (rs.next()) {
							id = rs.getInt("amount");
						}
					} catch (Exception e) {
						System.out.println("Sorry! Please try again later.");
					}/*finally {
					    // Always make sure result sets and statements are closed,
					    if (rs != null) {
						      try { rs.close(); } catch (SQLException e) { ; }
						      con = null;
						    }
					    if (con != null) {
					      try { con.close(); } catch (SQLException e) { ; }
					      con = null;
					    }
					}*/
					return id;
				}
				
				
		// Get Category List mom database.
				public int getTotalWithdrawalRequestPendingAndProcess(String loginID, Connection con) {
					int id = 0;
//					ResultSet rs = null;
					String query = "select count(ID) as ID from request_list where MEMBER_ID='"+loginID+"' AND STATUS in('pending', 'PROCESS');";
					try {
//						rs = dbc.selectquery(query);
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while (rs.next()) {
							id = rs.getInt("ID");
						}
					} catch (Exception e) {
						System.out.println("Sorry! Please try again later.");
					}/*finally {
					    // Always make sure result sets and statements are closed,
					    if (rs != null) {
						      try { rs.close(); } catch (SQLException e) { ; }
						      con = null;
						    }
					    if (con != null) {
					      try { con.close(); } catch (SQLException e) { ; }
					      con = null;
					    }
					}*/
					return id;
				}
				
				// Get Category List mom database.
				public ArrayList<RequestUser> getPendingWithdrawalRequestListForBulk(String id, Connection con){		
					ArrayList<RequestUser> ruLi = new ArrayList<RequestUser>();
					RequestUser r = null;
					try{	
						String query= "select * from request_list where MEMBER_ID='"+id+"'";
							stmt = (Statement)con.createStatement();
							rs = (ResultSet)stmt.executeQuery(query);
							while (rs.next()) {
								r = new RequestUser();
								r.setAmount(rs.getFloat("AMOUNT"));
								r.setBankID(rs.getInt("BANK_ID"));
								r.setEntryDate(rs.getDate("ENTRY_DATE"));
								r.setId(rs.getInt("ID"));
								r.setMemberID(rs.getString("MEMBER_ID"));
								r.setOrderID(rs.getString("ORDER_ID"));
								r.setRequestType(rs.getString("REQUEST_TYPE"));
								r.setStatus(rs.getString("STATUS"));
								r.setWithdrawalType(rs.getString("WITHDRAWAL_TYPE"));
								ruLi.add(r);
							}
					}
					catch (Exception e) {
						System.out.println("bank account List not getting from Database.");
					}
					return ruLi;
				}
				
				
				// Get Category List mom database.
				public ArrayList<RequestUser> getPendingWithdrawalRequestListForBulk(ArrayList<Integer> al, Connection con){		
					String query= "select * from request_list where STATUS = 'pending'";
					ArrayList<RequestUser> ruLi = new ArrayList<RequestUser>();
					RequestUser r = null;
					try{	
						for(int ri: al){
							query= "select * from request_list where STATUS = 'pending' AND ID="+ri;
							stmt = (Statement)con.createStatement();
							rs = (ResultSet)stmt.executeQuery(query);
							while (rs.next()) {
								r = new RequestUser();
								r.setAmount(rs.getFloat("AMOUNT"));
								r.setBankID(rs.getInt("BANK_ID"));
								r.setEntryDate(rs.getDate("ENTRY_DATE"));
								r.setId(rs.getInt("ID"));
								r.setMemberID(rs.getString("MEMBER_ID"));
								r.setOrderID(rs.getString("ORDER_ID"));
								r.setRequestType(rs.getString("REQUEST_TYPE"));
								r.setStatus(rs.getString("STATUS"));
								r.setWithdrawalType(rs.getString("WITHDRAWAL_TYPE"));
								ruLi.add(r);
							}
						}
					}
					catch (Exception e) {
						System.out.println("bank account List not getting from Database.");
					}
					return ruLi;
				}
				
				
				
				public int deleteWithdrawalRequest(String loginID, int id, Connection con)
				{	
					int i=0;
					String query = "delete from request_list where ID="+id;
					try{
//						 i = dbc.insertquery(query);
						 stmt = (Statement)con.createStatement();
						  i = stmt.executeUpdate(query);
						 if(i!=0){
							 System.out.println(i+" Withdrawal Requested Deleted  Successfully");
						 }else {
							 System.out.println(" Withdrawal Requested not Deleted.? Please try Again.");
						}
					}catch (Exception e) {
						e.printStackTrace();
					}finally{
						try{
							 stmt.close();
							}catch (Exception e) {
								e.printStackTrace();
							}
						}
					return i;	
				}
				
}

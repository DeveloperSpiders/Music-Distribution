package com.soft.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.soft.model.Travel;
import com.soft.model.Gallery;
import com.soft.model.Member;

public class TravelDAO {
//    DBConnection dbc=new DBConnection();
//    Connection con=dbc.insertPreparequery();
    PreparedStatement ps= null;
    ResultSet rs = null;
    Statement stmt = null;
	
	public int addNewBlog(Travel ct, Connection con){
		int i=0;
	    try {	
	    	String query = "insert into travel_data(TRAVEL_CATEGORY, SUBJECT_LINE, DESCRIPTION, IMAGE_PATH, ENTRY_BY, STATE, DISTRICT, CITY, STATUS, VIEW_COUNT, NAME, VIDEO_PATH, ENTRY_DATE)" 
						+ "VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, now())";	
			  ps=(PreparedStatement) con.prepareStatement(query);
			 ps.setString(1, ct.getTravelCategory());
			 ps.setString(2, ct.getSubjectLine());
			 ps.setString(3, ct.getDescription());
			 ps.setString(4, "NA");
			 ps.setString(5, ct.getEntryBy());
			 ps.setString(6, ct.getState());
			 ps.setString(7, ct.getDistrict());
			 ps.setString(8, ct.getCity());
			 ps.setString(9, ct.getStatus());
			 ps.setInt(10, 0);
			 ps.setString(11, ct.getName());
			 ps.setString(12, ct.getVideoPath());
			 i=ps.executeUpdate();
			 if(i!=0){
				 i= getLastBlogID(con);
				 System.out.println(" Blog Inserted  successfully");
			 }else {
				 System.out.println(" Blog is not Inserted");
			}
			 
		}
		 catch (Exception e){
			e.printStackTrace();
		}
		return i;	
	}
	public int updateBlogImagePath(String path, int id, Connection con) {
		String query = "update travel_data set IMAGE_PATH='"+path+"' where ID="+id;
		//DBConnection dbc = new DBConnection();
		int i=0;
		try{
			//i = dbc.insertquery(query);
			ps=(PreparedStatement) con.prepareStatement(query);
			i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return i;
	}
	
	public int updateIconPath(String thumbnail, int  id, Connection con) {
		int i=0;
		String query = "update travel_data set IMAGE_PATH=? where ID=?";
		try{
//		 con=dbc.insertPreparequery();
		  ps=(PreparedStatement) con.prepareStatement(query);
		 ps.setString(1, thumbnail);
		 ps.setInt(2, id);
		 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i;
	}
	
	public int updateBlogViewCount(int view, int id, Connection con) {
		String query = "update travel_data set VIEW_COUNT='"+view+"' where ID="+id;
		//DBConnection dbc = new DBConnection();
		int i=0;
		try{
			//i = dbc.insertquery(query);
			ps=(PreparedStatement) con.prepareStatement(query);
			i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return i;
	}
	
	public int updatImagePath(ArrayList<String> path, long id, Connection con) {
		int i=0;
		String url = "";
		try{
			for(String s : path){
				i = i+1;
				if(i==1){
					url += " IMAGE_PATH='"+s+"'";
				}else{
				url += ", IMAGE_PATH='"+s+"'";
				}
			}
			
			String query = "update travel_data set "+url+" where ID=?";
			 ps=(PreparedStatement) con.prepareStatement(query);
			 ps.setLong(1, id);
			 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i;
	}
	
	// Update Existing Category into Database.
	public int updateBlogDetail(Travel ct, Connection con){
		int i = 0;
	    try {  
	    	String query = "UPDATE travel_data set TRAVEL_CATEGORY=?, SUBJECT_LINE=?, DESCRIPTION=?, ENTRY_BY=?, STATE=?, DISTRICT=?, CITY=?, STATUS=?, NAME=?, VIDEO_PATH=? WHERE ID = ?";
			 ps=(PreparedStatement) con.prepareStatement(query);
			 ps.setString(1, ct.getTravelCategory());
			 ps.setString(2, ct.getSubjectLine());
			 ps.setString(3, ct.getDescription());
			 ps.setString(4, ct.getEntryBy());
			 ps.setString(5, ct.getState());
			 ps.setString(6, ct.getDistrict());
			 ps.setString(7, ct.getCity());
			 ps.setString(8, ct.getStatus());
			 ps.setString(9, ct.getName());
			 ps.setString(10, ct.getVideoPath());
			 ps.setInt(11, ct.getId());
			i=ps.executeUpdate();
	    	if(i!=0){
				 System.out.println(i+" Blog Updated  Successfully");
			 }else {
				 System.out.println(" Blog not Updated");
			}
	    	
		}catch (Exception e) {
			e.printStackTrace();
		}
		return i;	
	}
	// Count Total Blog.
			public ArrayList<Travel> getBlogList(Connection con){		
				Travel ct =null;
				ArrayList<Travel> al = new ArrayList<Travel>();
				String query = "select * from travel_data order by ID DESC";
				try{
					// rs = dbc.selectquery(query);
					stmt = (Statement)con.createStatement();
					  rs = (ResultSet)stmt.executeQuery(query);
					while (rs.next()) {
						ct = new Travel();
						fillObjectFromDatabase(ct, con);
						al.add(ct);
					}
				}catch (Exception e) {
					e.printStackTrace();
				}
				return al;
			}
			
			
			// Get Down Line List mom database.
			public ArrayList<Travel> getBlogList(int id, Connection con){		
				Travel ct = null;
				int start = id - 10;
			    ArrayList<Travel> al = new ArrayList<Travel>();
				String query= "select * from travel_data where ID between "+start+" AND "+id+" ORDER BY ID DESC";
				try{	
					 stmt = (Statement)con.createStatement();
					  rs = (ResultSet)stmt.executeQuery(query);
					while(rs.next()){		
						ct = new Travel();
						fillObjectFromDatabase(ct, con);
						al.add(ct);
					}
				}
				catch (Exception e) {
					System.out.println("muits List not getting mom Database.");
				}finally {
		    // Always make sure result sets and statements are closed,
		    if (rs != null) {
			      try { rs.close(); } catch (SQLException e) { ; }
			      rs = null;
			    }
		    if (stmt != null) {
		      try { stmt.close(); } catch (SQLException e) { ; }
		      stmt = null;
		    }
		}
				return al;
			}

			// Count Total Blog.
					public ArrayList<Travel> getBlogListByFiiter(String category, Connection con){		
						Travel ct =null;
						ArrayList<Travel> al = new ArrayList<Travel>();
						String query = "select * from travel_data where TRAVEL_CATEGORY='"+category+"' order by ID DESC";
						try{
							// rs = dbc.selectquery(query);
							stmt = (Statement)con.createStatement();
							  rs = (ResultSet)stmt.executeQuery(query);
							while (rs.next()) {
								ct = new Travel();
								fillObjectFromDatabase(ct, con);
								al.add(ct);
							}
						}catch (Exception e) {
							e.printStackTrace();
						}
						return al;
					}
					
					// Get Category List mom database.
					public ArrayList<Travel>  getBannerFilterList(String category, String state, String district, String city, Connection con){		
						Travel ct = null;
						String filter = " where 1=1";
						if(category!=null && !category.equals("")){
							filter +=" AND TRAVEL_CATEGORY='"+category+"'";
						}
						if(state!=null && !state.equals("")){
							filter +=" AND STATE='"+state+"'";
						}
						if(district!=null && !district.equals("")){
							filter +=" AND DISTRICT='"+district+"'";
						}
						if(city!=null && !city.equals("")){
							filter +=" AND CITY='"+city+"'";
						}
						
						ArrayList<Travel> al = new ArrayList<Travel>();
						String query= "select * from travel_data "+filter+"  order by ID DESC";
						try{	
							 stmt = (Statement)con.createStatement();
							  rs = (ResultSet)stmt.executeQuery(query);
							while(rs.next()){		
								ct = new Travel();
								fillObjectFromDatabase(ct, con);
								al.add(ct);
							}
						}
						catch (Exception e) {
							System.out.println("Image Gallery List not getting mom Database.");
						}finally {
				    // Always make sure result sets and statements are closed,
				    if (rs != null) {
					      try { rs.close(); } catch (SQLException e) { ; }
					      rs = null;
					    }
				    if (stmt != null) {
				      try { stmt.close(); } catch (SQLException e) { ; }
				      stmt = null;
				    }
				}
						return al;
					}
					
					
					
					// Get Category List mom database.
					public ArrayList<Travel>  getSearchBlogQuote(String key, Connection con){		
						Travel ct = null;
						
						ArrayList<Travel> al = new ArrayList<Travel>();
						String query= "select * from travel_data where SUBJECT_LINE LIKE '%"+key+"%' order by ID DESC limit 24";
						try{	
							 stmt = (Statement)con.createStatement();
							  rs = (ResultSet)stmt.executeQuery(query);
							while(rs.next()){		
								ct = new Travel();
								fillObjectFromDatabase(ct, con);
								al.add(ct);
							}
						}
						catch (Exception e) {
							System.out.println("Image Gallery List not getting mom Database.");
						}finally {
				    // Always make sure result sets and statements are closed,
				    if (rs != null) {
					      try { rs.close(); } catch (SQLException e) { ; }
					      rs = null;
					    }
				    if (stmt != null) {
				      try { stmt.close(); } catch (SQLException e) { ; }
				      stmt = null;
				    }
				}
						return al;
					}
					
					
					// Get Category List mom database.
					public ArrayList<Travel>  getBannerFilterListWithLimit(String category, String state, String district, String city, int limit, Connection con){		
						Travel ct = null;
						String filter = " where 1=1";
						if(category!=null && !category.equals("")){
							filter +=" AND TRAVEL_CATEGORY='"+category+"'";
						}
						if(state!=null && !state.equals("")){
							filter +=" AND STATE='"+state+"'";
						}
						if(district!=null && !district.equals("")){
							filter +=" AND DISTRICT='"+district+"'";
						}
						if(city!=null && !city.equals("")){
							filter +=" AND CITY='"+city+"'";
						}
						
						
						ArrayList<Travel> al = new ArrayList<Travel>();
						String query= "select * from travel_data "+filter+"  order by ID DESC limit "+limit+"";
						try{	
							 stmt = (Statement)con.createStatement();
							  rs = (ResultSet)stmt.executeQuery(query);
							while(rs.next()){		
								ct = new Travel();
								fillObjectFromDatabase(ct, con);
								al.add(ct);
							}
						}
						catch (Exception e) {
							System.out.println("Image Gallery List not getting mom Database.");
						}finally {
				    // Always make sure result sets and statements are closed,
				    if (rs != null) {
					      try { rs.close(); } catch (SQLException e) { ; }
					      rs = null;
					    }
				    if (stmt != null) {
				      try { stmt.close(); } catch (SQLException e) { ; }
				      stmt = null;
				    }
				}
						return al;
					}
					
					
					// Get Category List mom database.
					public ArrayList<Travel>  getBannerFilterListWithLimit(String list, String category, String state, String district, String city, int limit, Connection con){		
						Travel ct = null;
						String filter = " where 1=1";
						if(list!=null && !list.equals("")){
							filter +=" AND DISTRICT IN ("+list+")";
						}
						if(category!=null && !category.equals("")){
							filter +=" AND TRAVEL_CATEGORY='"+category+"'";
						}
						if(state!=null && !state.equals("")){
							filter +=" AND STATE='"+state+"'";
						}
						if(district!=null && !district.equals("")){
							filter +=" AND DISTRICT='"+district+"'";
						}
						if(city!=null && !city.equals("")){
							filter +=" AND CITY='"+city+"'";
						}
						
						
						ArrayList<Travel> al = new ArrayList<Travel>();
						String query= "select * from travel_data "+filter+" order by VIEW_COUNT, ID DESC limit "+limit+"";
						try{	
							 stmt = (Statement)con.createStatement();
							  rs = (ResultSet)stmt.executeQuery(query);
							while(rs.next()){		
								ct = new Travel();
								fillObjectFromDatabase(ct, con);
								al.add(ct);
							}
						}
						catch (Exception e) {
							System.out.println("Image Gallery List not getting mom Database.");
						}finally {
				    // Always make sure result sets and statements are closed,
				    if (rs != null) {
					      try { rs.close(); } catch (SQLException e) { ; }
					      rs = null;
					    }
				    if (stmt != null) {
				      try { stmt.close(); } catch (SQLException e) { ; }
				      stmt = null;
				    }
				}
						return al;
					}
					
					
					// Get Category List mom database.
					public ArrayList<Travel>  getBannerFilterListWithLimitSearch(String search, int limit, Connection con){		
						Travel ct = null;
						String filter = " where TRAVEL_CATEGORY='NOTHING'";
						if(search!=null && !search.equals("")){
							filter +=" OR NAME LIKE '%"+search+"%'";
						}
						if(search!=null && !search.equals("")){
							filter +=" OR SUBJECT_LINE LIKE '%"+search+"%'";
						}
						if(search!=null && !search.equals("")){
							filter +=" OR DESCRIPTION LIKE '%"+search+"%'";
						}
						if(search!=null && !search.equals("")){
							filter +=" OR TRAVEL_CATEGORY LIKE '%"+search+"%'";
						}
						if(search!=null && !search.equals("")){
							filter +=" OR STATE LIKE '%"+search+"%'";
						}
						if(search!=null && !search.equals("")){
							filter +=" OR DISTRICT LIKE '%"+search+"%'";
						}
						if(search!=null && !search.equals("")){
							filter +=" OR CITY LIKE '%"+search+"%'";
						}
						
						
						ArrayList<Travel> al = new ArrayList<Travel>();
						String query= "select * from travel_data "+filter+"  order by ID DESC limit "+limit+"";
						try{	
							 stmt = (Statement)con.createStatement();
							  rs = (ResultSet)stmt.executeQuery(query);
							while(rs.next()){		
								ct = new Travel();
								fillObjectFromDatabase(ct, con);
								al.add(ct);
							}
						}
						catch (Exception e) {
							System.out.println("Image Gallery List not getting mom Database.");
						}finally {
				    // Always make sure result sets and statements are closed,
				    if (rs != null) {
					      try { rs.close(); } catch (SQLException e) { ; }
					      rs = null;
					    }
				    if (stmt != null) {
				      try { stmt.close(); } catch (SQLException e) { ; }
				      stmt = null;
				    }
				}
						return al;
					}
					
					
					// Get Category List mom database.
					public ArrayList<Travel>  getBannerFilterListMostViewed(int limit, Connection con){		
						Travel ct = null;
						ArrayList<Travel> al = new ArrayList<Travel>();
						String query= "select * from travel_data order by VIEW_COUNT DESC limit "+limit+"";
						try{	
							 stmt = (Statement)con.createStatement();
							  rs = (ResultSet)stmt.executeQuery(query);
							while(rs.next()){		
								ct = new Travel();
								fillObjectFromDatabase(ct, con);
								al.add(ct);
							}
						}
						catch (Exception e) {
							System.out.println("Image Gallery List not getting mom Database.");
						}finally {
				    // Always make sure result sets and statements are closed,
				    if (rs != null) {
					      try { rs.close(); } catch (SQLException e) { ; }
					      rs = null;
					    }
				    if (stmt != null) {
				      try { stmt.close(); } catch (SQLException e) { ; }
				      stmt = null;
				    }
				}
						return al;
					}
					
					// Get Category List mom database.
					public ArrayList<Travel>  getBannerFilterList(int limit, Connection con){		
						Travel ct = null;
												
						ArrayList<Travel> al = new ArrayList<Travel>();
						String query= "select * from travel_data order by ID DESC limit "+limit+"";
						try{	
							 stmt = (Statement)con.createStatement();
							  rs = (ResultSet)stmt.executeQuery(query);
							while(rs.next()){		
								ct = new Travel();
								fillObjectFromDatabase(ct, con);
								al.add(ct);
							}
						}
						catch (Exception e) {
							System.out.println("Image Gallery List not getting mom Database.");
						}finally {
				    // Always make sure result sets and statements are closed,
				    if (rs != null) {
					      try { rs.close(); } catch (SQLException e) { ; }
					      rs = null;
					    }
				    if (stmt != null) {
				      try { stmt.close(); } catch (SQLException e) { ; }
				      stmt = null;
				    }
				}
						return al;
					}
					
					
					// Get Category List mom database.
					public ArrayList<Travel>  getTravelList(int limit, Connection con){		
						Travel ct = null;
												
						ArrayList<Travel> al = new ArrayList<Travel>();
						String query= "select NAME from travel_data GROUP BY NAME";
						try{	
							 stmt = (Statement)con.createStatement();
							  rs = (ResultSet)stmt.executeQuery(query);
							while(rs.next()){		
								ct = new Travel();
								ct.setName(rs.getString("NAME"));
								al.add(ct);
							}
						}
						catch (Exception e) {
							System.out.println("Image Gallery List not getting mom Database.");
						}finally {
				    // Always make sure result sets and statements are closed,
				    if (rs != null) {
					      try { rs.close(); } catch (SQLException e) { ; }
					      rs = null;
					    }
				    if (stmt != null) {
				      try { stmt.close(); } catch (SQLException e) { ; }
				      stmt = null;
				    }
				}
						return al;
					}
					
					
					// Get Category List mom database.
					public ArrayList<Travel>  getTravelDistrictList(int limit, Connection con){		
						Travel ct = null;
												
						ArrayList<Travel> al = new ArrayList<Travel>();
						String query= "select DISTINCT DISTRICT from travel_data GROUP BY DISTRICT ORDER BY sum(VIEW_COUNT) DESC limit "+limit+"";
						try{	
							 stmt = (Statement)con.createStatement();
							  rs = (ResultSet)stmt.executeQuery(query);
							while(rs.next()){		
								ct = new Travel();
								ct.setDistrict(rs.getString("DISTRICT"));
								al.add(ct);
							}
						}
						catch (Exception e) {
							System.out.println("Image Gallery List not getting mom Database.");
						}finally {
				    // Always make sure result sets and statements are closed,
				    if (rs != null) {
					      try { rs.close(); } catch (SQLException e) { ; }
					      rs = null;
					    }
				    if (stmt != null) {
				      try { stmt.close(); } catch (SQLException e) { ; }
				      stmt = null;
				    }
				}
						return al;
					}
					
					// Get Category List mom database.
					public ArrayList<Travel>  getTravelCityList(int limit, Connection con){		
						Travel ct = null;
												
						ArrayList<Travel> al = new ArrayList<Travel>();
						String query= "select DISTRICT, CITY, IMAGE_PATH from travel_data group by CITY limit "+limit+"";
						try{	
							 stmt = (Statement)con.createStatement();
							  rs = (ResultSet)stmt.executeQuery(query);
							while(rs.next()){		
								ct = new Travel();
								ct.setDistrict(rs.getString("DISTRICT"));
								ct.setCity(rs.getString("CITY"));
								ct.setImagePath(rs.getString("IMAGE_PATH"));
								al.add(ct);
							}
						}
						catch (Exception e) {
							System.out.println("Image Gallery List not getting mom Database.");
						}finally {
				    // Always make sure result sets and statements are closed,
				    if (rs != null) {
					      try { rs.close(); } catch (SQLException e) { ; }
					      rs = null;
					    }
				    if (stmt != null) {
				      try { stmt.close(); } catch (SQLException e) { ; }
				      stmt = null;
				    }
				}
						return al;
					}
					
					
					// Get Category List mom database.
					public ArrayList<Travel>  getBlogSubCategoryList(int limit, Connection con){		
						Travel ct = null;
												
						ArrayList<Travel> al = new ArrayList<Travel>();
						String query= "select TRAVEL_CATEGORY, count(ID) as ID from travel_data GROUP BY TRAVEL_CATEGORY";
						try{	
							 stmt = (Statement)con.createStatement();
							  rs = (ResultSet)stmt.executeQuery(query);
							while(rs.next()){		
								ct = new Travel();
								ct.setTravelCategory(rs.getString("TRAVEL_CATEGORY"));
								ct.setId(rs.getInt("ID"));
								al.add(ct);
							}
						}
						catch (Exception e) {
							System.out.println("Image Gallery List not getting mom Database.");
						}finally {
				    // Always make sure result sets and statements are closed,
				    if (rs != null) {
					      try { rs.close(); } catch (SQLException e) { ; }
					      rs = null;
					    }
				    if (stmt != null) {
				      try { stmt.close(); } catch (SQLException e) { ; }
				      stmt = null;
				    }
				}
						return al;
					}
					
					


					// Count Total Blog.
					public Travel getSingleBlogByCategoryFiiter(String category, Connection con){		
						Travel ct =null;
						String query = "select * from travel_data where CATEGORY='"+category+"' order by ID DESC LIMIT 1";
						try{
							// rs = dbc.selectquery(query);
							stmt = (Statement)con.createStatement();
							  rs = (ResultSet)stmt.executeQuery(query);
							while (rs.next()) {
								ct = new Travel();
								fillObjectFromDatabase(ct, con);
							}
						}catch (Exception e) {
							e.printStackTrace();
						}
						return ct;
					}
			
			/**
			 * @param ct
			 * @throws SQLException
			 */
			private void fillObjectFromDatabase(Travel ct, Connection con) throws SQLException {
				ct.setId(rs.getInt("ID"));
				ct.setViewCount(rs.getInt("VIEW_COUNT"));
				ct.setTravelCategory(rs.getString("TRAVEL_CATEGORY"));
				ct.setSubjectLine(rs.getString("SUBJECT_LINE"));
				ct.setDescription(rs.getString("DESCRIPTION"));
				ct.setImagePath(rs.getString("IMAGE_PATH"));
				ct.setVideoPath(rs.getString("VIDEO_PATH"));
				ct.setEntryBy(rs.getString("ENTRY_BY"));
				ct.setState(rs.getString("STATE"));
				ct.setDistrict(rs.getString("DISTRICT"));
				ct.setCity(rs.getString("CITY"));
				ct.setStatus(rs.getString("STATUS"));
				ct.setName(rs.getString("NAME"));
				ct.setEntryDate(rs.getDate("ENTRY_DATE"));
				
			}
			// Count Total Blog.
						public Travel getBlogById(int id, Connection con){		
							Travel ct =null;
							String query = "select * from travel_data where ID="+id;
							try{
								 //rs = dbc.selectquery(query);
								stmt = (Statement)con.createStatement();
								  rs = (ResultSet)stmt.executeQuery(query);
								while (rs.next()) {
									ct = new Travel();
									fillObjectFromDatabase(ct, con);
								}
							}catch (Exception e) {
								e.printStackTrace();
							}
							return ct;
						}

						public Travel getBlogByURL(String url, Connection con){		
							Travel ct =null;
							String query = "select * from travel_data where TEXT_URL='"+url+"'";
							try{
								 //rs = dbc.selectquery(query);
								stmt = (Statement)con.createStatement();
								  rs = (ResultSet)stmt.executeQuery(query);
								while (rs.next()) {
									ct = new Travel();
									fillObjectFromDatabase(ct, con);
								}
							}catch (Exception e) {
								e.printStackTrace();
							}
							return ct;
						}
	// Count Total Blog.
		public int getLastBlogID(Connection con){		
			int i=0;
			String query = "select max(ID) as id from travel_data";
			try{
				//rs = dbc.selectquery(query);
				stmt = (Statement)con.createStatement();
				  rs = (ResultSet)stmt.executeQuery(query);
				while (rs.next()) {
					i = rs.getInt("id");
				}
				 if(i!=0){
					 System.out.println(i+" Row Selected");
				 }else {
					 System.out.println(i+" Please try Again.");
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
			return i;
		}

		//Delete Category into Database	
		public int deleteBlog(int id, Connection con){
			int i=0;
			String query = "delete from travel_data where ID="+id;
			try{
				// i = dbc.insertquery(query);
				ps=(PreparedStatement) con.prepareStatement(query);
				i=ps.executeUpdate();
				 if(i!=0){
					 System.out.println(i+" Blog Deleted  Successfully");
				 }else {
					 System.out.println(" Blog not Deleted.? Please try Again.");
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
			return i;	
		}
}

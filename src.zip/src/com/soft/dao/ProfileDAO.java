package com.soft.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import com.soft.model.Member;

public class ProfileDAO {
	Date dt = new Date();
	Statement stmt = null;
	ResultSet rs = null;
	PreparedStatement ps = null;
	String DATE_FORMAT = "yyyy-MM-dd";
	java.text.SimpleDateFormat simpledataformat = 
	      new java.text.SimpleDateFormat(DATE_FORMAT); 
	public int addMember(Member m, Connection con) {
		int i=0;
		
		String query = "insert into member(FIRST_NAME, LAST_NAME, EMAIL_ID, ADDRESS, LOGIN_ID, CONTACT_NUMBER,  PASSWORD,  CITY, STATE, PIN_CODE, COURSE, COMPANY_NAME, QUALIFICATION, EXPERIENCE, ENTRY_BY, ENTRY_DATE, BATCH, PHOTO_URL, " +
				" ACCOUNT_NO, IFSC, BANK_NAME, GOOGLE_PAY, PHONE_PE, PAY_TM, UPI_ID) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, now(), ?, 'NA', ?, ?, ?, ?, ?, ?, ?)";
		try{
		  ps=(PreparedStatement) con.prepareStatement(query);
		 ps.setString(1, m.getFirstName());
		 ps.setString(2, m.getLastName());
		 ps.setString(3, m.getEmail());
		 ps.setString(4, m.getAddress());
		 ps.setString(5, m.getLoginID());
		 ps.setString(7, m.getPassword());
		 ps.setString(6, m.getContactNumber());
		 ps.setString(8, m.getCity());
		 ps.setString(9, m.getState());
		 ps.setString(10, m.getPinCode());
		 ps.setString(11, m.getCourse());
		 ps.setString(12, m.getCompanyName());
		 ps.setString(13, m.getQualification());
		 ps.setString(14, m.getExperience());
		 ps.setString(15, m.getEntryBy());
		 ps.setString(16, m.getBatch());
		 
		 ps.setString(17, m.getAccountNo());
		 ps.setString(18, m.getIfsc());
		 ps.setString(19, m.getBankName());
		 ps.setString(20, m.getGooglePay());
		 ps.setString(21, m.getPhonePe());
		 ps.setString(22, m.getPayTm());
		 ps.setString(23, m.getUpiId());
		 
		 i=ps.executeUpdate();
		 if(i!=0){
			 i = getLastMemberID(con);
			 //Now Add Bank Account
//			 Bank b = new Bank();
//			 b.setMemberID(i);
//			 b.setBankName("NA");
//			 bkDAO.addNewBankAccount(b, con);
//			 // level Member Counter Entry
//			 i = lmcDAO.UpperLevelSponsorIDList(m.getLoginID(), con);
//			 // Member Entry In Discount Pool
//			 DiscountPool d= new DiscountPool();
//			 d.setLoginID(m.getLoginID());
//			 d.setEntryBy(m.getFirstName());
//			 d.setSessionPeriod("2018-19");
//			 dpDAO.addMemberInDiscountInPool(d, con);
	 }
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i;
	}
	
	
	
	public int updateUserDetails(Member m, Connection con){
		int i = 0;
	    try {  
	    	String query = "UPDATE member set FIRST_NAME=?, LAST_NAME=?, EMAIL_ID=?, ADDRESS=?, CONTACT_NUMBER=?,  " +
	    			"PASSWORD=?, CITY=?, STATE=?, PIN_CODE=?, ENTRY_BY=?, ACCOUNT_NO=?, IFSC=?, BANK_NAME=?, GOOGLE_PAY=?, PHONE_PE=?, PAY_TM=?, UPI_ID=? " +
	    			" WHERE ID = ?";
			 ps=(PreparedStatement) con.prepareStatement(query);
			 ps.setString(1, m.getFirstName());
			 ps.setString(2, m.getLastName());
			 ps.setString(3, m.getEmail());
			 ps.setString(4, m.getAddress());
			 ps.setString(5, m.getContactNumber());
			 ps.setString(6, m.getPassword());
			 ps.setString(7, m.getCity());
			 ps.setString(8, m.getState());
			 ps.setString(9, m.getPinCode());
			 ps.setString(10, m.getEntryBy());
			 
			 ps.setString(11, m.getAccountNo());
			 ps.setString(12, m.getIfsc());
			 ps.setString(13, m.getBankName());
			 ps.setString(14, m.getGooglePay());
			 ps.setString(15, m.getPhonePe());
			 ps.setString(16, m.getPayTm());
			 ps.setString(17, m.getUpiId());
			 
			 ps.setInt(18, m.getId());
			i=ps.executeUpdate();
	    	if(i!=0){
				 System.out.println(i+" Blog Updated  Successfully");
			 }else {
				 System.out.println(" Blog not Updated");
			}
	    	
		}catch (Exception e) {
			e.printStackTrace();
		}
		return i;	
	}
	
	public ArrayList<Member> selectStudentList(Connection con){		
		Member c = null;
		ArrayList<Member> al = new ArrayList<Member>();
		String query= "select * from member order by ID DESC";
		try{	
			  stmt = (Statement)con.createStatement();
			  rs = (ResultSet)stmt.executeQuery(query);
			  while (rs.next()){
				  c = new Member();
				  c.setId(rs.getInt("ID"));
				  c.setFirstName(rs.getString("FIRST_NAME"));
				  c.setLastName(rs.getString("LAST_NAME"));
				  c.setEmail(rs.getString("EMAIL_ID"));
				  c.setAddress(rs.getString("ADDRESS"));
				  c.setLoginID(rs.getString("LOGIN_ID"));
				  c.setContactNumber(rs.getString("CONTACT_NUMBER"));
				  c.setPassword(rs.getString("PASSWORD"));
				  c.setCity(rs.getString("CITY"));
				  c.setState(rs.getString("STATE"));
				  c.setPinCode(rs.getString("PIN_CODE"));
				  c.setCourse(rs.getString("COURSE"));
				  c.setCompanyName(rs.getString("COMPANY_NAME"));
				  c.setQualification(rs.getString("QUALIFICATION"));
				  c.setExperience(rs.getString("EXPERIENCE"));
				  c.setEntryBy(rs.getString("ENTRY_BY"));
				  c.setEntryDate(rs.getDate("ENTRY_DATE"));
				  c.setBatch(rs.getString("BATCH"));
				  c.setPhotoURL(rs.getString("PHOTO_URL"));
				  al.add(c);
			}
		}
		catch (Exception e) {
			System.out.println("muits List not getting mom Database.");
		}finally{
			try{
				 rs.close();
				 stmt.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return al;
	}
	
	public ArrayList<Member> selectStudentList(int id, Connection con){		
		Member c = null;
		ArrayList<Member> al = new ArrayList<Member>();
		String query= "select * from member where ID='"+id+"'";
		try{	
			  stmt = (Statement)con.createStatement();
			  rs = (ResultSet)stmt.executeQuery(query);
			  while (rs.next()){
				  c = new Member();
				  c.setId(rs.getInt("ID"));
				  c.setFirstName(rs.getString("FIRST_NAME"));
				  c.setLastName(rs.getString("LAST_NAME"));
				  c.setEmail(rs.getString("EMAIL_ID"));
				  c.setAddress(rs.getString("ADDRESS"));
				  c.setLoginID(rs.getString("LOGIN_ID"));
				  c.setContactNumber(rs.getString("CONTACT_NUMBER"));
				  c.setPassword(rs.getString("PASSWORD"));
				  c.setCity(rs.getString("CITY"));
				  c.setState(rs.getString("STATE"));
				  c.setPinCode(rs.getString("PIN_CODE"));
				  c.setCourse(rs.getString("COURSE"));
				  c.setCompanyName(rs.getString("COMPANY_NAME"));
				  c.setQualification(rs.getString("QUALIFICATION"));
				  c.setExperience(rs.getString("EXPERIENCE"));
				  c.setEntryBy(rs.getString("ENTRY_BY"));
				  c.setEntryDate(rs.getDate("ENTRY_DATE"));
				  c.setBatch(rs.getString("BATCH"));
				  c.setPhotoURL(rs.getString("PHOTO_URL"));
				  al.add(c);
			}
		}
		catch (Exception e) {
			System.out.println("muits List not getting mom Database.");
		}finally{
			try{
				 rs.close();
				 stmt.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return al;
	}
	
	public int updateStudentImage(ArrayList<String> path, long id, Connection con) {
		int i=0;
		String url = "";
		try{
			for(String s : path){
				i = i+1;
				if(i==1){
					url += " PHOTO_URL='"+s+"'";
				}else{
				url += ", PHOTO_URL='"+s+"'";
				}
			}
			
			String query = "update member set "+url+" where ID=?";
			 ps=(PreparedStatement) con.prepareStatement(query);
			 ps.setLong(1, id);
			 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i;
	}
	
	/*public int DeleteRegisterStudent(int id, Connection con) {
		String query = "delete from member where ID=?";
		int i=0;
		try{
			 ps=(PreparedStatement) con.prepareStatement(query);
			 ps.setInt(1, id);
			 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i;
	}*/
	
	public int updateTotalUpline(int totalDownline, String Uplineid, Connection con) {
		int i=0;
		int currDownLine = getTotalDownLine(Uplineid, con);
		String query = "update member set TOTAL_DOWNLINE=? where ID=?";
		try{
		 ps=(PreparedStatement) con.prepareStatement(query);
		 ps.setInt(1, (currDownLine + 1));
		 ps.setString(2, Uplineid);
		 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i;
	}

	public int updateImagePath(String loginID, String imagePath, Connection con) {
		int i=0;
		String query = "update member set PHOTO_URL=? where LOGIN_ID=?";
		try{
		 ps=(PreparedStatement) con.prepareStatement(query);
		 ps.setString(1, imagePath);
		 ps.setString(2, loginID);
		 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i;
	}	
	
	public int updateImagePath(int id, String imagePath, Connection con) {
		int i=0;
		String query = "update member set PHOTO_URL=? where ID=?";
		try{
		 ps=(PreparedStatement) con.prepareStatement(query);
		 ps.setString(1, imagePath);
		 ps.setInt(2, id);
		 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i;
	}
	
	public int updateIDProofPath(String loginID, String imagePath, Connection con) {
		int i=0;
		String query = "update member set ID_PROOF=? where LOGIN_ID=?";
		try{
		 ps=(PreparedStatement) con.prepareStatement(query);
		 ps.setString(1, imagePath);
		 ps.setString(2, loginID);
		 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i;
	}	
	// Get Category List mom database.
	public int getTotalDownLine(String loginID, Connection con) {
		int k = 0;
		String query = "select TOTAL_DOWNLINE as ID from member where UPLINE_ID='"+loginID+"'";
		try {
//			ResultSet rs = dbc.selectquery(query);
			 stmt = (Statement)con.createStatement();
			  rs = (ResultSet)stmt.executeQuery(query);
			while (rs.next()) {
				k = rs.getInt("ID");
			}
		} catch (Exception e) {
			System.out.println("Sorry! Please try again later.");
		}finally{
			try{
				 rs.close();
				 stmt.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return k;
	}

	// Get Category List mom database.
	public int getTotalSponsorCount(String loginID, Connection con) {
		int k = 0;
		String query = "select count(ID) as ID from member where SPONSOR_ID='"+loginID+"'";
		try {
//			ResultSet rs = dbc.selectquery(query);
			 stmt = (Statement)con.createStatement();
			  rs = (ResultSet)stmt.executeQuery(query);
			while (rs.next()) {
				k = rs.getInt("ID");
			}
		} catch (Exception e) {
			System.out.println("Sorry! Please try again later.");
		}finally{
			try{
				 rs.close();
				 stmt.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return k;
	}
	// Get Category List mom database.
	public String getLastSideID(String side, String loginID, Connection con) {
		String k = null;
		String query = "select LOGIN_ID as logID from member where SIDE='"+side+"' AND UPLINE_ID='"+loginID+"'" ;
		try {
//			ResultSet rs = dbc.selectquery(query);
			 stmt = (Statement)con.createStatement();
			  rs = (ResultSet)stmt.executeQuery(query);
			while (rs.next()) {
				k = rs.getString("logID");
			}
		} catch (Exception e) {
			System.out.println("Sorry! Please try again later.");
		}finally{
			try{
				 rs.close();
				 stmt.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return k;
	}
	
	public int updateMemberDetails(Member m, Connection con) {
		int i=0;
		String query = "update member set FIRST_NAME=?, LAST_NAME=?, EMAIL_ID=?, ADDRESS=?, CONTACT_NUMBER=?, CITY=?, STATE=?, ENTRY_BY=?, ACCOUNT_NO=?, IFSC=?, BANK_NAME=?, GOOGLE_PAY=?, PHONE_PE=?, PAY_TM=?, UPI_ID=? where ID=?";
		try{
//		 con=dbc.insertPreparequery();
		 ps=(PreparedStatement) con.prepareStatement(query);
		 ps.setString(1, m.getFirstName());
		 ps.setString(2, m.getLastName());
		 ps.setString(3, m.getEmail());
		 ps.setString(4, m.getAddress());
		 ps.setString(5, m.getContactNumber());
		 ps.setString(6, m.getCity());
		 ps.setString(7, m.getState());
		 ps.setString(8, m.getEntryBy());
		 
		 ps.setString(9, m.getAccountNo());
		 ps.setString(10, m.getIfsc());
		 ps.setString(11, m.getBankName());
		 ps.setString(12, m.getGooglePay());
		 ps.setString(13, m.getPhonePe());
		 ps.setString(14, m.getPayTm());
		 ps.setString(15, m.getUpiId());
		 
		 
		 ps.setInt(16, m.getId());
		 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i;
	}
	public int updateProfileStatus(String status, int id, Connection con) {
		int i=0;
		String query = "update member set PROFILE_STATUS=? where ID=?";
		try{
//		 con=dbc.insertPreparequery();
		 ps=(PreparedStatement) con.prepareStatement(query);
		 ps.setString(1, status);
		 ps.setInt(2, id);
		 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i;
	}

	public int updateKYCStatus(String status, int id, Connection con) {
		int i=0;
		String query = "update member set KYC_STATUS=? where ID=?";
		try{
//		 con=dbc.insertPreparequery();
		 ps=(PreparedStatement) con.prepareStatement(query);
		 ps.setString(1, status);
		 ps.setInt(2, id);
		 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i;
	}
	public int updateProfileStatus(String status, int id, String loginID, Connection con) {
		int i=0;
		String query = "update member set PROFILE_STATUS=? where ID=? AND LOGIN_ID=?";
		try{
//		 con=dbc.insertPreparequery();
		 ps=(PreparedStatement) con.prepareStatement(query);
		 ps.setString(1, status);
		 ps.setInt(2, id);
		 ps.setString(3, loginID);
		 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i;
	}
	public int accountActivate(String kitName, String status, String memberID, float planType, Connection con) {
		int i=0;
		String query = "update member set SIDE=?, PROFILE_STATUS=?, PLAN_TYPE=?, TOPUP_DATE=now() where LOGIN_ID=?";
		try{
//		 con=dbc.insertPreparequery();
		 ps=(PreparedStatement) con.prepareStatement(query);
		 ps.setString(1, kitName);
		 ps.setString(2, "ACTIVE");
		 ps.setFloat(3, planType);
		 ps.setString(4, memberID);
		 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i;
	}
	public Member updateProfileStatusByUser(String status, String  loginID, Connection con) {
		Member m = null;	
		int i=0;
		Member dnLine = getSilgleMemberDetailsByLoginID(loginID, con);
		String query = "update member set PROFILE_STATUS=?, TOTAL_DOWNLINE=? where LOGIN_ID=?";
		try{
//		 con=dbc.insertPreparequery();
		 ps=(PreparedStatement) con.prepareStatement(query);
		 ps.setString(1, status);
		 ps.setInt(2, (dnLine.getTotalDownline() + 1));
		 ps.setString(3, loginID);
		 i=ps.executeUpdate();
		 if(i!=0){
			m= getSilgleMemberDetailsByLoginID(loginID, con);
		 }
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return m;
	}
	
	// Get Category List mom database.
				public Member getSilgleMemberDetails(int id, Connection con){		
					Member mbr = null;
//					ResultSet rs = null;
					String query= "select * from member where ID="+id;
					try{	
//						rs = dbc.selectquery(query);
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){		
							mbr = getSingleStoreEntry(rs);
						}
					}
					catch (Exception e) {
						System.out.println("muits List not getting mom Database.");
					}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
					return mbr;
				}
				// Get Category List mom database.
				public Member getSilgleMemberDetailsByLoginID(String id, Connection con){		
					Member mbr = null;
//					ResultSet rs = null;
					String query= "select * from member where LOGIN_ID='"+id+"'";
					try{	
//						rs = dbc.selectquery(query);
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){		
							mbr = getSingleStoreEntry(rs);
						}
					}
					catch (Exception e) {
						System.out.println("muits List not getting mom Database.");
					}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
					return mbr;
				}

				// Get Category List mom database.
				public Member getUplineID(String loginId, Connection con){		
					Member mbr = null;
//					ResultSet rs = null;
					String query= "select * from member where LOGIN_ID='"+loginId+"'";
					try{	
//						rs = dbc.selectquery(query);
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){		
							mbr = getSingleStoreEntry(rs);
						}
					}
					catch (Exception e) {
						System.out.println("muits List not getting mom Database.");
					}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
					return mbr;
				}
				
				// Get Category List mom database.
				public Member getSilgleMemberDetailsByLoginID(String email, String contact, Connection con){		
					Member mbr = null;
//					ResultSet rs = null;
					String filter = " 1=1";
					if(email!=null && !email.equals("")){
						filter +=" AND EMAIL_ID='"+email+"'";
					}
					if(contact!=null && !contact.equals("")){
						filter +=" AND CONTACT_NUMBER='"+contact+"'";
					}
					String query= "select * from member where "+filter;
					try{	
//						rs = dbc.selectquery(query);
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){		
							mbr = getSingleStoreEntry(rs);
						}
					}
					catch (Exception e) {
						System.out.println("muits List not getting mom Database.");
					}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
					return mbr;
				}
				
				// Get Category List mom database.
				public Member getSilgleMemberDetailsByUplineID(String id, Connection con){		
					Member mbr = null;
					String query= "select * from member where UPLINE_ID='"+id+"'";
					try{	
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){		
							mbr = getSingleStoreEntry(rs);
						}
					}
					catch (Exception e) {
						System.out.println("muits List not getting mom Database.");
					}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
					return mbr;
				}
				// Get Down Line List mom database.
				public ArrayList<Member> getMemberList(int id, Connection con){		
					Member mbr = null;
					int start = id - 20;
				    ArrayList<Member> al = new ArrayList<Member>();
					String query= "select * from member where ID between "+start+" AND "+id+" ORDER BY ID DESC";
					try{	
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){		
							mbr = getSingleStoreEntry(rs);
							al.add(mbr);
						}
					}
					catch (Exception e) {
						System.out.println("muits List not getting mom Database.");
					}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
					return al;
				}
				// Get Down Line List mom database.
				public ArrayList<Member> getMemberListForApproval(Connection con){		
					Member mbr = null;
				    ArrayList<Member> al = new ArrayList<Member>();
					String query= "select * from member where PROFILE_STATUS in ('INACTIVE', 'MIDDLE')";
					try{	
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){		
							mbr = getSingleStoreEntry(rs);
							al.add(mbr);
						}
					}
					catch (Exception e) {
						System.out.println("muits List not getting mom Database.");
					}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
					return al;
				}
				// Get Down Line List mom database.
				public ArrayList<Member> getSponsoredListByDate(String loginID, Date dt, Connection con){		
					Member mbr = null;
				    ArrayList<Member> al = new ArrayList<Member>();
					String query = "select * from member where SPONSOR_ID='"+loginID+"' AND TOPUP_DATE >'"+dt+"' AND PROFILE_STATUS='ACTIVE' ORDER BY ID DESC";
					try{	
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){		
							mbr = getSingleStoreEntry(rs);
							al.add(mbr);
						}
					}
					catch (Exception e) {
						System.out.println("muits List not getting mom Database.");
					}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
					return al;
				}
				
				public String getLastMemberLOGIN_ID(Connection con) {
					String id = null;
					String query = "select LOGIN_ID from member ORDER BY ID DESC LIMIT 1";
					try {
//						ResultSet rs = dbc.selectquery(query);
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while (rs.next()) {
							id = rs.getString("LOGIN_ID");
						}
					}catch (Exception e) {
						System.out.println("Sorry! Please try again later.");
					}finally{
						try{
							 rs.close();
							 stmt.close();
							}catch (Exception e) {
								e.printStackTrace();
							}
						}
					return id;
				}
				
				// Get Down Line List mom database.
				public ArrayList<Member> getSponsoredListBy(String loginID, Connection con){		
					Member mbr = null;
				    ArrayList<Member> al = new ArrayList<Member>();
					String query = "select * from member where SPONSOR_ID='"+loginID+"' AND PROFILE_STATUS='ACTIVE' ORDER BY (ID) DESC";
					try{	
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){		
							mbr = getSingleStoreEntry(rs);
							al.add(mbr);
						}
					}
					catch (Exception e) {
						System.out.println("muits List not getting mom Database.");
					}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
					return al;
				}
				// Get Down Line List mom database.
				public ArrayList<Member> getGeneology(String loginID, Connection con){		
					Member mbr = null;
				    ArrayList<Member> al = new ArrayList<Member>();
					String query= "select * from member where UPLINE_ID='"+loginID+"'";
					try{	
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){		
							mbr = getSingleStoreEntry(rs);
							al.add(mbr);
						}
					}
					catch (Exception e) {
						System.out.println("muits List not getting mom Database.");
					}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
					return al;
				}
				// Get Down Line List mom database.
				public HashMap<String, Member> getFullDataDownLine(int id, String side, Connection con){		
					Member mbr = null;
				    HashMap<String, Member> hm = new HashMap<String, Member>();
					String query= "select LOGIN_ID, UPLINE_ID, SIDE, PROFILE_STATUS from member where ID >" + id + " AND SIDE='"+side+"'";
					try{	
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){
							mbr = new Member();
							mbr.setLoginID(rs.getString("LOGIN_ID"));
							mbr.setSide(rs.getString("SIDE"));
							mbr.setProfileStatus(rs.getString("PROFILE_STATUS"));
							hm.put(rs.getString("UPLINE_ID"), mbr);
						}
					}
					catch (Exception e) {
						System.out.println("muits List not getting fmom Database.");
					}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
					return hm;
				}
				

				// Get Down Line List mom database.
				public ArrayList<Member> getFullDataDownLineForGeonology(int id, Connection con){		
					Member mbr = null;
				    ArrayList<Member> al = new ArrayList<Member>();
					String query= "select * from member where ID >" + id;
					try{	
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){
							mbr = getSingleStoreEntry(rs);
							al.add(mbr);
						}
					}
					catch (Exception e) {
						System.out.println("muits List not getting fmom Database.");
					}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
					return al;
				}
				// Get Down Line List mom database.
				public ArrayList<Member> getDownLine(String loginID, Connection con){		
					Member mbr = null;
				    ArrayList<Member> al = new ArrayList<Member>();
					String query= "select * from member where SPONSOR_ID='"+loginID+"'";
					try{	
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){		
							mbr = getSingleStoreEntry(rs);
							al.add(mbr);
						}
					}
					catch (Exception e) {
						System.out.println("muits List not getting mom Database.");
					}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
					return al;
				}
				

				// Get Down Line List from database.
				public ArrayList<Member> getCompleteDownLine(String loginID, Connection con){		
					Member mbr = null;
				    ArrayList<Member> al = new ArrayList<Member>();
				    ArrayList<Member> secondAl = new ArrayList<Member>();
				    ArrayList<Member> alFull = new ArrayList<Member>();
					String query= "select * from member where SPONSOR_ID='"+loginID+"'";
					try{	
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						  //direct Referral
						while(rs.next()){		
							mbr = getSingleStoreEntry(rs);
							mbr.setTotalDownline(1);
							al.add(mbr);
							alFull.add(mbr);
						}
						//first Lelvel
						for(Member fstLvl : al){
							 query= "select * from member where SPONSOR_ID='"+fstLvl.getLoginID()+"'";
								 stmt = (Statement)con.createStatement();
								  rs = (ResultSet)stmt.executeQuery(query);
								while(rs.next()){		
									mbr = getSingleStoreEntry(rs);
									mbr.setTotalDownline(2);
									secondAl.add(mbr);
									alFull.add(mbr);
								}
						}
						al.clear();
						//Second Lelvel
						for(Member fstLvl : secondAl){
							 query= "select * from member where SPONSOR_ID='"+fstLvl.getLoginID()+"'";
								 stmt = (Statement)con.createStatement();
								  rs = (ResultSet)stmt.executeQuery(query);
								while(rs.next()){		
									mbr = getSingleStoreEntry(rs);
									mbr.setTotalDownline(3);
									al.add(mbr);
									alFull.add(mbr);
								}
						}
						secondAl.clear();
						//third Lelvel
						for(Member fstLvl : al){
							 query= "select * from member where SPONSOR_ID='"+fstLvl.getLoginID()+"'";
								 stmt = (Statement)con.createStatement();
								  rs = (ResultSet)stmt.executeQuery(query);
								while(rs.next()){		
									mbr = getSingleStoreEntry(rs);
									mbr.setTotalDownline(4);
									secondAl.add(mbr);
									alFull.add(mbr);
								}
						}

						al.clear();
						//fourth Lelvel
						for(Member fstLvl : secondAl){
							 query= "select * from member where SPONSOR_ID='"+fstLvl.getLoginID()+"'";
								 stmt = (Statement)con.createStatement();
								  rs = (ResultSet)stmt.executeQuery(query);
								while(rs.next()){		
									mbr = getSingleStoreEntry(rs);
									mbr.setTotalDownline(5);
									al.add(mbr);
									alFull.add(mbr);
								}
						}

						secondAl.clear();
						//Fifth Lelvel
						for(Member fstLvl : al){
							 query= "select * from member where SPONSOR_ID='"+fstLvl.getLoginID()+"'";
								 stmt = (Statement)con.createStatement();
								  rs = (ResultSet)stmt.executeQuery(query);
								while(rs.next()){		
									mbr = getSingleStoreEntry(rs);
									mbr.setTotalDownline(6);
									secondAl.add(mbr);
									alFull.add(mbr);
								}
						}

						/*secondAl.clear();
						//Sixth Lelvel
						for(Member fstLvl : secondAl){
							 query= "select * from member where SPONSOR_ID='"+fstLvl.getLoginID()+"'";
								 stmt = (Statement)con.createStatement();
								  rs = (ResultSet)stmt.executeQuery(query);
								while(rs.next()){		
									mbr = getSingleStoreEntry(rs);
									mbr.setTotalDownline(6);
									alFull.add(mbr);
								}
						}*/
					}catch (Exception e) {
						e.printStackTrace();
					}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
					return alFull;
				}
				
				// Get Down Line List mom database.
				public ArrayList<Member> getDownLineStatusForSecindWithdrawal(String loginID, Connection con){		
					Member mbr = null;
				    ArrayList<Member> al = new ArrayList<Member>();
					String query= "select * from member where UPLINE_ID='"+loginID+"' AND PROFILE_STATUS='ACTIVE'";
					try{	
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){		
							mbr = getSingleStoreEntry(rs);
							al.add(mbr);
						}
					}
					catch (Exception e) {
						System.out.println("muits List not getting mom Database.");
					}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
					return al;
				}
				// Get Down Line List mom database.
				public int checkTotalDownLine(String loginID, Connection con){		
					int total = 0;
					String query= "select count(ID) as total from member where UPLINE_ID='"+loginID+"'";
					try{	
//						ResultSet rs = dbc.selectquery(query);
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){		
							total= rs.getInt("total");
						}
					}
					catch (Exception e) {
						System.out.println("muits List not getting mom Database.");
					}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
					return total;
				}
				// Get Down Line List mom database.
				public ArrayList<Member> getDownLineSingleSide(String loginID, String side, Connection con){		
					Member mbr = null;
				    ArrayList<Member> al = new ArrayList<Member>();
					String query= "select * from member where UPLINE_ID='"+loginID+"' AND SIDE='"+side+"'";
					try{	
//						ResultSet rs = dbc.selectquery(query);
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){		
							mbr = getSingleStoreEntry(rs);
							al.add(mbr);
						}
					}
					catch (Exception e) {
						System.out.println("muits List not getting mom Database.");
					}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
					return al;
				}
				
				// Get Down Line List mom database.
				public ArrayList<Member> getDownLineBithSide(String loginID, Connection con){		
					Member m = null;
				    ArrayList<Member> al = new ArrayList<Member>();
					String query= "select FIRST_NAME, LAST_NAME, PLAN_TYPE, LOGIN_ID, ENTRY_DATE, SPONSOR_ID, SIDE, PROFILE_STATUS from member where UPLINE_ID='"+loginID+"'";
					try{	
//						ResultSet rs = dbc.selectquery(query);
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){	
							m = new Member();
							m.setFirstName(rs.getString("FIRST_NAME"));
							m.setLastName(rs.getString("LAST_NAME"));
							m.setLoginID(rs.getString("LOGIN_ID"));
							m.setEntryDate(rs.getDate("ENTRY_DATE"));
							m.setSide(rs.getString("SIDE"));
							m.setPlanType(rs.getFloat("PLAN_TYPE"));
							m.setProfileStatus(rs.getString("PROFILE_STATUS"));
							m.setSponsorID(rs.getString("SPONSOR_ID"));
							al.add(m);
						}
					}
					catch (Exception e) {
						System.out.println("muits List not getting mom Database.");
					}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
					return al;
				}
				// Get Down Line List mom database.
				public Member getDownLineByLoginID(String loginID, Connection con){		
					Member m = null;
					String query= "select * from member where LOGIN_ID= '"+loginID+"' AND PROFILE_STATUS='ACTIVE'";
					try{	
//						ResultSet rs = dbc.selectquery(query);
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){	
							m = new Member();
							m.setFirstName(rs.getString("FIRST_NAME"));
							m.setLastName(rs.getString("LAST_NAME"));
							m.setLoginID(rs.getString("LOGIN_ID"));
							m.setEntryDate(rs.getDate("ENTRY_DATE"));
							m.setSide(rs.getString("SIDE"));
							m.setPlanType(rs.getFloat("PLAN_TYPE"));
							m.setProfileStatus(rs.getString("PROFILE_STATUS"));
							m.setSponsorID(rs.getString("SPONSOR_ID"));
							m.setTopupDate(rs.getDate("TOPUP_DATE"));
						}
					}
					catch (Exception e) {
						System.out.println("muits List not getting mom Database.");
					}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
					return m;
				}

				// Get Down Line List mom database.
				public ArrayList<Member> getDownLineByAllActiveProfile(String allList, Connection con){		
					Member m = null;
				    ArrayList<Member> al = new ArrayList<Member>();
					String query= "select ID, FIRST_NAME, LAST_NAME, LOGIN_ID, ENTRY_DATE,SIDE, PLAN_TYPE, PROFILE_STATUS, SPONSOR_ID, count(ENTRY_DATE) as totalDownline, TOPUP_DATE from member where LOGIN_ID IN("+allList+") AND PROFILE_STATUS='ACTIVE' GROUP BY ENTRY_DATE, PLAN_TYPE";
					try{	
//						ResultSet rs = dbc.selectquery(query);
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){	
							m = new Member();
							m.setId(rs.getInt("ID"));
							m.setFirstName(rs.getString("FIRST_NAME"));
							m.setLastName(rs.getString("LAST_NAME"));
							m.setLoginID(rs.getString("LOGIN_ID"));
							m.setEntryDate(rs.getDate("ENTRY_DATE"));
							m.setSide(rs.getString("SIDE"));
							m.setPlanType(rs.getFloat("PLAN_TYPE"));
							m.setProfileStatus(rs.getString("PROFILE_STATUS"));
							m.setSponsorID(rs.getString("SPONSOR_ID"));
							m.setTopupDate(rs.getDate("TOPUP_DATE"));
							m.setTotalDownline(rs.getInt("totalDownline"));
							al.add(m);
						}
					}
					catch (Exception e) {
						System.out.println("muits List not getting mom Database.");
					}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
					return al;
				}
				// Get Down Line List mom database.
				public int getDownLineCountForProfilePopup(String allList, Connection con){		
					int m = 0;
					String query= "select count(LOGIN_ID) as totalCount from member where LOGIN_ID IN("+allList+") AND PROFILE_STATUS='ACTIVE'";
					try{	
//						ResultSet rs = dbc.selectquery(query);
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){	
							m = rs.getInt("totalCount");
						}
					}
					catch (Exception e) {
						System.out.println("muits List not getting mom Database.");
					}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
					return m;
				}
			
				
				// Get Down Line List mom database.
				

				// Get Down Line List mom database.
				public ArrayList<Member> getDownLineInGroup(String allList, Connection con){		
					Member m = null;
				    ArrayList<Member> al = new ArrayList<Member>();
					String query= "select * from member where LOGIN_ID IN("+allList+")";
					try{	
//						ResultSet rs = dbc.selectquery(query);
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){	
							m = new Member();
							m.setFirstName(rs.getString("FIRST_NAME"));
							m.setLastName(rs.getString("LAST_NAME"));
							m.setLoginID(rs.getString("LOGIN_ID"));
							m.setEntryDate(rs.getDate("ENTRY_DATE"));
							m.setSide(rs.getString("SIDE"));
							m.setPlanType(rs.getFloat("PLAN_TYPE"));
							m.setProfileStatus(rs.getString("PROFILE_STATUS"));
							m.setSponsorID(rs.getString("SPONSOR_ID"));
							m.setTopupDate(rs.getDate("TOPUP_DATE"));
							al.add(m);
						}
					}
					catch (Exception e) {
						System.out.println("muits List not getting mom Database.");
					}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
					return al;
				}
				// method calling from Binary Income
				public Member getDownlineForBinaryIncome(String loginID, Connection con){		
					Member m = null;
					String query= "select * from member where LOGIN_ID='"+loginID+"' AND PROFILE_STATUS='ACTIVE'";
					try{	
//						ResultSet rs = dbc.selectquery(query);
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){	
							m = new Member();
							m= getSingleStoreEntry(rs);
						}
					}
					catch (Exception e) {
						System.out.println("muits List not getting mom Database.");
					}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
					return m;
				}
				// method calling from Binary Income
				public Member getSingleMemberForRegistrationCheck(String email, Connection con){		
					Member m = null;
					String query= "select * from member where EMAIL_ID='"+email+"'";
					try{	
//						ResultSet rs = dbc.selectquery(query);
						 stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						while(rs.next()){	
							m = new Member();
							m= getSingleStoreEntry(rs);
						}
					}
					catch (Exception e) {
						System.out.println("muits List not getting mom Database.");
					}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
					return m;
				}
				//Get AdminCategory Data Method
				private Member getSingleStoreEntry(ResultSet rs)
						throws SQLException {
					Member m;
					m=new Member();
					m.setId(rs.getInt("ID"));
					m.setFirstName(rs.getString("FIRST_NAME"));
					m.setLastName(rs.getString("LAST_NAME"));
					m.setEmail(rs.getString("EMAIL_ID"));
					m.setAddress(rs.getString("ADDRESS"));
					m.setLoginID(rs.getString("LOGIN_ID"));
					m.setContactNumber(rs.getString("CONTACT_NUMBER"));
					m.setPassword(rs.getString("PASSWORD"));
					m.setCity(rs.getString("CITY"));
					m.setState(rs.getString("STATE"));
					 m.setPinCode(rs.getString("PIN_CODE"));
					m.setCourse(rs.getString("COURSE"));
					m.setCompanyName(rs.getString("COMPANY_NAME"));
					m.setQualification(rs.getString("QUALIFICATION"));
					m.setExperience(rs.getString("EXPERIENCE"));
					m.setEntryBy(rs.getString("ENTRY_BY"));
					m.setEntryDate(rs.getDate("ENTRY_DATE"));
					m.setPhotoURL(rs.getString("PHOTO_URL"));
					
					m.setAccountNo(rs.getString("ACCOUNT_NO"));
					m.setIfsc(rs.getString("IFSC"));
					m.setBankName(rs.getString("BANK_NAME"));
					m.setGooglePay(rs.getString("GOOGLE_PAY"));
					m.setPhonePe(rs.getString("PHONE_PE"));
					m.setPayTm(rs.getString("PAY_TM"));
					m.setUpiId(rs.getString("UPI_ID"));
					
					return m;
				}
	// Get Category List mom database.
	public int getLastMemberID(Connection con) {
		int id = 0;
		String query = "select max(ID) as ID from member";
		try {
//			ResultSet rs = dbc.selectquery(query);
			 stmt = (Statement)con.createStatement();
			  rs = (ResultSet)stmt.executeQuery(query);
			while (rs.next()) {
				id = rs.getInt("ID");
			}
		}catch (Exception e) {
			System.out.println("Sorry! Please try again later.");
		}finally{
			try{
				 rs.close();
				 stmt.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return id;
	}
	// Get Category List mom database.
	public int getTotalSponsorCountByLoginID(String loginID, String status, Connection con) {
		int id = 0;
		String filter = " 1 = 1 AND SPONSOR_ID='"+loginID+"'";
		if(status.equals("ACTIVE")){
			filter += " AND PROFILE_STATUS='ACTIVE'";
		}
		String query = "select count(ID) as ID from member where "+ filter;
		try {
//			ResultSet rs = dbc.selectquery(query);
			 stmt = (Statement)con.createStatement();
			  rs = (ResultSet)stmt.executeQuery(query);
			while (rs.next()) {
				id = rs.getInt("ID");
			}
		} catch (Exception e) {
			System.out.println("Sorry! Please try again later.");
		}finally{
			try{
				 rs.close();
				 stmt.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return id;
	}

	// he is new joining he will get the details of receiver from him.
	
	// Get Down Line List mom database.
	public ArrayList<Member> getMemberListFilter(String loginId, String firstName, String lastName, String contactNo, Date fromDate, Date toDate, String city, String state, String profileStatus, String email, Connection con){		
		Member mbr = null;
		String filter = " where 1=1";
		if(loginId!=null && !loginId.equals("")){
			filter +=" AND LOGIN_ID='"+loginId+"'";
		}
		if(firstName!=null && !firstName.equals("")){
			filter +=" AND FIRST_NAME='"+firstName+"'";
		}
		if(lastName!=null && !lastName.equals("")){
			filter +=" AND LAST_NAME='"+lastName+"'";
		}
		if(contactNo!=null && !contactNo.equals("")){
			filter +=" AND CONTACT_NUMBER='"+contactNo+"'";
		}
		if(city!=null && !city.equals("")){
			filter +=" AND CITY='"+city+"'"; 
		}
		if(state!=null && !state.equals("")){
			filter +=" AND STATE='"+state+"'";
		}
		if(email!=null && !email.equals("")){
			filter +=" AND EMAIL_ID='"+email+"'";
		}
		if(profileStatus!=null && !profileStatus.equals("")){
			filter +=" AND PROFILE_STATUS='"+profileStatus+"'";
		}
		if(fromDate!=null && !fromDate.equals("") && toDate!=null && !toDate.equals("")){
			filter +=" AND TOPUP_DATE between '"+new java.sql.Date(fromDate.getTime())+"' AND '"+new java.sql.Date(toDate.getTime())+"' ";
		}
	    ArrayList<Member> al = new ArrayList<Member>();
		String query= "select * from member "+filter+" ORDER BY ID DESC";
		try{	
//			ResultSet rs = dbc.selectquery(query);
			 stmt = (Statement)con.createStatement();
			  rs = (ResultSet)stmt.executeQuery(query);
			while(rs.next()){		
				mbr = getSingleStoreEntry(rs);
				al.add(mbr);
			}
		}catch (Exception e) {
			System.out.println("filter member List not getting mom Database.");
		}finally{
			try{
				 rs.close();
				 stmt.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return al;
	}
	
	public int selectTotalStudent(Connection con){		
		int i=0;
		String query= "select count(ID) as ID from member";
		try{	
			  stmt = (Statement)con.createStatement();
			  rs = (ResultSet)stmt.executeQuery(query);
			  while (rs.next()) {
				  i = rs.getInt("ID");
			}
		}
		catch (Exception e) {
			System.out.println("muits List not getting mom Database.");
		}finally{
			try{
				 rs.close();
				 stmt.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i-1;
	}

}

package com.soft.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class WelcomePageDAO {
//    DBConnection dbc=new DBConnection();
	int i=0;
	Statement stmt = null;
	ResultSet rs = null;
//	Connection con = (Connection)DBConnection.getInstance().insertPreparequery();
	PreparedStatement ps = null;
	// Get Category List fmom database.
		public int gettotalUsedPinAmount(String memberID, Connection con) {
			int id = 0;
			String query = "select sum(PIN_RATE) as totalPinAmount from pin_list where MEMBER_ID='"+memberID+"' AND TRANSFER_TO_ID='NO'";
			try {
				 stmt = (Statement)con.createStatement();
				  rs = (ResultSet)stmt.executeQuery(query);
				while (rs.next()) {
					id = rs.getInt("totalPinAmount");
				}
			} catch (Exception e) {
				System.out.println("Sorry! Please try again later.");
			}finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			    if (stmt != null) {
			      try { stmt.close(); } catch (SQLException e) { ; }
			      stmt = null;
			    }
			}
			return id;
		}

}

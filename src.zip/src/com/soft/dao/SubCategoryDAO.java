package com.soft.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.soft.model.Category;

public class SubCategoryDAO {

//    DBConnection dbc=new DBConnection();
	int i=0;
	Statement stmt = null;
	ResultSet rs = null;
//	Connection con = (Connection)DBConnection.getInstance().insertPreparequery();
	PreparedStatement ps = null;
	public int addCategory(Category  c, Connection con) {
		String query = "insert into top_category(MAIN_CATEGORY, SUB_CATEGORY, COMMENTS, ENTRY_BY, ENTRY_DATE) values(?, ?, ?, ?,  now())";
		try{
//		 con=dbc.insertPreparequery();
		 ps=(PreparedStatement) con.prepareStatement(query);
		 ps.setString(1, c.getMainCategory());
		 ps.setString(2, c.getSubCategory());
		 ps.setString(3, c.getExtras());
		 ps.setString(4, c.getEntryBy());
		 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i;
	}
	// he is new joining he will get the details of receiver from him.
			public ArrayList<Category> selectCategoryList(Connection con){		
				Category c = null;
				ArrayList<Category> al = new ArrayList<Category>();
				String query= "select * from top_category order by MAIN_CATEGORY ASC";
				try{	
					  stmt = (Statement)con.createStatement();
					  rs = (ResultSet)stmt.executeQuery(query);
					  while (rs.next()) {
						  c = new Category();
						  c.setId(rs.getInt("ID"));
						  c.setEntryBy(rs.getString("ENTRY_BY"));
						  c.setEntryDate(rs.getDate("ENTRY_DATE").toString());
						  c.setExtras(rs.getString("COMMENTS"));
						  c.setMainCategory(rs.getString("MAIN_CATEGORY"));
						  c.setSubCategory(rs.getString("SUB_CATEGORY"));
						  al.add(c);
					}
				}
				catch (Exception e) {
					System.out.println("muits List not getting mom Database.");
				}finally{
					try{
						 rs.close();
						 stmt.close();
						}catch (Exception e) {
							e.printStackTrace();
						}
					}
				return al;
			}

			// he is new joining he will get the details of receiver from him.
			public ArrayList<Category> selectCategoryListByMainCategoryForVisitor(String mainCategory, Connection con){		
				Category c = null;
				ArrayList<Category> al = new ArrayList<Category>();
				String query= "select * from top_category where MAIN_CATEGORY='"+mainCategory+"' order by SUB_CATEGORY DESC";
				try{	
					  stmt = (Statement)con.createStatement();
					  rs = (ResultSet)stmt.executeQuery(query);
					  while (rs.next()) {
						  c = new Category();
						  c.setId(rs.getInt("ID"));
						  c.setEntryBy(rs.getString("ENTRY_BY"));
						  c.setEntryDate(rs.getDate("ENTRY_DATE").toString());
						  c.setExtras(rs.getString("COMMENTS"));
						  c.setMainCategory(rs.getString("MAIN_CATEGORY"));
						  c.setSubCategory(rs.getString("SUB_CATEGORY"));
						  al.add(c);
					}
				}
				catch (Exception e) {
					System.out.println("muits List not getting mom Database.");
				}finally{
					try{
						 rs.close();
						 stmt.close();
						}catch (Exception e) {
							e.printStackTrace();
						}
					}
				return al;
			}
			
			
			
			
			
			
			// he is new joining he will get the details of receiver from him.
					public ArrayList<Category> selectCategoryListByMainCategory(String mainCategory, Connection con){		
						Category c = null;
						ArrayList<Category> al = new ArrayList<Category>();
						String query= "select * from top_category where MAIN_CATEGORY='"+mainCategory+"' order by SUB_CATEGORY DESC";
						try{	
							  stmt = (Statement)con.createStatement();
							  rs = (ResultSet)stmt.executeQuery(query);
							  while (rs.next()) {
								  c = new Category();
								  c.setId(rs.getInt("ID"));
								  c.setEntryBy(rs.getString("ENTRY_BY"));
								  c.setEntryDate(rs.getDate("ENTRY_DATE").toString());
								  c.setExtras(rs.getString("COMMENTS"));
								  c.setMainCategory(rs.getString("MAIN_CATEGORY"));
								  c.setSubCategory(rs.getString("SUB_CATEGORY"));
								  al.add(c);
							}
						}
						catch (Exception e) {
							System.out.println("muits List not getting mom Database.");
						}finally{
							try{
								 rs.close();
								 stmt.close();
								}catch (Exception e) {
									e.printStackTrace();
								}
							}
						return al;
					}
			// he is new joining he will get the details of receiver from him.
					public int totalCategoryCount(Connection con){		
						int count=0;
						String query= "select max(ID) as ID from top_category";
						try{	
							  stmt = (Statement)con.createStatement();
							  rs = (ResultSet)stmt.executeQuery(query);
							  while (rs.next()) {
								count = rs.getInt("ID");
							}
						}
						catch (Exception e) {
							System.out.println("muits List not getting mom Database.");
						}finally{
							try{
								 rs.close();
								 stmt.close();
								}catch (Exception e) {
									e.printStackTrace();
								}
							}
						return count;
					}

					public int deleteCategory(int id, Connection con) {
						String query = "delete from top_category where ID=?";
						int i=0;
						try{
							 ps=(PreparedStatement) con.prepareStatement(query);
							 ps.setInt(1, id);
							 i=ps.executeUpdate();
						}catch (Exception e) {
							e.printStackTrace();
						}finally{
							try{
								 ps.close();
								}catch (Exception e) {
									e.printStackTrace();
								}
							}
						return i;
					}
					
					// Get Category List mom database.
					public ArrayList<Category>  getSubCategoryFilterByCategory(String ctg, Connection con){		
						Category c = null;
						String filter = " where 1=1";
						if(ctg!=null && !ctg.equals("")){
							filter +=" AND MAIN_CATEGORY='"+ctg+"'";
						}
						
						ArrayList<Category> al = new ArrayList<Category>();
						String query= "select distinct SUB_CATEGORY from top_category "+filter+"  order by ID DESC";
						try{	
							 stmt = (Statement)con.createStatement();
							  rs = (ResultSet)stmt.executeQuery(query);
							while(rs.next()){		
								c = new Category();
								  c.setSubCategory(rs.getString("SUB_CATEGORY"));
								  al.add(c);
							}
						}
						catch (Exception e) {
							System.out.println("Image Gallery List not getting mom Database.");
						}finally {
				    // Always make sure result sets and statements are closed,
				    if (rs != null) {
					      try { rs.close(); } catch (SQLException e) { ; }
					      rs = null;
					    }
				    if (stmt != null) {
				      try { stmt.close(); } catch (SQLException e) { ; }
				      stmt = null;
				    }
				}
						return al;
					}
					
					
}

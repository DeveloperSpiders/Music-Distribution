package com.soft.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.soft.model.Category;
import com.soft.model.ChildCategory;
import com.soft.utility.DBConnection;

public class ChildCategoryDAO {

//    DBConnection dbc=new DBConnection();
	int i=0;
	Statement stmt = null;
	ResultSet rs = null;
//	Connection con = (Connection)DBConnection.getInstance().insertPreparequery();
	PreparedStatement ps = null;
	public int addChildCategory(ChildCategory  c, Connection con) {
		String query = "insert into child_category(MAIN_CATEGORY, SUB_CATEGORY, EXTRAS, ENTRY_BY, ENTRY_DATE) values(?, ?, ?, ?, now())";
		try{
//		 con=dbc.insertPreparequery();
		 ps=(PreparedStatement) con.prepareStatement(query);
		 ps.setString(1, c.getCategory());
		 ps.setString(2, c.getSubcategory());
		 ps.setString(3, c.getExtras());
		 ps.setString(4, c.getEntryBy());
		 i=ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				 ps.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		return i;
	}
	// he is new joining he will get the details of receiver from him.
			public ArrayList<ChildCategory> selectChildCategoryList(Connection con){		
				ChildCategory c = null;
				ArrayList<ChildCategory> al = new ArrayList<ChildCategory>();
				String query= "select * from child_category order by MAIN_CATEGORY, SUB_CATEGORY DESC";
				try{	
					  stmt = (Statement)con.createStatement();
					  rs = (ResultSet)stmt.executeQuery(query);
					  while (rs.next()) {
						  c = new ChildCategory();
						  c.setId(rs.getInt("ID"));
						  c.setEntryBy(rs.getString("ENTRY_BY"));
						  c.setEntryDate(rs.getDate("ENTRY_DATE").toString());
						  c.setExtras(rs.getString("EXTRAS"));
						  c.setCategory(rs.getString("MAIN_CATEGORY"));
						  c.setSubcategory(rs.getString("SUB_CATEGORY"));
						  al.add(c);
					}
				}
				catch (Exception e) {
					System.out.println("muits List not getting mom Database.");
				}finally{
					try{
						 rs.close();
						 stmt.close();
						}catch (Exception e) {
							e.printStackTrace();
						}
					}
				return al;
			}

			// he is new joining he will get the details of receiver from him.
					public ArrayList<ChildCategory> selectChildCategoryListByMainChildCategory(String mainChildCategory, Connection con){		
						ChildCategory c = null;
						ArrayList<ChildCategory> al = new ArrayList<ChildCategory>();
						String query= "select * from child_category where SUB_CATEGORY='"+mainChildCategory+"' order by SUB_CATEGORY DESC";
						try{	
							  stmt = (Statement)con.createStatement();
							  rs = (ResultSet)stmt.executeQuery(query);
							  while (rs.next()) {
								  c = new ChildCategory();
								  c.setId(rs.getInt("ID"));
								  c.setEntryBy(rs.getString("ENTRY_BY"));
								  c.setEntryDate(rs.getDate("ENTRY_DATE").toString());
								  c.setExtras(rs.getString("EXTRAS"));
								  c.setCategory(rs.getString("MAIN_CATEGORY"));
								  c.setSubcategory(rs.getString("SUB_CATEGORY"));
								  al.add(c);
							}
						}
						catch (Exception e) {
							System.out.println("muits List not getting mom Database.");
						}finally{
							try{
								 rs.close();
								 stmt.close();
								}catch (Exception e) {
									e.printStackTrace();
								}
							}
						return al;
					}
			// he is new joining he will get the details of receiver from him.
					public int totalChildCategoryCount(Connection con){		
						int count=0;
						String query= "select max(ID) as ID from child_category";
						try{	
							  stmt = (Statement)con.createStatement();
							  rs = (ResultSet)stmt.executeQuery(query);
							  while (rs.next()) {
								count = rs.getInt("ID");
							}
						}
						catch (Exception e) {
							System.out.println("muits List not getting mom Database.");
						}finally{
							try{
								 rs.close();
								 stmt.close();
								}catch (Exception e) {
									e.printStackTrace();
								}
							}
						return count;
					}

					public int deleteChildCategory(int id, Connection con) {
						String query = "delete from child_category where ID=?";
						int i=0;
						try{
							 ps=(PreparedStatement) con.prepareStatement(query);
							 ps.setInt(1, id);
							 i=ps.executeUpdate();
						}catch (Exception e) {
							e.printStackTrace();
						}finally{
							try{
								 ps.close();
								}catch (Exception e) {
									e.printStackTrace();
								}
							}
						return i;
					}
					
					// Get Category List mom database.
					public ArrayList<ChildCategory>  getChildCategoryFilterBySubCategory(String subctg, Connection con){		
						ChildCategory c = null;
						String filter = " where 1=1";
						if(subctg!=null && !subctg.equals("")){
							filter +=" AND SUB_CATEGORY='"+subctg+"'";
						}
						
						ArrayList<ChildCategory> al = new ArrayList<ChildCategory>();
						String query= "select distinct EXTRAS from child_category "+filter+"  order by ID DESC";
						try{	
							 stmt = (Statement)con.createStatement();
							  rs = (ResultSet)stmt.executeQuery(query);
							while(rs.next()){		
								c = new ChildCategory();
								  c.setExtras(rs.getString("EXTRAS"));
								  al.add(c);
							}
						}
						catch (Exception e) {
							System.out.println("Image Gallery List not getting mom Database.");
						}finally {
				    // Always make sure result sets and statements are closed,
				    if (rs != null) {
					      try { rs.close(); } catch (SQLException e) { ; }
					      rs = null;
					    }
				    if (stmt != null) {
				      try { stmt.close(); } catch (SQLException e) { ; }
				      stmt = null;
				    }
				}
						return al;
					}
}

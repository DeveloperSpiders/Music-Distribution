package com.soft.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.soft.model.ContactUs;
import com.soft.model.VisitorContact;

public class ContactUsDAO {
	// DBConnection dbc=new DBConnection();
		int i=0;
		Statement stmt = null;
		ResultSet rs = null;
//		Connection con = (Connection)DBConnection.getInstance().insertPreparequery();
		PreparedStatement ps = null;
		public int addNewContact(ContactUs  c, Connection con) {
			String query = "insert into contact_us(CONTACT, CONTACT2, ADDRESS, ADDRESS2, EMAIL, EMAIL2, ABOUT, ABOUT_LONG, ENTRY_BY, ENTRY_DATE) values(?, ?, ?, ?, ?, ?, ?, ?, 'ADMIN',  now())";
			try{
			 ps=(PreparedStatement) con.prepareStatement(query);
			 ps.setString(1, c.getContact());
			 ps.setString(2, c.getContact2());
			 ps.setString(3, c.getAddress());
			 ps.setString(4, c.getAddress2());
			 ps.setString(5, c.getEmail());
			 ps.setString(6, c.getEmail2());
			 ps.setString(7, c.getAbout());
			 ps.setString(8, c.getAboutLong());
			 i=ps.executeUpdate();
			}catch (Exception e) {
				e.printStackTrace();
			}finally{
				try{
					 ps.close();
					}catch (Exception e) {
						e.printStackTrace();
					}
				}
			return i;
		}
		
		public int UpdateContactDetails(ContactUs  c, Connection con) {
			String query = "update contact_us set CONTACT=?, CONTACT2=?, ADDRESS=?, ADDRESS2=?, EMAIL=?, EMAIL2=?, ABOUT=?, ABOUT_LONG=? where ID=?";
			try{
			 ps=(PreparedStatement) con.prepareStatement(query);
			 ps.setString(1, c.getContact());
			 ps.setString(2, c.getContact2());
			 ps.setString(3, c.getAddress());
			 ps.setString(4, c.getAddress2());
			 ps.setString(5, c.getEmail());
			 ps.setString(6, c.getEmail2());
			 ps.setString(7, c.getAbout());
			 ps.setString(8, c.getAboutLong());
			 ps.setInt(9, c.getId());
			 i=ps.executeUpdate();
			}catch (Exception e) {
				e.printStackTrace();
			}finally{
				try{
					 ps.close();
					}catch (Exception e) {
						e.printStackTrace();
					}
				}
			return i;
		}

		
		// he is new joining he will get the details of receiver from him.
		public ArrayList<ContactUs> selectContactList(Connection con){		
			ContactUs c = null;
			ArrayList<ContactUs> al = new ArrayList<ContactUs>();
			String query= "select * from contact_us order by ID DESC";
			try{	
				  stmt = (Statement)con.createStatement();
				  rs = (ResultSet)stmt.executeQuery(query);
				  while (rs.next()){
					  c = new ContactUs();
					  c.setId(rs.getInt("ID"));
					  c.setContact(rs.getString("CONTACT"));
					  c.setContact2(rs.getString("CONTACT2"));
					  c.setAddress(rs.getString("ADDRESS"));
					  c.setAddress2(rs.getString("ADDRESS2"));
					  c.setEmail(rs.getString("EMAIL"));
					  c.setEmail2(rs.getString("EMAIL2"));
					  c.setAbout(rs.getString("ABOUT"));
					  c.setAboutLong(rs.getString("ABOUT_LONG"));
					  c.setEntryBy(rs.getString("ENTRY_BY"));
					  c.setEntryDate(rs.getDate("ENTRY_DATE"));
					  al.add(c);
				}
			}
			catch (Exception e) {
				System.out.println("muits List not getting mom Database.");
			}finally{
				try{
					 rs.close();
					 stmt.close();
					}catch (Exception e) {
						e.printStackTrace();
					}
				}
			return al;
		}
		
		
		// he is new joining he will get the details of receiver from him.
				public ArrayList<ContactUs> selectContactDetails(int id, Connection con){		
					ContactUs c = null;
					ArrayList<ContactUs> al = new ArrayList<ContactUs>();
					String query= "select * from contact_us where ID='"+id+"'";
					try{	
						  stmt = (Statement)con.createStatement();
						  rs = (ResultSet)stmt.executeQuery(query);
						  while (rs.next()){
							  c = new ContactUs();
							  c.setId(rs.getInt("ID"));
							  c.setContact(rs.getString("CONTACT"));
							  c.setContact2(rs.getString("CONTACT2"));
							  c.setAddress(rs.getString("ADDRESS"));
							  c.setAddress2(rs.getString("ADDRESS2"));
							  c.setEmail(rs.getString("EMAIL"));
							  c.setEmail2(rs.getString("EMAIL2"));
							  c.setAbout(rs.getString("ABOUT"));
							  c.setAboutLong(rs.getString("ABOUT_LONG"));
							  c.setEntryBy(rs.getString("ENTRY_BY"));
							  c.setEntryDate(rs.getDate("ENTRY_DATE"));
							  al.add(c);
						}
					}
					catch (Exception e) {
						System.out.println("muits List not getting mom Database.");
					}finally{
						try{
							 rs.close();
							 stmt.close();
							}catch (Exception e) {
								e.printStackTrace();
							}
						}
					return al;
				}
				
		
		public int DeleteContactDetails(int id, Connection con) {
			String query = "delete from contact_us where ID=?";
			int i=0;
			try{
				 ps=(PreparedStatement) con.prepareStatement(query);
				 ps.setInt(1, id);
				 i=ps.executeUpdate();
			}catch (Exception e) {
				e.printStackTrace();
			}finally{
				try{
					 ps.close();
					}catch (Exception e) {
						e.printStackTrace();
					}
				}
			return i;
		}
		
		
		
		public ArrayList<ContactUs> getSilgleContactDetails(int id, Connection con){		
			ContactUs cu = null;
			ArrayList<ContactUs> al = new ArrayList<ContactUs>();
			String query= "select * from contact_us order by ID DESC limit 1";
			try{	
//				ResultSet rs = dbc.selectquery(query);
				 stmt = (Statement)con.createStatement();
				  rs = (ResultSet)stmt.executeQuery(query);
				while(rs.next()){		
					cu = getContactgEntry(rs);
						al.add(cu);
					}
				}
				catch (Exception e) {
				System.out.println("bank account List not getting from Database.");
				}finally {
				    // Always make sure result sets and statements are closed,
				    if (rs != null) {
					      try { rs.close(); } catch (SQLException e) { ; }
					      rs = null;
					    }
				    if (stmt != null) {
				      try { stmt.close(); } catch (SQLException e) { ; }
				      stmt = null;
				    }
				}
		   return al;
		}
		
		public ContactUs getSilgleContactDetail(int id, Connection con){		
			ContactUs cu = null;
			String query= "select * from contact_us order by ID DESC limit 1";
			try{	
//				ResultSet rs = dbc.selectquery(query);
				 stmt = (Statement)con.createStatement();
				  rs = (ResultSet)stmt.executeQuery(query);
				while(rs.next()){		
					cu = getContactgEntry(rs);
					}
				}
				catch (Exception e) {
				System.out.println("bank account List not getting from Database.");
				}finally {
				    // Always make sure result sets and statements are closed,
				    if (rs != null) {
					      try { rs.close(); } catch (SQLException e) { ; }
					      rs = null;
					    }
				    if (stmt != null) {
				      try { stmt.close(); } catch (SQLException e) { ; }
				      stmt = null;
				    }
				}
		   return cu;
		}
		
		
		private ContactUs getContactgEntry(ResultSet rs)
				throws SQLException {
				ContactUs c;
				c = new ContactUs();
				  c.setId(rs.getInt("ID"));
				  c.setContact(rs.getString("CONTACT"));
				  c.setContact2(rs.getString("CONTACT2"));
				  c.setAddress(rs.getString("ADDRESS"));
				  c.setAddress2(rs.getString("ADDRESS2"));
				  c.setEmail(rs.getString("EMAIL"));
				  c.setEmail2(rs.getString("EMAIL2"));
				  c.setAbout(rs.getString("ABOUT"));
				  c.setAboutLong(rs.getString("ABOUT_LONG"));
				  c.setEntryBy(rs.getString("ENTRY_BY"));
				  c.setEntryDate(rs.getDate("ENTRY_DATE"));
			return c;
		}
		
		public int getLastContactID(Connection con) {
			int id = 0;
//			ResultSet rs = null;
			String query = "select MAX(ID) as ID from contact_us";
			try {
//				rs = dbc.selectquery(query);
				 stmt = (Statement)con.createStatement();
				  rs = (ResultSet)stmt.executeQuery(query);
				while (rs.next()) {
					id = rs.getInt("ID");
				}
			} catch (Exception e) {
				System.out.println("Sorry! Please try again later.");
			}finally{
				try{
					 rs.close();
					 stmt.close();
					}catch (Exception e) {
						e.printStackTrace();
					}
				}
			return id;
		}
		
		
		
}

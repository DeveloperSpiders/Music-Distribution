package com.soft.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.soft.model.ContactUs;
import com.soft.model.VisitorContact;

public class VisitorContactDAO {
	// DBConnection dbc=new DBConnection();
			int i=0;
			Statement stmt = null;
			ResultSet rs = null;
//			Connection con = (Connection)DBConnection.getInstance().insertPreparequery();
			PreparedStatement ps = null;
			public int addVisitorContact(VisitorContact  c, Connection con) {
				String query = "insert into visitor_contact(NAME, EMAIL, CONTACT, MESSAGE, ENTRY_BY, ENTRY_DATE) values(?, ?, ?, ?, ?, now())";
				try{
				 ps=(PreparedStatement) con.prepareStatement(query);
				 ps.setString(1, c.getName());
				 ps.setString(2, c.getEmail());
				 ps.setString(3, c.getContact());
				 ps.setString(4, c.getMessage());
				 ps.setString(5, c.getEntryBy());
				 i=ps.executeUpdate();
				}catch (Exception e) {
					e.printStackTrace();
				}finally{
					try{
						 ps.close();
						}catch (Exception e) {
							e.printStackTrace();
						}
					}
				return i;
			}
			
			
			// he is new joining he will get the details of receiver from him.
			public ArrayList<VisitorContact> selectVisitorContactList(Connection con){		
				VisitorContact c = null;
				ArrayList<VisitorContact> al = new ArrayList<VisitorContact>();
				String query= "select * from visitor_contact order by ID DESC";
				try{	
					  stmt = (Statement)con.createStatement();
					  rs = (ResultSet)stmt.executeQuery(query);
					  while (rs.next()){
						  c = new VisitorContact();
						  c.setId(rs.getInt("ID"));
						  c.setName(rs.getString("NAME"));
						  c.setEmail(rs.getString("EMAIL"));
						  c.setContact(rs.getString("CONTACT"));
						  c.setMessage(rs.getString("MESSAGE"));
						  c.setEntryBy(rs.getString("ENTRY_BY"));
						  c.setEntryDate(rs.getDate("ENTRY_DATE"));
						  al.add(c);
					}
				}
				catch (Exception e) {
					System.out.println("muits List not getting mom Database.");
				}finally{
					try{
						 rs.close();
						 stmt.close();
						}catch (Exception e) {
							e.printStackTrace();
						}
					}
				return al;
			}

}

package com.soft.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import java.sql.PreparedStatement;
import java.sql.Connection;

import com.soft.model.AlbumName;

	public class AlbumNameDAO {
		int i=0;
		
	    PreparedStatement ps = null;
		Statement stmt = null;
		ResultSet rs = null;
		PreparedStatement ps1 = null;
		public int AddAlbumNameImage(String subj, String eventDate, Connection con) {
			String query = "insert into album_name(SUBJECT, IMAGE_PATH,  ENTRY_BY, ENTRY_DATE) values(?, 'NA', 'ADMIN', ?)";
			try{
//			 con=dbc.insertPreparequery();
			 PreparedStatement ps=(PreparedStatement) con.prepareStatement(query);
			 ps.setString(1, subj);
			 ps.setString(2, eventDate);
			 i=ps.executeUpdate();
			 if(i!=0){
				i= getLastAlbumNameID(con);
			 }
			}catch (Exception e) {
				e.printStackTrace();
			}finally {
			    // Always make sure result sets and statements are closed,
			    if (ps!= null) {
			      try { ps.close(); } catch (SQLException e) { ; }
			      ps = null;
			    }
			}
			return i;
		}
		
		public int updateAlbumImagePath(String path, int id, Connection con) {
			String query = "update album_name set IMAGE_PATH='"+path+"' where ID="+id;
			//DBConnection dbc = new DBConnection();
			int i=0;
			try{
				//i = dbc.insertquery(query);
				ps=(PreparedStatement) con.prepareStatement(query);
				i=ps.executeUpdate();
			}catch (Exception e) {
				e.printStackTrace();
			}
			return i;
		}

		// Get Category List from database.
				public ArrayList<AlbumName> getAlbumNameList(int id, Connection con){		
					AlbumName devices = null;
					int fst = id - 20;
					ArrayList<AlbumName> arraylist = new ArrayList<AlbumName>();
					String query= "select * from album_name order by ID  ASC";
					try{			
					    ps=(PreparedStatement) con.prepareStatement(query);
						rs = ps.executeQuery();
							while(rs.next()){	
							devices = getSingleStoreEntry(rs);
							arraylist.add(devices);
						}
					}catch (Exception e){
						System.out.println("fruits List not getting from Database.");
					}finally {
					    // Always make sure result sets and statements are closed,
					    if (rs != null) {
						      try { rs.close(); } catch (SQLException e) { ; }
						      rs = null;
						    }
					    if (ps!= null) {
					      try { ps.close(); } catch (SQLException e) { ; }
					      ps = null;
					    }
					}
					return arraylist;
				}
				// Get Category List from database.
							public ArrayList<AlbumName> getAlbumNameListForUploadGallery(Connection con){		
								AlbumName devices = null;
								ArrayList<AlbumName> arraylist = new ArrayList<AlbumName>();
								String query= "select * from album_name ORDER BY ID ASC";
								try{			
								    ps=(PreparedStatement) con.prepareStatement(query);
									rs = ps.executeQuery();
										while(rs.next()){	
										devices = getSingleStoreEntry(rs);
										arraylist.add(devices);
									}
								}catch (Exception e){
									System.out.println("fruits List not getting from Database.");
								}finally {
								    // Always make sure result sets and statements are closed,
								    if (rs != null) {
									      try { rs.close(); } catch (SQLException e) { ; }
									      rs = null;
									    }
								    if (ps!= null) {
								      try { ps.close(); } catch (SQLException e) { ; }
								      ps = null;
								    }
								}
								return arraylist;
							}

							// Get Category List from database.
										public AlbumName getAlbumNameByAlbumId(int id, Connection con){		
											AlbumName devices = null;
											String query= "select * from album_name where ID="+id;
											try{			
											    ps=(PreparedStatement) con.prepareStatement(query);
												rs = ps.executeQuery();
													while(rs.next()){	
													devices = getSingleStoreEntry(rs);
												}
											}catch (Exception e){
												System.out.println("get Album Name List For Upload Gallery List not getting from Database.");
											}finally {
											    // Always make sure result sets and statements are closed,
											    if (rs != null) {
												      try { rs.close(); } catch (SQLException e) { ; }
												      rs = null;
												    }
											    if (ps!= null) {
											      try { ps.close(); } catch (SQLException e) { ; }
											      ps = null;
											    }
											}
											return devices;
										}
				//Get AdminCategory Data Method
				private AlbumName getSingleStoreEntry(ResultSet rs)
						throws SQLException {
					AlbumName fr;
					fr=new AlbumName();
					fr.setId(rs.getInt("ID"));
					fr.setSubject(rs.getString("SUBJECT"));
					fr.setEntryBy(rs.getString("ENTRY_BY"));
					fr.setEntryDate(rs.getString("ENTRY_DATE"));
					fr.setImagePath(rs.getString("IMAGE_PATH"));
					return fr;
				}
		// Get Category List from database.
		public int getLastAlbumNameID(Connection con) {
			int id = 0;
			String query = "select MAX(ID) as ID from album_name";
			try{			
			    ps=(PreparedStatement) con.prepareStatement(query);
				rs = ps.executeQuery();
					while(rs.next()){
					id = rs.getInt("ID");
				}
			} catch (Exception e) {
				System.out.println("Sorry! Please try again later.");
			} finally {
			    // Always make sure result sets and statements are closed,
			    if (rs != null) {
				      try { rs.close(); } catch (SQLException e) { ; }
				      rs = null;
				    }
			}
			return id;
		}
		public int updateImagePath(String path, int id, Connection con) {
			String query = "update album_name set IMAGE_PATH='"+path+"' where ID="+id;
			int i=0;
			try{
				 ps=(PreparedStatement) con.prepareStatement(query);
					i = ps.executeUpdate() ;
			}catch (Exception e) {
				e.printStackTrace();
			}finally {
			    // Always make sure result sets and statements are closed,
			    if (ps!= null) {
			      try { ps.close(); } catch (SQLException e) { ; }
			      ps = null;
			    }
			}
			return i;
		}
		
		public int deleteAlbumNameImage(int id, Connection con) {
			String query1= "delete from gallery where ALBUM_ID="+id;
			String query = "delete from album_name where ID="+id;
			int i=0;
			try{
				 ps=(PreparedStatement) con.prepareStatement(query);
				 i = ps.executeUpdate() ;
				 ps1=(PreparedStatement) con.prepareStatement(query1);
				i = ps1.executeUpdate() ;
			}catch (Exception e) {
				e.printStackTrace();
			}finally {
			    // Always make sure result sets and statements are closed,
			    if (ps1 != null) {
				      try {ps1.close(); } catch (SQLException e) { ; }
				      ps1 = null;
				    }
			    if (ps!= null) {
			      try { ps.close(); } catch (SQLException e) { ; }
			      ps = null;
			    }
			}
			return i;
		}
		
		
	}
	
	

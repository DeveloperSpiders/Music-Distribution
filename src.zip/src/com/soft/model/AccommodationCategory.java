package com.soft.model;

import java.io.Serializable;

public class AccommodationCategory implements Serializable{
	private static final long serialVersionUID = 1L;
	int id;
	String accommodationCategory;
	String extras;
	String entryBy;
	String entryDate;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAccommodationCategory() {
		return accommodationCategory;
	}
	public void setAccommodationCategory(String accommodationCategory) {
		this.accommodationCategory = accommodationCategory;
	}
	public String getExtras() {
		return extras;
	}
	public void setExtras(String extras) {
		this.extras = extras;
	}
	public String getEntryBy() {
		return entryBy;
	}
	public void setEntryBy(String entryBy) {
		this.entryBy = entryBy;
	}
	public String getEntryDate() {
		return entryDate;
	}
	public void setEntryDate(String entryDate) {
		this.entryDate = entryDate;
	}
	
	
}

package com.soft.model;

import java.io.Serializable;
import java.util.Date;

public class Kit implements Serializable {
	private static final long serialVersionUID = 1L;
	int id;
	String kitName;
	float kitAmount;
	int kitPointValue;
	float kitWeight;
	Float firstLevelCommission;
	String kitDescription;
	String category;
	String entryBy;
	Date entryDate;
	float gstAmount;
	float gstRate;
	float commissionLevel1;
	float commissionLevel2;
	float commissionLevel3;
	float commissionLevel4;
	float commissionLevel5;
	float commissionLevel6;
	float commissionLevel7;
	float commissionLevel8;
	float commissionLevel9;
	float commissionLevel10;
	float commissionLevel11;
	float commissionLevel12;
	float commissionLevel13;
	float commissionLevel14;
	float commissionLevel15;
	float commissionLevel16;
	int totalKit;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getKitName() {
		return kitName;
	}
	public void setKitName(String kitName) {
		this.kitName = kitName;
	}
	public float getKitAmount() {
		return kitAmount;
	}
	public void setKitAmount(float kitAmount) {
		this.kitAmount = kitAmount;
	}
	public int getKitPointValue() {
		return kitPointValue;
	}
	public void setKitPointValue(int kitPointValue) {
		this.kitPointValue = kitPointValue;
	}
	public float getKitWeight() {
		return kitWeight;
	}
	public void setKitWeight(float kitWeight) {
		this.kitWeight = kitWeight;
	}
	public Float getFirstLevelCommission() {
		return firstLevelCommission;
	}
	public void setFirstLevelCommission(Float firstLevelCommission) {
		this.firstLevelCommission = firstLevelCommission;
	}
	public String getKitDescription() {
		return kitDescription;
	}
	public void setKitDescription(String kitDescription) {
		this.kitDescription = kitDescription;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getEntryBy() {
		return entryBy;
	}
	public void setEntryBy(String entryBy) {
		this.entryBy = entryBy;
	}
	public Date getEntryDate() {
		return entryDate;
	}
	public void setEntryDate(Date entryDate) {
		this.entryDate = entryDate;
	}
	public float getGstAmount() {
		return gstAmount;
	}
	public void setGstAmount(float gstAmount) {
		this.gstAmount = gstAmount;
	}
	public float getGstRate() {
		return gstRate;
	}
	public void setGstRate(float gstRate) {
		this.gstRate = gstRate;
	}
	public float getCommissionLevel1() {
		return commissionLevel1;
	}
	public void setCommissionLevel1(float commissionLevel1) {
		this.commissionLevel1 = commissionLevel1;
	}
	public float getCommissionLevel2() {
		return commissionLevel2;
	}
	public void setCommissionLevel2(float commissionLevel2) {
		this.commissionLevel2 = commissionLevel2;
	}
	public float getCommissionLevel3() {
		return commissionLevel3;
	}
	public void setCommissionLevel3(float commissionLevel3) {
		this.commissionLevel3 = commissionLevel3;
	}
	public float getCommissionLevel4() {
		return commissionLevel4;
	}
	public void setCommissionLevel4(float commissionLevel4) {
		this.commissionLevel4 = commissionLevel4;
	}
	public float getCommissionLevel5() {
		return commissionLevel5;
	}
	public void setCommissionLevel5(float commissionLevel5) {
		this.commissionLevel5 = commissionLevel5;
	}
	public float getCommissionLevel6() {
		return commissionLevel6;
	}
	public void setCommissionLevel6(float commissionLevel6) {
		this.commissionLevel6 = commissionLevel6;
	}
	public float getCommissionLevel7() {
		return commissionLevel7;
	}
	public void setCommissionLevel7(float commissionLevel7) {
		this.commissionLevel7 = commissionLevel7;
	}
	public float getCommissionLevel8() {
		return commissionLevel8;
	}
	public void setCommissionLevel8(float commissionLevel8) {
		this.commissionLevel8 = commissionLevel8;
	}
	public float getCommissionLevel9() {
		return commissionLevel9;
	}
	public void setCommissionLevel9(float commissionLevel9) {
		this.commissionLevel9 = commissionLevel9;
	}
	public float getCommissionLevel10() {
		return commissionLevel10;
	}
	public void setCommissionLevel10(float commissionLevel10) {
		this.commissionLevel10 = commissionLevel10;
	}
	public float getCommissionLevel11() {
		return commissionLevel11;
	}
	public void setCommissionLevel11(float commissionLevel11) {
		this.commissionLevel11 = commissionLevel11;
	}
	public float getCommissionLevel12() {
		return commissionLevel12;
	}
	public void setCommissionLevel12(float commissionLevel12) {
		this.commissionLevel12 = commissionLevel12;
	}
	public float getCommissionLevel13() {
		return commissionLevel13;
	}
	public void setCommissionLevel13(float commissionLevel13) {
		this.commissionLevel13 = commissionLevel13;
	}
	public float getCommissionLevel14() {
		return commissionLevel14;
	}
	public void setCommissionLevel14(float commissionLevel14) {
		this.commissionLevel14 = commissionLevel14;
	}
	public float getCommissionLevel15() {
		return commissionLevel15;
	}
	public void setCommissionLevel15(float commissionLevel15) {
		this.commissionLevel15 = commissionLevel15;
	}
	public float getCommissionLevel16() {
		return commissionLevel16;
	}
	public void setCommissionLevel16(float commissionLevel16) {
		this.commissionLevel16 = commissionLevel16;
	}
	public int getTotalKit() {
		return totalKit;
	}
	public void setTotalKit(int totalKit) {
		this.totalKit = totalKit;
	}
}

package com.soft.model;

import java.io.Serializable;
import java.util.Date;

public class Helpdesk implements Serializable {
	private static final long serialVersionUID = 1L;
	int id;
	String loginId;
	String memberName;
	String subject;
	String description;
	String adminComment;
	String status;
	Date adminCommentDate;
	String imagePath;
	Date entryDate;
	String paymentMethod;
	String topupBy;
	String queryType;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public String getMemberName() {
		return memberName;
	}
	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getAdminComment() {
		return adminComment;
	}
	public void setAdminComment(String adminComment) {
		this.adminComment = adminComment;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getAdminCommentDate() {
		return adminCommentDate;
	}
	public void setAdminCommentDate(Date adminCommentDate) {
		this.adminCommentDate = adminCommentDate;
	}
	public String getImagePath() {
		return imagePath;
	}
	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}
	public Date getEntryDate() {
		return entryDate;
	}
	public void setEntryDate(Date entryDate) {
		this.entryDate = entryDate;
	}
	public String getPaymentMethod() {
		return paymentMethod;
	}
	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	public String getTopupBy() {
		return topupBy;
	}
	public void setTopupBy(String topupBy) {
		this.topupBy = topupBy;
	}
	public String getQueryType() {
		return queryType;
	}
	public void setQueryType(String queryType) {
		this.queryType = queryType;
	}
}

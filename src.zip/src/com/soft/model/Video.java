package com.soft.model;

import java.io.Serializable;
import java.util.Date;

public class Video implements Serializable {
	private static final long serialVersionUID = 1L;
	
	
	
	int id;
	String type;
	String title;
	String singer;
	String musicDirector;
	String lyrics;
	String genre;
	String mood;
	String label;
	String publisher;
	String isrc;
	String crbtTitle;
	String crbtTime;
	String language;
	String duration;
	String videoDirector;
	String starCast;
	String releasingDate;
	String filePath;
	String imagepath1;
	String imagepath2;
	String imagepath3;
	String contentRating;
	String description;
	String filmSynopsis;
	String category;
	String remark;
	
	String status;
	String entryBy;
	Date entryDate;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getSinger() {
		return singer;
	}
	public void setSinger(String singer) {
		this.singer = singer;
	}
	public String getMusicDirector() {
		return musicDirector;
	}
	public void setMusicDirector(String musicDirector) {
		this.musicDirector = musicDirector;
	}
	public String getLyrics() {
		return lyrics;
	}
	public void setLyrics(String lyrics) {
		this.lyrics = lyrics;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	public String getMood() {
		return mood;
	}
	public void setMood(String mood) {
		this.mood = mood;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	public String getIsrc() {
		return isrc;
	}
	public void setIsrc(String isrc) {
		this.isrc = isrc;
	}
	public String getCrbtTitle() {
		return crbtTitle;
	}
	public void setCrbtTitle(String crbtTitle) {
		this.crbtTitle = crbtTitle;
	}
	public String getCrbtTime() {
		return crbtTime;
	}
	public void setCrbtTime(String crbtTime) {
		this.crbtTime = crbtTime;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public String getVideoDirector() {
		return videoDirector;
	}
	public void setVideoDirector(String videoDirector) {
		this.videoDirector = videoDirector;
	}
	public String getStarCast() {
		return starCast;
	}
	public void setStarCast(String starCast) {
		this.starCast = starCast;
	}
	public String getReleasingDate() {
		return releasingDate;
	}
	public void setReleasingDate(String releasingDate) {
		this.releasingDate = releasingDate;
	}
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	public String getImagepath1() {
		return imagepath1;
	}
	public void setImagepath1(String imagepath1) {
		this.imagepath1 = imagepath1;
	}
	public String getImagepath2() {
		return imagepath2;
	}
	public void setImagepath2(String imagepath2) {
		this.imagepath2 = imagepath2;
	}
	public String getImagepath3() {
		return imagepath3;
	}
	public void setImagepath3(String imagepath3) {
		this.imagepath3 = imagepath3;
	}
	public String getContentRating() {
		return contentRating;
	}
	public void setContentRating(String contentRating) {
		this.contentRating = contentRating;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getFilmSynopsis() {
		return filmSynopsis;
	}
	public void setFilmSynopsis(String filmSynopsis) {
		this.filmSynopsis = filmSynopsis;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getEntryBy() {
		return entryBy;
	}
	public void setEntryBy(String entryBy) {
		this.entryBy = entryBy;
	}
	public Date getEntryDate() {
		return entryDate;
	}
	public void setEntryDate(Date entryDate) {
		this.entryDate = entryDate;
	}
	
	
	
	
	
	
}

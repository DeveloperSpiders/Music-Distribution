package com.soft.model;

import java.io.Serializable;
import java.util.Date;

public class Payment implements Serializable {
	private static final long serialVersionUID = 1L;
	int id;
	int orderID;
	String loginID;
	String paymentvia;
	String paymentType;
	float totalAmount;
	String paymentStatus;
	Date paymentDate;
	String paymentviaName;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getOrderID() {
		return orderID;
	}
	public void setOrderID(int orderID) {
		this.orderID = orderID;
	}
	public String getLoginID() {
		return loginID;
	}
	public void setLoginID(String loginID) {
		this.loginID = loginID;
	}
	public String getPaymentvia() {
		return paymentvia;
	}
	public void setPaymentvia(String paymentvia) {
		this.paymentvia = paymentvia;
	}
	public String getPaymentType() {
		return paymentType;
	}
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
	public float getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(float totalAmount) {
		this.totalAmount = totalAmount;
	}
	public String getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
	public Date getPaymentDate() {
		return paymentDate;
	}
	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}
	public String getPaymentviaName() {
		return paymentviaName;
	}
	public void setPaymentviaName(String paymentviaName) {
		this.paymentviaName = paymentviaName;
	}
}

package com.soft.model;

import java.io.Serializable;
import java.util.Date;

public class Member implements Serializable {
	private static final long serialVersionUID = 1L;
	int id;
	String firstName;
	String lastName;
	String course;
	String companyName;
	String qualification;
	String experience;
	String email;
	String address;
	String loginID;
	String contactNumber;
	String side;
	String password;
	String city;
	String state;
	String uplineID;
	String profileStatus;
	String pinCode;
	int totalDownline;
	String sponsorID;
	float planType;
	String entryBy;
	Date topupDate;
	String transactionPassword;
	Date entryDate;
	String shippingAddress;
	int orderID;
	String orderNo;
	float shippingCharges;
	String orderStatus;
	String branchName;
	float courierCharges;
	String purchaseOrderNo;
	String photoURL;
	String kycStatus;
	String batch;
	String Monthexperience;
	String Yearexperience;
	
	String accountNo;
	String ifsc;
	String bankName;
	String googlePay;
	String phonePe;
	String payTm;
	String upiId;
	
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public String getExperience() {
		return experience;
	}
	public void setExperience(String experience) {
		this.experience = experience;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getLoginID() {
		return loginID;
	}
	public void setLoginID(String loginID) {
		this.loginID = loginID;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getSide() {
		return side;
	}
	public void setSide(String side) {
		this.side = side;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getUplineID() {
		return uplineID;
	}
	public void setUplineID(String uplineID) {
		this.uplineID = uplineID;
	}
	public String getProfileStatus() {
		return profileStatus;
	}
	public void setProfileStatus(String profileStatus) {
		this.profileStatus = profileStatus;
	}
	public String getPinCode() {
		return pinCode;
	}
	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}
	public int getTotalDownline() {
		return totalDownline;
	}
	public void setTotalDownline(int totalDownline) {
		this.totalDownline = totalDownline;
	}
	public String getSponsorID() {
		return sponsorID;
	}
	public void setSponsorID(String sponsorID) {
		this.sponsorID = sponsorID;
	}
	public float getPlanType() {
		return planType;
	}
	public void setPlanType(float planType) {
		this.planType = planType;
	}
	public String getEntryBy() {
		return entryBy;
	}
	public void setEntryBy(String entryBy) {
		this.entryBy = entryBy;
	}
	public Date getTopupDate() {
		return topupDate;
	}
	public void setTopupDate(Date topupDate) {
		this.topupDate = topupDate;
	}
	public String getTransactionPassword() {
		return transactionPassword;
	}
	public void setTransactionPassword(String transactionPassword) {
		this.transactionPassword = transactionPassword;
	}
	public Date getEntryDate() {
		return entryDate;
	}
	public void setEntryDate(Date entryDate) {
		this.entryDate = entryDate;
	}
	public String getShippingAddress() {
		return shippingAddress;
	}
	public void setShippingAddress(String shippingAddress) {
		this.shippingAddress = shippingAddress;
	}
	public int getOrderID() {
		return orderID;
	}
	public void setOrderID(int orderID) {
		this.orderID = orderID;
	}
	public String getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}
	public float getShippingCharges() {
		return shippingCharges;
	}
	public void setShippingCharges(float shippingCharges) {
		this.shippingCharges = shippingCharges;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public float getCourierCharges() {
		return courierCharges;
	}
	public void setCourierCharges(float courierCharges) {
		this.courierCharges = courierCharges;
	}
	public String getPurchaseOrderNo() {
		return purchaseOrderNo;
	}
	public void setPurchaseOrderNo(String purchaseOrderNo) {
		this.purchaseOrderNo = purchaseOrderNo;
	}
	public String getPhotoURL() {
		return photoURL;
	}
	public void setPhotoURL(String photoURL) {
		this.photoURL = photoURL;
	}
	public String getKycStatus() {
		return kycStatus;
	}
	public void setKycStatus(String kycStatus) {
		this.kycStatus = kycStatus;
	}
	public String getBatch() {
		return batch;
	}
	public void setBatch(String batch) {
		this.batch = batch;
	}
	public String getMonthexperience() {
		return Monthexperience;
	}
	public void setMonthexperience(String monthexperience) {
		Monthexperience = monthexperience;
	}
	public String getYearexperience() {
		return Yearexperience;
	}
	public void setYearexperience(String yearexperience) {
		Yearexperience = yearexperience;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getIfsc() {
		return ifsc;
	}
	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getGooglePay() {
		return googlePay;
	}
	public void setGooglePay(String googlePay) {
		this.googlePay = googlePay;
	}
	public String getPhonePe() {
		return phonePe;
	}
	public void setPhonePe(String phonePe) {
		this.phonePe = phonePe;
	}
	public String getPayTm() {
		return payTm;
	}
	public void setPayTm(String payTm) {
		this.payTm = payTm;
	}
	public String getUpiId() {
		return upiId;
	}
	public void setUpiId(String upiId) {
		this.upiId = upiId;
	}
	
	
	
	
}

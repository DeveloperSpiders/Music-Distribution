package com.soft.model;

import java.io.Serializable;

public class TravelCategory implements Serializable{
	private static final long serialVersionUID = 1L;
	int id;
	String travelCategory;
	String extras;
	String entryBy;
	String entryDate;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTravelCategory() {
		return travelCategory;
	}
	public void setTravelCategory(String travelCategory) {
		this.travelCategory = travelCategory;
	}
	public String getExtras() {
		return extras;
	}
	public void setExtras(String extras) {
		this.extras = extras;
	}
	public String getEntryBy() {
		return entryBy;
	}
	public void setEntryBy(String entryBy) {
		this.entryBy = entryBy;
	}
	public String getEntryDate() {
		return entryDate;
	}
	public void setEntryDate(String entryDate) {
		this.entryDate = entryDate;
	}
	
	
}

package com.soft.model;

import java.io.Serializable;
import java.util.Date;

public class RequestUser implements Serializable {
	private static final long serialVersionUID = 1L;
	int id;
	int reqID;
	int bnkID;
	String memberID;
	String name;
	String requestType;
	String status;
	int bankID;
	String orderID;
	float amount;
	float deduction;
	String withdrawalType;
	Date entryDate;
	float tdsRate;
	float tdsAmount;
	float extraCharges;
	String panNumber;
	String kycStatus;
	String entryDate2;
	String accountHolderName;
	String accountNumber;
	String bankName;
	String contactNumber;
	
	String branchName;
	String ifscCode;
	String aadharNumber;
	String dateofBirth;
	String nomineeName;
	String relationship;
	String nomineeAge;
	String entryBy;
	String addressProof;
	String idProof;
	String fatherName;
	String paytmNumber;
	String meritalStatus;
	String aadharFront;
	String aadharBack;
	String pancard;
	String passbook;
	
	String loginId;
	String nomineeAadharNumber;
	String nomineeAddress;
	String narration;
	
	
	float totalIncome;
	float matchingWithdrawal;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getReqID() {
		return reqID;
	}
	public void setReqID(int reqID) {
		this.reqID = reqID;
	}
	public int getBnkID() {
		return bnkID;
	}
	public void setBnkID(int bnkID) {
		this.bnkID = bnkID;
	}
	public String getMemberID() {
		return memberID;
	}
	public void setMemberID(String memberID) {
		this.memberID = memberID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRequestType() {
		return requestType;
	}
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getBankID() {
		return bankID;
	}
	public void setBankID(int bankID) {
		this.bankID = bankID;
	}
	public String getOrderID() {
		return orderID;
	}
	public void setOrderID(String orderID) {
		this.orderID = orderID;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	public float getDeduction() {
		return deduction;
	}
	public void setDeduction(float deduction) {
		this.deduction = deduction;
	}
	public String getWithdrawalType() {
		return withdrawalType;
	}
	public void setWithdrawalType(String withdrawalType) {
		this.withdrawalType = withdrawalType;
	}
	public Date getEntryDate() {
		return entryDate;
	}
	public void setEntryDate(Date entryDate) {
		this.entryDate = entryDate;
	}
	public float getTdsRate() {
		return tdsRate;
	}
	public void setTdsRate(float tdsRate) {
		this.tdsRate = tdsRate;
	}
	public float getTdsAmount() {
		return tdsAmount;
	}
	public void setTdsAmount(float tdsAmount) {
		this.tdsAmount = tdsAmount;
	}
	public float getExtraCharges() {
		return extraCharges;
	}
	public void setExtraCharges(float extraCharges) {
		this.extraCharges = extraCharges;
	}
	public String getPanNumber() {
		return panNumber;
	}
	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}
	public String getKycStatus() {
		return kycStatus;
	}
	public void setKycStatus(String kycStatus) {
		this.kycStatus = kycStatus;
	}
	public String getEntryDate2() {
		return entryDate2;
	}
	public void setEntryDate2(String entryDate2) {
		this.entryDate2 = entryDate2;
	}
	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public String getIfscCode() {
		return ifscCode;
	}
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	public String getAadharNumber() {
		return aadharNumber;
	}
	public void setAadharNumber(String aadharNumber) {
		this.aadharNumber = aadharNumber;
	}
	public String getDateofBirth() {
		return dateofBirth;
	}
	public void setDateofBirth(String dateofBirth) {
		this.dateofBirth = dateofBirth;
	}
	public String getNomineeName() {
		return nomineeName;
	}
	public void setNomineeName(String nomineeName) {
		this.nomineeName = nomineeName;
	}
	public String getRelationship() {
		return relationship;
	}
	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}
	public String getNomineeAge() {
		return nomineeAge;
	}
	public void setNomineeAge(String nomineeAge) {
		this.nomineeAge = nomineeAge;
	}
	public String getEntryBy() {
		return entryBy;
	}
	public void setEntryBy(String entryBy) {
		this.entryBy = entryBy;
	}
	public String getAddressProof() {
		return addressProof;
	}
	public void setAddressProof(String addressProof) {
		this.addressProof = addressProof;
	}
	public String getIdProof() {
		return idProof;
	}
	public void setIdProof(String idProof) {
		this.idProof = idProof;
	}
	public String getFatherName() {
		return fatherName;
	}
	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}
	public String getPaytmNumber() {
		return paytmNumber;
	}
	public void setPaytmNumber(String paytmNumber) {
		this.paytmNumber = paytmNumber;
	}
	public String getMeritalStatus() {
		return meritalStatus;
	}
	public void setMeritalStatus(String meritalStatus) {
		this.meritalStatus = meritalStatus;
	}
	public String getAadharFront() {
		return aadharFront;
	}
	public void setAadharFront(String aadharFront) {
		this.aadharFront = aadharFront;
	}
	public String getAadharBack() {
		return aadharBack;
	}
	public void setAadharBack(String aadharBack) {
		this.aadharBack = aadharBack;
	}
	public String getPancard() {
		return pancard;
	}
	public void setPancard(String pancard) {
		this.pancard = pancard;
	}
	public String getPassbook() {
		return passbook;
	}
	public void setPassbook(String passbook) {
		this.passbook = passbook;
	}
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public String getNomineeAadharNumber() {
		return nomineeAadharNumber;
	}
	public void setNomineeAadharNumber(String nomineeAadharNumber) {
		this.nomineeAadharNumber = nomineeAadharNumber;
	}
	public String getNomineeAddress() {
		return nomineeAddress;
	}
	public void setNomineeAddress(String nomineeAddress) {
		this.nomineeAddress = nomineeAddress;
	}
	public String getNarration() {
		return narration;
	}
	public void setNarration(String narration) {
		this.narration = narration;
	}
	public float getTotalIncome() {
		return totalIncome;
	}
	public void setTotalIncome(float totalIncome) {
		this.totalIncome = totalIncome;
	}
	public float getMatchingWithdrawal() {
		return matchingWithdrawal;
	}
	public void setMatchingWithdrawal(float matchingWithdrawal) {
		this.matchingWithdrawal = matchingWithdrawal;
	}
}

package com.soft.model;

import java.io.Serializable;
import java.util.Date;

public class Banner implements Serializable {
	private static final long serialVersionUID = 1L;
	int id;
	String topLine;
	String subLine;
	String about;
	String bannerPath;
	String entryBy;
	Date entryDate;
	String shoppingURL;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTopLine() {
		return topLine;
	}
	public void setTopLine(String topLine) {
		this.topLine = topLine;
	}
	public String getSubLine() {
		return subLine;
	}
	public void setSubLine(String subLine) {
		this.subLine = subLine;
	}
	public String getAbout() {
		return about;
	}
	public void setAbout(String about) {
		this.about = about;
	}
	public String getBannerPath() {
		return bannerPath;
	}
	public void setBannerPath(String bannerPath) {
		this.bannerPath = bannerPath;
	}
	public String getEntryBy() {
		return entryBy;
	}
	public void setEntryBy(String entryBy) {
		this.entryBy = entryBy;
	}
	public Date getEntryDate() {
		return entryDate;
	}
	public void setEntryDate(Date entryDate) {
		this.entryDate = entryDate;
	}
	public String getShoppingURL() {
		return shoppingURL;
	}
	public void setShoppingURL(String shoppingURL) {
		this.shoppingURL = shoppingURL;
	}
}
